import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {execFileSync} from 'node:child_process';

const baseline=process.argv.includes('--baseline');
const source=baseline?execFileSync('git',['show','HEAD:assets/js/search-palette.js'],{encoding:'utf8'}):fs.readFileSync('assets/js/search-palette.js','utf8');
function section(start,end){return source.slice(source.indexOf(start),source.indexOf(end,source.indexOf(start)));}
const cancellation=section('  function cancelAI()', '  function escapeHtml(value)'),trigger=section('  function updateAiTrigger()', '  // Open palette');
const events=section("  window.addEventListener('pagehide'",'  indexRetry?.addEventListener');
for(const phase of ['headers','partial','completed']){
  const initialHTML=phase==='headers'?'<div class="search-palette__ai-loading"></div>':'same visible conversation '+phase;
  const attrs={'aria-busy':'true'},children=[],handlers={},calls=[],history=[{role:'user',content:'First question'},{role:'assistant',content:'Completed answer'}];
  if(phase!=='completed')history.push({role:'user',content:'Pending follow-up'});
  if(phase==='completed')delete attrs['aria-busy'];
  const partial={textContent:'Keep incomplete answer'},draft={value:'Keep unsubmitted draft'},content={innerHTML:initialHTML,removeAttribute(key){delete attrs[key];},querySelector(selector){return selector==='.search-palette__ai-loading'&&this.innerHTML.includes('ai-loading')?{}:selector==='#ai-streaming-target'?partial:selector==='.search-palette__followup-input'?draft:null;},appendChild(child){children.push(child);}};
  const controller=new AbortController(),reader={cancel(){calls.push('cancel');return Promise.resolve();}},request={controller,reader,timer:0,cleanup(){calls.push('cleanup');}};
  const active=phase!=='completed',aiButton={disabled:active},aiStop={hidden:!active},input={value:'First question',focus(){calls.push('focus');}},context={
    aiSerial:0,aiRequest:active?request:null,isAiThinking:active,isOpen:true,aiBox:{hidden:false},aiContent:content,aiStop,aiBtn:aiButton,input,lastAiQuery:'Pending follow-up',conversationHistory:history,isZh:false,labels:{retry:'Retry'},
    document:{activeElement:null,createElement(){return {isConnected:true,children:[],listeners:{},setAttribute(){},appendChild(child){this.children.push(child);},addEventListener(type,fn){this.listeners[type]=fn;}};}},
    window:{addEventListener(type,fn){handlers[type]=fn;}},clearTimeout(){},cancelSearchIntent(){},cancelIndex(){},fuse:{},doSearch(){calls.push('local search');},loadSearchData(){throw new Error('No index refetch expected');},
    updateFullSearchLink(){},renderConversation(){return history.map(message=>message.content).join('\n');},askAI(question,followup){calls.push({question,followup,context:history.map(message=>({...message}))});},console,
  };
  vm.createContext(context);vm.runInContext(cancellation+'\n'+trigger+'\n'+events,context);const originalHistory=history.slice();handlers.pagehide();handlers.pageshow();
  const result={phase,aborted:controller.signal.aborted,requestCleared:context.aiRequest===null,thinking:context.isAiThinking,busy:attrs['aria-busy'],stopHidden:aiStop.hidden,buttonDisabled:aiButton.disabled,loading:content.innerHTML.includes('ai-loading'),focusCalls:calls.filter(value=>value==='focus').length,recovery:children[0]?.textContent,history:history.map(message=>({...message}))};
  console.log(JSON.stringify(result));
  if(baseline)continue;
  assert.equal(result.focusCalls,0,'pagehide/pageshow cannot steal focus');assert.deepEqual(history,originalHistory);assert.equal(calls.filter(value=>typeof value==='object').length,0,'pageshow never restarts AI');
  if(active){assert.equal(result.aborted,true);assert.equal(result.requestCleared,true);assert.equal(result.thinking,false);assert.equal(result.busy,undefined);assert.equal(result.stopHidden,true);assert.equal(result.buttonDisabled,false);assert.equal(result.loading,false);assert.equal(result.recovery,'Generation stopped. You can retry.');if(phase==='partial'){assert.equal(content.innerHTML,initialHTML);assert.equal(content.querySelector('#ai-streaming-target'),partial);}
    const retry=children[0].children[0];context.document.activeElement=retry;retry.listeners.click();const retryCall=calls.find(value=>typeof value==='object');assert.equal(retryCall.question,'Pending follow-up');assert.equal(retryCall.followup,true);assert.equal(retryCall.context.length,2);assert.equal(retryCall.context.at(-1).content,'Completed answer');
  }else{assert.equal(content.innerHTML,initialHTML);assert.equal(content.querySelector('.search-palette__followup-input'),draft);assert.equal(draft.value,'Keep unsubmitted draft');assert.equal(children.length,0);}
}
if(!baseline)console.log('PASS actual-source pagehide/pageshow: pending headers, retained partial, completed DOM/draft/context, no automatic AI or focus steal, retry without a duplicate question');
