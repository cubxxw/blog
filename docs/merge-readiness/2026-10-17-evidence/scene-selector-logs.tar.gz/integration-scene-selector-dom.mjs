import {createRequire} from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import vm from 'node:vm';
const rootDir=process.cwd(),require=createRequire(path.join(rootDir,'package.json'));
const {JSDOM}=require('jsdom'),{parse}=require('yaml');
const read=p=>fs.readFileSync(path.join(rootDir,p),'utf8');
const contextPath='/private/tmp/ai-test-blog-merge-20261017.Eka6IH/ci-c520-selected/browser/legacy/results/space-cafe-details-contrac-d850e--through-the-live-workspace-desktop/error-context.md';
const context=fs.readFileSync(contextPath,'utf8'),template=read('layouts/partials/space/cafe.html'),controller=read('assets/js/space/cafe.js'),spec=read('tests/e2e/space-cafe-details-contracts.spec.ts');
// The context truncates the last attribute. Retain its entire complete prefix,
// including the actual root tag/class/runtime cafe-theme, and discard only the
// incomplete data-world-maple-trees tail. The real dialog is parsed unchanged.
const actualRootPrefix=context.match(/1\) (<section[^\n]+)/)[1].split(' data-world-maple-trees=')[0];
const actualButton=context.match(/2\) (<button[^\n]*?<\/button>)/)[1];
const dialogHTML=template.match(/<dialog\b[^>]*data-cafe-dialog[\s\S]*?<\/dialog>/)[0];
const dom=new JSDOM(`${actualRootPrefix}>${dialogHTML}</section>`),document=dom.window.document,root=document.querySelector('[data-bear-workspace]');
assert.ok(root);assert.equal(root.tagName,'SECTION');assert.equal(root.dataset.cafeTheme,'zen');
assert.equal(document.querySelectorAll('[data-cafe-dialog]').length,1);
const dialog=root.querySelector('[data-cafe-dialog]'),choices=dialog.querySelector('[data-cafe-choices]'),pickerStatus=dialog.querySelector('[data-cafe-picker-status]');
assert.ok(choices);assert.ok(pickerStatus);dialog.showModal=()=>dialog.setAttribute('open','');
const themes=parse(read('data/space_cafe.yml')).themes.map(scene=>({id:scene.id,name:scene.name_zh,note:scene.note_zh}));
const openSource=controller.slice(controller.indexOf('  function openPicker(source){'),controller.indexOf('  async function inspect(kind,source){'));
vm.runInNewContext(`let trigger;let theme='zen';${openSource};openPicker(null);`,{document,dialog,choices,pickerStatus,themes});
const contextButton=new JSDOM(actualButton).window.document.querySelector('button');
assert.equal(choices.querySelector('button[data-cafe-theme="zen"]').dataset.cafeTheme,contextButton.dataset.cafeTheme);
assert.equal(root.querySelectorAll('[data-cafe-theme="zen"]').length+Number(root.matches('[data-cafe-theme="zen"]')),2);
console.log('PASS actual failed SECTION prefix + unmodified real dialog template + original openPicker creates the reported two broad zen matches');
const match=spec.match(/for\(const id of (\[[^\]]+\])\)\{await page\.locator\('\.space-cafe__utilities \[data-cafe-picker\]'\)/);
const tested=vm.runInNewContext(match[1]);assert.deepEqual(Array.from(tested),themes.map(scene=>scene.id));
assert.ok(spec.includes("page.locator('[data-cafe-dialog]').locator(`button[data-cafe-theme=\"${id}\"]`)"));
for(const id of tested){
 root.dataset.cafeTheme=id;
 const buttons=document.querySelector('[data-cafe-dialog]').querySelectorAll(`button[data-cafe-theme="${id}"]`);
 assert.equal(document.querySelectorAll(`[data-cafe-theme="${id}"]`).length,2);
 assert.equal(buttons.length,1);assert.equal(buttons[0].tagName,'BUTTON');assert.ok(choices.contains(buttons[0]));
 console.log(`PASS ${id}: actual original picker button is unique in the real dialog while runtime root shares the state attribute`);
}
assert.equal(choices.querySelectorAll('button[data-cafe-theme]').length,6);
dom.window.close();
console.log('PASS deterministic DOM verification only; no browser, renderer, network, or production changes');
