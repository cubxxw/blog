# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: space-onboarding.spec.ts >> a cancelled read transition cannot steal a replayed café visit
- Location: tests/e2e/space-onboarding.spec.ts:45:5

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('[data-bear-workspace]')
Expected: "true"
Received: "false"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" locator('[data-bear-workspace]') with timeout 5000ms
  - waiting for locator('[data-bear-workspace]')
    8 × locator resolved to <section class="space" data-ready="true" data-theme="light" data-boot-stage="3" data-wallpaper="dawn" data-cafe-theme="zen" data-cat-state="look" data-bear-workspace="" data-world-theme="zen" data-world-frames="80" data-world-draws="104" data-cat-loaded="true" data-world-ready="true" data-cat-active="false" data-cafe-mode="desktop" data-world-objects="115" data-world-pbr-maps="21" data-product-panel="bear" data-world-travel="false" data-boot-state="complete" data-world-maple-trees="17" data-world-mode=…>…</section>
      - unexpected value "false"

```

```yaml
- region "CUBXXW OS 个人工作区":
  - region "欢迎"
  - region "文章与思考"
  - navigation "应用 Dock"
  - navigation "咖啡馆导览"
```

# Test source

```ts
  1   | import {test,expect} from '../helpers/frozen-site';
  2   | import {enterWorkspace,reserveWorldJourney} from '../helpers/space-entry';
  3   | 
  4   | test.use({channel:'chromium',launchOptions:{args:process.platform==='darwin'?['--enable-gpu','--use-angle=metal']:['--enable-unsafe-swiftshader']}});
  5   | test.beforeEach(({page})=>reserveWorldJourney(page));
  6   | const root='[data-bear-workspace]';
  7   | const room=async(page:import('@playwright/test').Page)=>{
  8   |   await expect(page.locator(root)).toHaveAttribute('data-boot-state','complete',{timeout:30000});
  9   |   await expect(page.locator(root)).toHaveAttribute('data-world-rendered-mode','roam');
  10  | };
  11  | 
  12  | test('the terminal stays visible until a real scene frame, with a direct writing escape',async({page})=>{
  13  |   let release!:()=>void;const gate=new Promise<void>(resolve=>release=resolve);
  14  |   await page.route('**/world-cafe.*.js',async route=>{await gate;await route.continue();});
  15  |   await page.goto('/zh/projects/');
  16  |   try {
  17  |     await expect(page.locator('[data-space-boot]')).toBeVisible();
  18  |     await expect(page.locator('[data-boot-skip]')).toBeDisabled();
  19  |     await expect(page.locator('[data-space-boot] a').last()).toHaveAttribute('href','/zh/articles/');
  20  |     await expect(page.locator(root)).not.toHaveAttribute('data-world-ready','true');
  21  |     expect(await page.locator('[data-space-boot]').evaluate(el=>el.scrollWidth<=el.clientWidth)).toBe(true);
  22  |   }finally{release();}
  23  |   await room(page);await expect(page.locator(root)).toHaveAttribute('data-world-ready','true');
  24  |   await expect(page.locator('[data-space-boot]')).toBeHidden();
  25  |   await expect(page.locator('[data-cafe-read]')).toBeVisible();
  26  | });
  27  | 
  28  | test('opening a seat or terrace from the workspace preserves notes and allows returning',async({page})=>{
  29  |   await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/zh/projects/');await enterWorkspace(page);
  30  |   await page.evaluate(()=>(window as unknown as {BearSpace:{execute:(n:string,a:object)=>void}}).BearSpace.execute('open',{app:'notes'}));
  31  |   await page.locator('[data-note-editor]').fill('The same private draft.');
  32  |   await page.locator('[data-note-editor]').evaluate(el=>(el as HTMLElement).dataset.instance='resident');
  33  |   for(const place of ['outside','start']){
  34  |     await page.locator('.space-world-hud__workspace [data-cafe-picker]').click();
  35  |     await page.locator(`[data-cafe-${place}]`).click();await room(page);
  36  |     await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','cafe');
  37  |     await page.locator('[data-cafe-enter]').click();
  38  |     await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  39  |     await expect(page.locator(root)).toHaveAttribute('data-world-mode','workspace');
  40  |     await expect(page.locator('[data-note-editor]')).toHaveAttribute('data-instance','resident');
  41  |     await expect(page.locator('[data-note-editor]')).toHaveValue('The same private draft.');
  42  |   }
  43  | });
  44  | 
  45  | test('a cancelled read transition cannot steal a replayed café visit',async({page})=>{
  46  |   await page.goto('/zh/projects/');await room(page);
  47  |   await page.locator('[data-cafe-read]').click();
> 48  |   await expect(page.locator(root)).toHaveAttribute('data-world-travel','true');
      |                                    ^ Error: expect(locator).toHaveAttribute(expected) failed
  49  |   await page.locator('.space-cafe__utilities [data-cafe-picker]').click();
  50  |   await page.locator('[data-cafe-replay]').click();await room(page);
  51  |   await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','cafe');
  52  |   const snapshot=await page.evaluate(()=>(window as unknown as {BearSpace:{snapshot:()=>{active:string;windows:{id:string}[]}}}).BearSpace.snapshot());
  53  |   expect(snapshot.active).not.toBe('reader');
  54  |   await expect(page.locator('[data-space-window="reader"]')).toHaveCount(0);
  55  |   await page.locator('[data-cafe-enter]').click();await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  56  | });
  57  | 
  58  | test('a completed onboarding recovers immediately after graphics context loss',async({page})=>{
  59  |   await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/zh/projects/');await room(page);
  60  |   await page.locator('.space-world__canvas').evaluate(canvas=>(canvas as HTMLCanvasElement).getContext('webgl2')!.getExtension('WEBGL_lose_context')!.loseContext());
  61  |   await expect(page.locator(root)).toHaveAttribute('data-world-failed','true');
  62  |   await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  63  |   await expect(page.locator('.space-world')).toHaveCount(0);
  64  |   await expect(page.locator('[data-space-toast]')).toBeVisible();
  65  |   await page.evaluate(()=>(window as unknown as {BearSpace:{execute:(n:string,a:object)=>void}}).BearSpace.execute('open',{app:'notes'}));
  66  |   await page.locator('[data-note-editor]').fill('Still usable after losing the GPU.');
  67  | });
  68  | 
  69  | test('module failure offers an ordinary workspace and reading link',async({page})=>{
  70  |   await page.route('**/world-cafe.*.js',route=>route.abort());
  71  |   await page.goto('/zh/projects/');await expect(page.locator(root)).toHaveAttribute('data-world-failed','true');
  72  |   await expect(page.locator('[data-boot-status]')).toContainText('仍可阅读');
  73  |   await page.locator('[data-boot-skip]').click();await expect(page.locator('[data-space-boot]')).toBeHidden();
  74  |   await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  75  |   await expect(page.locator('[data-space-menu-trigger]')).toBeVisible();
  76  | });
  77  | 
  78  | test('the optional resident can fail without blocking the room or workspace',async({page})=>{
  79  |   await page.emulateMedia({reducedMotion:'reduce'});await page.route('**/models/space/cat.glb',route=>route.abort());
  80  |   await page.goto('/zh/projects/');await room(page);await expect(page.locator(root)).toHaveAttribute('data-cat-loaded','false');
  81  |   await page.locator('[data-cafe-read]').click();await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  82  |   await expect(page.locator('[data-space-window="reader"]')).toBeVisible();
  83  | });
  84  | 
  85  | test('the resident wanders but pauses in quiet mode, dialogs, reduced motion and the workspace',async({page})=>{
  86  |   reserveWorldJourney(page);await page.goto('/zh/projects/');await room(page);
  87  |   await expect(page.locator(root)).toHaveAttribute('data-cat-loaded','true');
  88  |   const pose=()=>page.locator(root).getAttribute('data-cat-pose');const initial=await pose();
  89  |   await expect.poll(pose,{timeout:12000}).not.toBe(initial);
  90  |   await page.locator('[data-cafe-quiet]').click();await expect(page.locator(root)).toHaveAttribute('data-cat-active','false');
  91  |   const quiet=await pose();await page.waitForTimeout(400);expect(await pose()).toBe(quiet);
  92  |   const frames=await page.locator(root).getAttribute('data-world-frames');await page.waitForTimeout(200);expect(await page.locator(root).getAttribute('data-world-frames')).toBe(frames);
  93  |   await page.locator('[data-cafe-quiet]').click();
  94  |   await page.locator('.space-cafe__utilities [data-cafe-picker]').click();
  95  |   await expect(page.locator(root)).toHaveAttribute('data-cat-active','false');const modal=await pose();await page.waitForTimeout(400);expect(await pose()).toBe(modal);
  96  |   await page.locator('[data-cafe-picker-close]').click();
  97  |   await page.emulateMedia({reducedMotion:'reduce'});await expect(page.locator(root)).toHaveAttribute('data-cat-active','false');
  98  |   const reduced=await pose();await page.waitForTimeout(400);expect(await pose()).toBe(reduced);
  99  |   await page.locator('[data-cafe-enter]').click();await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  100 |   const desk=await pose();await page.waitForTimeout(400);expect(await pose()).toBe(desk);
  101 | });
  102 | 
  103 | test('a graphics failure during the reveal cannot leave an invisible modal behind',async({page})=>{
  104 |   await page.goto('/zh/projects/');
  105 |   await expect(page.locator(root)).toHaveAttribute('data-boot-state','revealing');
  106 |   await page.locator('.space-world__canvas').evaluate(canvas=>(canvas as HTMLCanvasElement).getContext('webgl2')!.getExtension('WEBGL_lose_context')!.loseContext());
  107 |   await expect(page.locator(root)).toHaveAttribute('data-world-failed','true');
  108 |   await expect(page.locator('[data-space-boot]')).toBeHidden();
  109 |   await page.keyboard.press('Control+k');await expect(page.locator('[data-space-search]')).toBeVisible();
  110 | });
  111 | 
  112 | test('graphics recovery preserves the original editor, focus and selection',async({page})=>{
  113 |   await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/zh/projects/');await enterWorkspace(page);
  114 |   await page.evaluate(()=>(window as unknown as {BearSpace:{execute:(n:string,a:object)=>void}}).BearSpace.execute('open',{app:'notes'}));
  115 |   const editor=page.locator('[data-note-editor]');await editor.click();await page.keyboard.type('A quiet draft.');
  116 |   await expect(editor).toBeFocused();
  117 |   await editor.evaluate(el=>{(el as HTMLTextAreaElement).setSelectionRange(2,7);(el as HTMLElement).dataset.instance='same';});
  118 |   await page.locator('.space-world__canvas').evaluate(canvas=>(canvas as HTMLCanvasElement).getContext('webgl2')!.getExtension('WEBGL_lose_context')!.loseContext());
  119 |   await expect(page.locator(root)).toHaveAttribute('data-world-failed','true');
  120 |   await expect(editor).toBeFocused();await expect(editor).toHaveAttribute('data-instance','same');
  121 |   expect(await editor.evaluate(el=>[(el as HTMLTextAreaElement).selectionStart,(el as HTMLTextAreaElement).selectionEnd])).toEqual([2,7]);
  122 |   await page.keyboard.type('calm');await expect(editor).toHaveValue('A calm draft.');
  123 | });
  124 | 
  125 | test('returning from a hidden Product Lab waits for readiness and restores keyboard entry',async({page})=>{
  126 |   await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/zh/projects/#product-lab');
  127 |   await expect(page.locator(root)).toHaveAttribute('data-ready','true');
  128 |   await expect(page.locator(root)).toBeHidden();
  129 |   await page.setViewportSize({width:568,height:320});
  130 |   await page.locator('.product-view-switch [data-product-view-button="bear"]').click();
  131 |   await expect(page.locator(root)).toHaveAttribute('data-world-rendered-mode','workspace');
  132 |   await expect(page.locator('[data-space-menu-trigger]')).toBeFocused();
  133 |   await page.keyboard.press('Enter');await expect(page.locator('.space-menu')).toBeVisible();
  134 | });
  135 | 
```