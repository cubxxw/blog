# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: p1-p2-ux.spec.ts >> P1-P2 UX regression >> a pending knowledge mount cannot clear an immediate reopen or a later BEAR view
- Location: tests/e2e/p1-p2-ux.spec.ts:342:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: expect(locator).toBeVisible() failed

Locator:  locator('[data-bear-workspace]')
Expected: visible
Received: undefined

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=e2]:
    - generic [ref=e3]:
      - heading "空间 · CUBXXW OS" [level=1] [ref=e4]
      - paragraph [ref=e5]: CUBXXW OS 工作区
      - region "CUBXXW OS 个人工作区" [ref=e6]:
        - generic [ref=e7]:
          - generic "三维咖啡馆。WASD 或方向键行走，拖动看四周。" [ref=e8]
          - generic "CUBXXW OS" [ref=e9]:
            - region "欢迎" [ref=e10]:
              - generic [ref=e11]:
                - generic [ref=e12]:
                  - button "关闭窗口" [ref=e13] [cursor=pointer]: ×
                  - button "最小化窗口" [ref=e14] [cursor=pointer]: −
                  - button "最大化或恢复窗口" [ref=e15] [cursor=pointer]: +
                - strong: 欢迎
                - button "窗口概览" [ref=e16] [cursor=pointer]: ◫
              - article [ref=e18]:
                - generic [ref=e19]:
                  - generic [ref=e20]: Xinwei Xiong / cubxxw
                  - button "关于我 ↗" [ref=e21] [cursor=pointer]
                - group [ref=e22]:
                  - generic "个人介绍与经历" [ref=e23] [cursor=pointer]:
                    - text: 个人介绍与经历
                    - generic [aria-hidden] [ref=e24]: ↗
                  - generic [ref=e25]:
                    - navigation "个人介绍目录" [ref=e26]:
                      - button "个人档案" [ref=e27] [cursor=pointer]
                      - button "这些年" [ref=e28] [cursor=pointer]
                      - button "阅读地图" [ref=e29] [cursor=pointer]
                    - generic [ref=e30]:
                      - paragraph [ref=e31]: CUBXXW / PROFILE
                      - heading "熊鑫伟 cubxxw" [level=3] [ref=e32]
                      - paragraph [ref=e33]: 熊鑫伟（cubxxw / BEAR，2001 年生）构建 AI 产品，关注 Agent 评估与可靠执行。曾参与 OpenIM 的工程和社区协作，在 cubxxw.com 公开项目实践与每月思考，旅行仍是生活的一部分。
                      - paragraph [ref=e34]: 更了解自己，更了解世界。
                      - generic [ref=e35]:
                        - link "简历与项目证据 ↗" [ref=e36] [cursor=pointer]:
                          - /url: https://resume.cubxxw.com
                        - link "GitHub ↗" [ref=e37] [cursor=pointer]:
                          - /url: https://github.com/cubxxw
                        - button "联系我 ↗" [ref=e38] [cursor=pointer]
                      - group [ref=e39]:
                        - generic "完整履历与公开资料" [ref=e40] [cursor=pointer]
                    - generic [ref=e41]:
                      - paragraph [ref=e42]: CUBXXW / ALONG THE WAY
                      - heading "这些年" [level=3] [ref=e43]
                      - list [ref=e44]:
                        - listitem [ref=e45]:
                          - time [ref=e46]: "2021"
                          - generic [ref=e47]:
                            - heading "第一篇博客" [level=4] [ref=e48]
                            - paragraph [ref=e49]: 注册了 GitHub，写下第一篇博客，开始公开自己的笔记。
                            - group [ref=e50]:
                              - generic "多一点细节" [ref=e51] [cursor=pointer]
                            - link "阅读《我的第一个博客》 ↗" [ref=e52] [cursor=pointer]:
                              - /url: /zh/growth/posts/my-first-blog/
                        - listitem [ref=e53]:
                          - time [ref=e54]: "2023"
                          - generic [ref=e55]:
                            - heading "OpenIM 与开源社区" [level=4] [ref=e56]
                            - paragraph [ref=e57]: 进入 OpenIM 实习，贡献代码，设计并主持社区双周会。
                            - group [ref=e58]:
                              - generic "多一点细节" [ref=e59] [cursor=pointer]
                            - link "阅读 2023 年度总结 ↗" [ref=e60] [cursor=pointer]:
                              - /url: /zh/growth/posts/2023-annual-summary-reflections-and-aspirations/
                        - listitem [ref=e61]:
                          - time [ref=e62]: "2024"
                          - generic [ref=e63]:
                            - heading "毕业，出发" [level=4] [ref=e64]
                            - paragraph [ref=e65]: 第一次出国、毕业、工作，再离职，开始一边旅行一边构建。
                            - group [ref=e66]:
                              - generic "多一点细节" [ref=e67] [cursor=pointer]
                            - link "阅读 2024 年度回顾 ↗" [ref=e68] [cursor=pointer]:
                              - /url: /zh/growth/posts/2024-annual-review/
                        - listitem [ref=e69]:
                          - time [ref=e70]: "2025"
                          - generic [ref=e71]:
                            - heading "尼泊尔 ACT" [level=4] [ref=e72]
                            - paragraph [ref=e73]: 走完第一次高原徒步。从 2 月起，开始每月写思考笔记。
                            - group [ref=e74]:
                              - generic "多一点细节" [ref=e75] [cursor=pointer]
                            - link "阅读 2025-2026 年度总结 ↗" [ref=e76] [cursor=pointer]:
                              - /url: /zh/growth/posts/2025-annual-review/
                        - listitem [ref=e77]:
                          - time [ref=e78]: "2026"
                          - generic [ref=e79]:
                            - heading "产品和新的工作" [level=4] [ref=e80]
                            - paragraph [ref=e81]: 继续做产品、写作。8 月 10 日，结束约两年的空窗，开始新的工作。
                            - group [ref=e82]:
                              - generic "多一点细节" [ref=e83] [cursor=pointer]
                            - link "阅读《不会让恐惧替我做决定》 ↗" [ref=e84] [cursor=pointer]:
                              - /url: /zh/growth/posts/2026-08-10-fear-does-not-decide-for-me/
                    - generic [ref=e85]:
                      - paragraph [ref=e86]: CUBXXW / READING PATHS
                      - group [ref=e88]:
                        - generic "想读我的文字？ 展开四条精选阅读路径" [ref=e89] [cursor=pointer]:
                          - text: 想读我的文字？
                          - generic [ref=e90]: 展开四条精选阅读路径
            - navigation "应用 Dock" [ref=e94]:
              - button "CUBXXW OS 空间菜单" [active] [ref=e95] [cursor=pointer]:
                - generic: CUBXXW OS
              - button "欢迎" [ref=e100] [cursor=pointer]
              - button "文章与思考" [ref=e108] [cursor=pointer]
              - button "产品" [ref=e114] [cursor=pointer]
              - button "旅途相册" [ref=e121] [cursor=pointer]
              - button "你的笔记" [ref=e128] [cursor=pointer]
              - button "空间助手" [ref=e134] [cursor=pointer]
              - button "工作区设置" [ref=e140] [cursor=pointer]
        - navigation "咖啡馆导览":
          - generic:
            - button "回到咖啡馆" [ref=e146] [cursor=pointer]: ← 回到咖啡馆
            - generic: CUBXXW OS
            - button "换个风景" [ref=e147] [cursor=pointer]: 换个风景 ↗
      - text: ← 01 02 03 04 05 06 07 08
```

# Test source

```ts
  263 |       const before = await snapshot();
  264 |       await page.locator('[data-set-language="en"]').click();
  265 |       if (blocked === 'local') {
  266 |         await expect(page).toHaveURL(/\/zh\/projects\/\?profile=about#identity$/);
  267 |         await expect(workspace.locator('[data-space-toast]')).toContainText('导出');
  268 |       } else {
  269 |         await expect(page).toHaveURL(/\/projects\/\?profile=about#identity$/);
  270 |         await enterWorkspace(page);
  271 |         await expect(page.locator('[data-set-language="en"]')).toHaveAttribute('aria-pressed', 'true');
  272 |       }
  273 |       expect(await snapshot()).toEqual(before);
  274 |       await expect(workspace.locator('[data-space-window="settings"]')).toBeVisible();
  275 |     });
  276 |   }
  277 | 
  278 |   test('Product Lab can enter BEAR knowledge space and return without leaving lab', async ({ page }) => {
  279 |     await page.goto('/zh/projects/');
  280 |     await enterWorkspace(page);
  281 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  282 | 
  283 |     await page.locator('[data-space-menu-trigger]').click();
  284 |     await page.locator('.space-menu [data-product-view-button="lab"]').click();
  285 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  286 | 
  287 |     const host = page.locator('[data-bks-host]');
  288 |     await expect(page).toHaveURL(/#knowledge$/);
  289 |     await expect(host).toBeVisible();
  290 |     await expect(host.locator('.bks__chip').first()).toBeVisible();
  291 |     await expect(host.locator('.bks__title')).toHaveText('产品与写作如何连成一条线');
  292 |     await expect(host.getByText('BEAR 知识空间', { exact: true })).toBeVisible();
  293 |     // Ordinary page scroll stays available (no overflow lock).
  294 |     await expect(page.locator('body')).not.toHaveClass(/overflow-hidden|scroll-locked/);
  295 | 
  296 |     await page.keyboard.press('Escape');
  297 |     await expect(page).toHaveURL(/#product-lab$/);
  298 |     await expect(host).toBeHidden();
  299 |     await expect(page.locator('[data-product-panel="lab"]')).toBeVisible();
  300 |     await expect(page.getByRole('button', { name: '进入知识空间' })).toBeVisible();
  301 |   });
  302 | 
  303 |   test('an already open global search owns shortcuts above the BEAR workspace', async ({ page }) => {
  304 |     await page.goto('/zh/projects/');
  305 |     await enterWorkspace(page);
  306 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  307 |     const globalSearch=page.locator('#search-command-palette');
  308 |     const workspaceSearch=page.locator('[data-space-search]');
  309 |     for(const key of [process.platform==='darwin'?'Meta+k':'Control+k','Escape']) {
  310 |       if (await page.locator('[data-bear-workspace]').isVisible()) { await page.locator('[data-space-menu-trigger]').click(); await page.locator('.space-menu [data-product-view-button="lab"]').click(); }
  311 |       await page.locator('[data-search-trigger="nav"]').click();
  312 |       await expect(globalSearch).toBeVisible();
  313 |       await page.evaluate(()=>{location.hash='';});
  314 |       await expect(page.locator('[data-bear-workspace]')).toBeVisible();
  315 |       await globalSearch.locator('.search-palette__close').focus();
  316 |       await page.keyboard.press(key);
  317 |       await expect(globalSearch).toBeHidden();
  318 |       await expect(workspaceSearch).toBeHidden();
  319 |       await expect(page.locator('[data-space-window="welcome"]')).toBeVisible();
  320 |     }
  321 |   });
  322 | 
  323 |   test('knowledge space stays closed when the reader exits before its module loads', async ({ page }) => {
  324 |     await page.route('**/bear-knowledge-space*.js', async (route) => {
  325 |       await new Promise((resolve) => setTimeout(resolve, 500));
  326 |       await route.fallback();
  327 |     });
  328 |     await page.goto('/zh/projects/');
  329 |     await enterWorkspace(page);
  330 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  331 |     await page.locator('[data-space-menu-trigger]').click();
  332 |     await page.locator('.space-menu [data-product-view-button="lab"]').click();
  333 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  334 |     await page.keyboard.press('Escape');
  335 |     await expect(page).toHaveURL(/#product-lab$/);
  336 |     await page.waitForTimeout(700);
  337 |     await expect(page.locator('[data-bks-host]')).toBeHidden();
  338 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  339 |     await expect(page.locator('[data-bks-host] .bks__chip').first()).toBeVisible();
  340 |   });
  341 | 
  342 |   test('a pending knowledge mount cannot clear an immediate reopen or a later BEAR view', async ({ page }) => {
  343 |     await page.route('**/bear-knowledge-space*.js', async (route) => {
  344 |       await new Promise((resolve) => setTimeout(resolve, 500));
  345 |       await route.fallback();
  346 |     });
  347 |     await page.goto('/zh/projects/');
  348 |     await enterWorkspace(page);
  349 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  350 |     await page.locator('[data-space-menu-trigger]').click();
  351 |     await page.locator('.space-menu [data-product-view-button="lab"]').click();
  352 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  353 |     await page.keyboard.press('Escape');
  354 |     await expect(page).toHaveURL(/#product-lab$/);
  355 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  356 |     await expect(page.locator('[data-bks-host] .bks__chip').first()).toBeVisible();
  357 |     await expect(page.locator('[data-bks-host]')).toHaveCount(1);
  358 |     await page.locator('.bks__back').click();
  359 |     await expect(page).toHaveURL(/#product-lab$/);
  360 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  361 |     await expect(page.locator('[data-bks-host] .bks__chip').first()).toBeVisible();
  362 |     await page.getByRole('button', { name: 'CUBXXW OS', exact: true }).click();
> 363 |     await expect(page.locator('[data-bear-workspace]')).toBeVisible();
      |                                                         ^ Error: expect(locator).toBeVisible() failed
  364 |     await expect(page.locator('[data-bks-host]')).toBeHidden();
  365 |     await expect(page).not.toHaveURL(/#knowledge$/);
  366 |   });
  367 | });
  368 | 
```