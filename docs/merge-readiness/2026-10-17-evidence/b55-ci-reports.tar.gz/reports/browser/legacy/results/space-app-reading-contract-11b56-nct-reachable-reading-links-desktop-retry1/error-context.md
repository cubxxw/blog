# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: space-app-reading-contracts.spec.ts >> 1440×900 zh light products and books >> real choices retain focus, readable content and distinct reachable reading links
- Location: tests/e2e/space-app-reading-contracts.spec.ts:52:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.evaluate: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('[data-space-window="products"]').locator('.space-product__links a').nth(1)
    - locator resolved to visible <a class="" target="_blank" rel="noopener noreferrer" href="https://gettalentsignal.com/demo">测试预览 ↗</a>

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=e2]:
    - generic [ref=e3]:
      - heading "空间 · CUBXXW OS" [level=1] [ref=e4]
      - paragraph [ref=e5]: CUBXXW OS 工作区
      - region "CUBXXW OS 个人工作区" [ref=e6]:
        - generic [ref=e7]:
          - generic "三维咖啡馆。WASD 或方向键行走，拖动看四周。" [ref=e8]
          - generic "CUBXXW OS" [ref=e9]:
            - generic:
              - region "欢迎" [ref=e10]:
                - generic [ref=e11]:
                  - generic [ref=e12]:
                    - button "关闭窗口" [ref=e13] [cursor=pointer]: ×
                    - button "最小化窗口" [ref=e14] [cursor=pointer]: −
                    - button "最大化或恢复窗口" [ref=e15] [cursor=pointer]: +
                  - strong: 欢迎
                  - button "窗口并排" [ref=e16] [cursor=pointer]: ◫
                - article [ref=e18]:
                  - generic [ref=e19]:
                    - generic [ref=e20]: Xinwei Xiong / cubxxw
                    - button "关于我 ↗" [ref=e21] [cursor=pointer]
                  - group [ref=e22]:
                    - generic "个人介绍与经历" [ref=e23] [cursor=pointer]:
                      - text: 个人介绍与经历
                      - generic [aria-hidden] [ref=e24]: ↗
                    - generic [ref=e25]:
                      - navigation "个人介绍目录" [ref=e26]:
                        - button "个人档案" [ref=e27] [cursor=pointer]
                        - button "这些年" [ref=e28] [cursor=pointer]
                        - button "阅读地图" [ref=e29] [cursor=pointer]
                      - generic [ref=e30]:
                        - paragraph [ref=e31]: CUBXXW / PROFILE
                        - heading "熊鑫伟 cubxxw" [level=3] [ref=e32]
                        - paragraph [ref=e33]: 熊鑫伟（cubxxw / BEAR，2001 年生）构建 AI 产品，关注 Agent 评估与可靠执行。曾参与 OpenIM 的工程和社区协作，在 cubxxw.com 公开项目实践与每月思考，旅行仍是生活的一部分。
                        - paragraph [ref=e34]: 更了解自己，更了解世界。
                        - generic [ref=e35]:
                          - link "简历与项目证据 ↗" [ref=e36] [cursor=pointer]:
                            - /url: https://resume.cubxxw.com
                          - link "GitHub ↗" [ref=e37] [cursor=pointer]:
                            - /url: https://github.com/cubxxw
                          - button "联系我 ↗" [ref=e38] [cursor=pointer]
                        - group [ref=e39]:
                          - generic "完整履历与公开资料" [ref=e40] [cursor=pointer]
                      - generic [ref=e41]:
                        - paragraph [ref=e42]: CUBXXW / ALONG THE WAY
                        - heading "这些年" [level=3] [ref=e43]
                        - list [ref=e44]:
                          - listitem [ref=e45]:
                            - time [ref=e46]: "2021"
                            - generic [ref=e47]:
                              - heading "第一篇博客" [level=4] [ref=e48]
                              - paragraph [ref=e49]: 注册了 GitHub，写下第一篇博客，开始公开自己的笔记。
                              - group [ref=e50]:
                                - generic "多一点细节" [ref=e51] [cursor=pointer]
                              - link "阅读《我的第一个博客》 ↗" [ref=e52] [cursor=pointer]:
                                - /url: /zh/growth/posts/my-first-blog/
                          - listitem [ref=e53]:
                            - time [ref=e54]: "2023"
                            - generic [ref=e55]:
                              - heading "OpenIM 与开源社区" [level=4] [ref=e56]
                              - paragraph [ref=e57]: 进入 OpenIM 实习，贡献代码，设计并主持社区双周会。
                              - group [ref=e58]:
                                - generic "多一点细节" [ref=e59] [cursor=pointer]
                              - link "阅读 2023 年度总结 ↗" [ref=e60] [cursor=pointer]:
                                - /url: /zh/growth/posts/2023-annual-summary-reflections-and-aspirations/
                          - listitem [ref=e61]:
                            - time [ref=e62]: "2024"
                            - generic [ref=e63]:
                              - heading "毕业，出发" [level=4] [ref=e64]
                              - paragraph [ref=e65]: 第一次出国、毕业、工作，再离职，开始一边旅行一边构建。
                              - group [ref=e66]:
                                - generic "多一点细节" [ref=e67] [cursor=pointer]
                              - link "阅读 2024 年度回顾 ↗" [ref=e68] [cursor=pointer]:
                                - /url: /zh/growth/posts/2024-annual-review/
                          - listitem [ref=e69]:
                            - time [ref=e70]: "2025"
                            - generic [ref=e71]:
                              - heading "尼泊尔 ACT" [level=4] [ref=e72]
                              - paragraph [ref=e73]: 走完第一次高原徒步。从 2 月起，开始每月写思考笔记。
                              - group [ref=e74]:
                                - generic "多一点细节" [ref=e75] [cursor=pointer]
                              - link "阅读 2025-2026 年度总结 ↗" [ref=e76] [cursor=pointer]:
                                - /url: /zh/growth/posts/2025-annual-review/
                          - listitem [ref=e77]:
                            - time [ref=e78]: "2026"
                            - generic [ref=e79]:
                              - heading "产品和新的工作" [level=4] [ref=e80]
                              - paragraph [ref=e81]: 继续做产品、写作。8 月 10 日，结束约两年的空窗，开始新的工作。
                              - group [ref=e82]:
                                - generic "多一点细节" [ref=e83] [cursor=pointer]
                              - link "阅读《不会让恐惧替我做决定》 ↗" [ref=e84] [cursor=pointer]:
                                - /url: /zh/growth/posts/2026-08-10-fear-does-not-decide-for-me/
                      - generic [ref=e85]:
                        - paragraph [ref=e86]: CUBXXW / READING PATHS
                        - group [ref=e88]:
                          - generic "想读我的文字？ 展开四条精选阅读路径" [ref=e89] [cursor=pointer]:
                            - text: 想读我的文字？
                            - generic [ref=e90]: 展开四条精选阅读路径
              - region "你的笔记" [ref=e94]:
                - generic [ref=e95]:
                  - generic [ref=e96]:
                    - button "关闭窗口" [ref=e97] [cursor=pointer]: ×
                    - button "最小化窗口" [ref=e98] [cursor=pointer]: −
                    - button "最大化或恢复窗口" [ref=e99] [cursor=pointer]: +
                  - strong: 你的笔记
                  - button "窗口并排" [ref=e100] [cursor=pointer]: ◫
                - generic [ref=e102]:
                  - generic [ref=e103]:
                    - generic [ref=e104]: 属于你的笔记
                    - generic [ref=e105]:
                      - button "保存到沙盒" [ref=e106] [cursor=pointer]
                      - button "导出 .md ↗" [ref=e107] [cursor=pointer]
                  - textbox "你的笔记" [ref=e108]:
                    - /placeholder: "逛到这里，想到了什么？\n\n可以写下来，下次回来继续。"
                    - text: 同一个输入框，先读产品和书，再接着写。
                  - generic [ref=e109]:
                    - generic [ref=e110]: 仅保存在当前浏览器，不会公开
                    - generic [ref=e111]: 19 / 40000
              - region "Talent Signal" [ref=e115]:
                - generic [ref=e116]:
                  - generic [ref=e117]:
                    - button "关闭窗口" [ref=e118] [cursor=pointer]: ×
                    - button "最小化窗口" [ref=e119] [cursor=pointer]: −
                    - button "最大化或恢复窗口" [ref=e120] [cursor=pointer]: +
                  - strong: Talent Signal
                  - button "窗口并排" [ref=e121] [cursor=pointer]: ◫
                - generic [ref=e123]:
                  - complementary [ref=e124]:
                    - generic [ref=e125]:
                      - paragraph [ref=e126]: 产品目录
                      - button "Talent Signal" [pressed] [ref=e127] [cursor=pointer]
                      - button "Leafhour" [ref=e128] [cursor=pointer]
                      - button "IMStage" [ref=e129] [cursor=pointer]
                      - button "Solo Compass" [ref=e130] [cursor=pointer]
                      - button "DayPage" [ref=e131] [cursor=pointer]
                      - button "Telepace" [ref=e132] [cursor=pointer]
                      - button "Apply Agent" [ref=e133] [cursor=pointer]
                      - button "Agent Diff Guard" [ref=e134] [cursor=pointer]
                    - navigation "继续探索" [ref=e135]:
                      - button "构建笔记" [ref=e136] [cursor=pointer]
                      - button "我的书架" [ref=e137] [cursor=pointer]
                  - article [ref=e138]:
                    - paragraph [ref=e139]: 测试中
                    - heading "Talent Signal" [level=2] [ref=e140]
                    - paragraph [ref=e141]: 知道现在谁需要你，以及为什么。
                    - img "Talent Signal 首页，左侧呈现产品主张，右侧用证据关系图展示四条确认事实汇聚成一个下一步行动" [ref=e142]
                    - paragraph [ref=e143]: 面向独立猎头的关系智能工具，把关键对话变成可核对的候选人动态、证据链和一个明确下一步，同时把最终判断留给猎头。
                    - generic [ref=e144]:
                      - link "打开真实产品 ↗" [active] [ref=e145] [cursor=pointer]:
                        - /url: https://gettalentsignal.com/
                      - link "测试预览 ↗" [ref=e146] [cursor=pointer]:
                        - /url: https://gettalentsignal.com/demo
                      - link "源码 ↗" [ref=e147] [cursor=pointer]:
                        - /url: https://github.com/getyak/talent-signal
                      - button "✳ 聊聊这个产品" [ref=e148] [cursor=pointer]
                    - paragraph [ref=e149]: 当前边界：当前使用合成数据验证产品语言、审阅状态和跨端流程，还不是生产候选人数据系统。
            - navigation "应用 Dock" [ref=e153]:
              - button "CUBXXW OS 空间菜单" [ref=e154] [cursor=pointer]:
                - generic: CUBXXW OS
              - button "欢迎" [ref=e159] [cursor=pointer]
              - button "文章与思考" [ref=e167] [cursor=pointer]
              - button "产品" [ref=e173] [cursor=pointer]
              - button "旅途相册" [ref=e180] [cursor=pointer]
              - button "你的笔记" [ref=e187] [cursor=pointer]
              - button "空间助手" [ref=e193] [cursor=pointer]
              - button "工作区设置" [ref=e199] [cursor=pointer]
        - navigation "咖啡馆导览":
          - generic:
            - button "回到咖啡馆" [ref=e205] [cursor=pointer]: ← 回到咖啡馆
            - generic: CUBXXW OS
            - button "换个风景" [ref=e206] [cursor=pointer]: 换个风景 ↗
```

# Test source

```ts
  1   | import {test,expect,type Page,type Locator} from '../helpers/frozen-site';
  2   | import {enterWorkspace} from '../helpers/space-entry';
  3   | import {readFileSync} from 'node:fs';
  4   | import {parse} from 'yaml';
  5   | 
  6   | test.use({reducedMotion:'reduce',channel:'chromium',launchOptions:{args:process.platform==='darwin'?['--enable-gpu','--use-angle=metal']:['--enable-unsafe-swiftshader']}});
  7   | 
  8   | type Product={id:string,name:string,headline:string,description:string,url:string,demo:string,github:string,image:string,alt:string};
  9   | type Book={title:string,author:string,description:string,url:string};
  10  | type SourceProduct={id:string,name:string,url:string,url_zh?:string,url_en?:string,demo?:string,github?:string,headline_zh:string,headline_en:string,desc_zh:string,desc_en:string};
  11  | const sourceProducts=parse(readFileSync('data/products.yml','utf8')).products as SourceProduct[];
  12  | 
  13  | async function openApp(page:Page,app:string) {
  14  |   const dock=page.locator(`[data-space-dock] [data-open="${app}"]`);
  15  |   if(await dock.isVisible())await dock.click();
  16  |   else {
  17  |     await page.locator('[data-space-menu-trigger]').click();
  18  |     await page.locator('.space-menu [data-space-launchpad-trigger]').click();
  19  |     await page.locator(`[data-launchpad-app="${app}"]`).click();
  20  |   }
  21  |   const win=page.locator(`[data-space-window="${app}"]`);await expect(win).toBeVisible();return win;
  22  | }
  23  | const projectedFontCSS=(node:Locator)=>node.evaluate((el:HTMLElement)=>parseFloat(getComputedStyle(el).fontSize)*el.getBoundingClientRect().width/el.offsetWidth);
  24  | const fitsHorizontally=(node:Locator)=>node.evaluate(el=>el.scrollWidth<=el.clientWidth+1);
  25  | const nextFrame=(page:Page)=>page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>resolve())));
  26  | async function hit(control:Locator) {
  27  |   await control.scrollIntoViewIfNeeded();
  28  |   const box=(await control.boundingBox())!;
  29  |   expect(box.width).toBeGreaterThanOrEqual(44);expect(box.height).toBeGreaterThanOrEqual(44);
> 30  |   expect(await control.evaluate(el=>{const b=el.getBoundingClientRect();return el.contains(document.elementFromPoint(b.x+b.width/2,b.y+b.height/2));})).toBe(true);
      |                        ^ Error: locator.evaluate: Test timeout of 30000ms exceeded.
  31  |   return box;
  32  | }
  33  | async function isolatedLinkClick(page:Page,control:Locator,url:string) {
  34  |   await expect(control).toHaveAttribute('href',new URL(url,page.url()).href);
  35  |   await expect(control).toHaveAttribute('target','_blank');await expect(control).toHaveAttribute('rel',/noopener/);
  36  |   const box=await hit(control),previous=await page.evaluate(()=>(window as any).__spaceLinkClicks.length);
  37  |   await page.mouse.click(box.x+box.width/2,box.y+box.height/2);
  38  |   const clicks=await page.evaluate(()=>(window as any).__spaceLinkClicks as {href:string,target:string}[]);
  39  |   expect(clicks).toHaveLength(previous+1);expect(clicks[clicks.length-1]).toEqual({href:new URL(url,page.url()).href,target:'_blank'});
  40  | }
  41  | 
  42  | const cases=[
  43  |   {width:320,height:844,locale:'zh',theme:'light',coarse:true},
  44  |   {width:390,height:844,locale:'en',theme:'light',coarse:true},
  45  |   {width:620,height:844,locale:'zh',theme:'dark',coarse:true},
  46  |   {width:844,height:390,locale:'en',theme:'dark',coarse:true},
  47  |   {width:1440,height:900,locale:'zh',theme:'light',coarse:false},
  48  |   {width:1440,height:900,locale:'en',theme:'dark',coarse:false},
  49  | ];
  50  | for(const view of cases)test.describe(`${view.width}×${view.height} ${view.locale} ${view.theme} products and books`,()=>{
  51  |   test.use({viewport:{width:view.width,height:view.height},hasTouch:view.coarse,isMobile:view.coarse});
  52  |   test('real choices retain focus, readable content and distinct reachable reading links',async({page})=>{
  53  |     await page.goto(view.locale==='zh'?'/zh/projects/':'/projects/');await enterWorkspace(page);
  54  |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-world-ready','true');
  55  |     expect(await page.evaluate(()=>matchMedia('(pointer:coarse)').matches)).toBe(view.coarse);
  56  |     // The public theme tool only establishes this fixture's appearance;
  57  |     // settings choice focus is deliberately outside this App contract.
  58  |     await page.evaluate(theme=>(window as any).BearSpace.execute('theme',{value:theme}),view.theme);
  59  |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-theme',view.theme);
  60  |     const catalog=await page.locator('[data-space-catalog]').evaluate(el=>JSON.parse(el.textContent||'{}')) as {products:Product[],books:Book[]};
  61  |     const locale=view.locale==='zh'?'zh':'en';
  62  |     const expectedProducts=sourceProducts.map(product=>({id:product.id,name:product.name,headline:product[`headline_${locale}`],description:product[`desc_${locale}`],url:product[`url_${locale}`]||product.url,demo:product.demo||'',github:product.github||''}));
  63  |     expect(catalog.products.length).toBeGreaterThan(0);expect(catalog.products).toHaveLength(sourceProducts.length);
  64  |     expect(new Set(catalog.products.map(product=>product.id)).size).toBe(sourceProducts.length);
  65  |     expect(catalog.products.map(({id,name,headline,description,url,demo,github})=>({id,name,headline,description,url,demo,github}))).toEqual(expectedProducts);
  66  |     expect(catalog.products.find(product=>product.id==='leafhour')).toMatchObject({name:'Leafhour',url:locale==='zh'?'https://leafhour.com':'https://leafhour.com/en',demo:'https://leafhour.com/read?book=gutenberg-alice',github:'https://github.com/getyak/leafhour'});
  67  |     expect(catalog.books).toHaveLength(4);
  68  |     const notes=await openApp(page,'notes'),editor=notes.locator('[data-note-editor]');await editor.fill('同一个输入框，先读产品和书，再接着写。');
  69  |     const original=await editor.elementHandle(),products=await openApp(page,'products');
  70  |     // Capture real clicks at the document boundary so no external product,
  71  |     // bookstore or API is contacted during this offline verification.
  72  |     await page.evaluate(()=>{
  73  |       (window as any).__spaceLinkClicks=[];
  74  |       document.addEventListener('click',event=>{
  75  |         const anchor=(event.target as Element).closest<HTMLAnchorElement>('.space-product__links a,.space-book > a');
  76  |         if(anchor){event.preventDefault();(window as any).__spaceLinkClicks.push({href:anchor.href,target:anchor.target});}
  77  |       },true);
  78  |     });
  79  |     const compact=view.width<=640||view.coarse&&view.height<=420,picker=products.locator('[data-product-select]');
  80  |     const directory=products.locator('.space-product-directory');
  81  |     if(compact) {
  82  |       await expect(directory).toBeHidden();await expect(picker).toBeVisible();await expect(picker.locator('option')).toHaveCount(sourceProducts.length);
  83  |       expect(await picker.locator('option').evaluateAll(nodes=>nodes.map(n=>(n as HTMLOptionElement).value))).toEqual(catalog.products.map(p=>p.id));
  84  |     } else {await expect(directory).toBeVisible();await expect(picker).toBeHidden();await expect(directory.locator('button')).toHaveCount(sourceProducts.length);
  85  |       expect(await directory.locator('[data-select-product]').evaluateAll(nodes=>nodes.map(node=>node.getAttribute('data-select-product')))).toEqual(sourceProducts.map(product=>product.id));}
  86  |     for(let i=0;i<catalog.products.length;i++) {
  87  |       const product=catalog.products[i];
  88  |       if(compact) {
  89  |         await hit(picker);await picker.focus();
  90  |         // Home/End and ArrowDown are native select keyboard operations.
  91  |         // They also exercise reconstruction while the choice owns focus.
  92  |         if(i===0){await picker.press('End');await picker.press('Home');}else await picker.press('ArrowDown');
  93  |         await expect(picker).toHaveValue(product.id);await nextFrame(page);await expect(picker).toBeFocused();
  94  |       } else {
  95  |         const choice=directory.locator(`[data-select-product="${product.id}"]`);await hit(choice);await choice.focus();await choice.press('Space');
  96  |         await expect(choice).toHaveAttribute('aria-pressed','true');await nextFrame(page);await expect(choice).toBeFocused();
  97  |         expect(await projectedFontCSS(choice)).toBeGreaterThanOrEqual(13);
  98  |       }
  99  |       await expect(products.locator('.space-product h2')).toHaveText(product.name);
  100 |       expect(await page.evaluate(()=>(window as any).BearSpace.snapshot().windows.find((w:any)=>w.app==='products').payload)).toBe(product.id);
  101 |       const paragraphs=products.locator('.space-product > p:not(.space-product__stage):not(.space-product__boundary)');
  102 |       await expect(paragraphs.first()).toHaveText(product.headline);await expect(paragraphs.last()).toHaveText(product.description);
  103 |       expect(await projectedFontCSS(paragraphs.first())).toBeGreaterThanOrEqual(16);
  104 |       expect(await fitsHorizontally(products.locator('[data-window-body]'))).toBe(true);
  105 |       if(view.width===844&&view.height===390) {
  106 |         const body=products.locator('[data-window-body]');await body.evaluate(el=>{el.scrollTop=0;});await nextFrame(page);
  107 |         // Entry means the top of this real scroll container, before any
  108 |         // automatic image/link scrolling. Measure the projected first line.
  109 |         const entry=await body.evaluate((el:HTMLElement)=>{
  110 |           const rect=el.getBoundingClientRect(),title=el.querySelector('.space-product h2')!.getBoundingClientRect();
  111 |           const headline=el.querySelector('.space-product h2 + p')!,line=headline.getBoundingClientRect();
  112 |           return {scrollTop:el.scrollTop,bodyTop:rect.top,bodyBottom:rect.bottom,titleTop:title.top,titleBottom:title.bottom,lineTop:line.top,lineBottom:line.top+parseFloat(getComputedStyle(headline).lineHeight)*rect.height/el.offsetHeight};
  113 |         });
  114 |         expect(entry.scrollTop).toBe(0);expect(entry.titleTop).toBeGreaterThanOrEqual(entry.bodyTop);
  115 |         expect(entry.titleBottom).toBeLessThanOrEqual(entry.bodyBottom);expect(entry.lineTop).toBeGreaterThanOrEqual(entry.bodyTop);
  116 |         expect(entry.lineBottom).toBeLessThanOrEqual(entry.bodyBottom);
  117 |       }
  118 |       if(product.image) {
  119 |         const image=products.locator('.space-product__shot');await image.scrollIntoViewIfNeeded();
  120 |         await expect(image).toHaveAttribute('src',product.image);await expect(image).toHaveAttribute('alt',product.alt);
  121 |         await expect.poll(()=>image.evaluate((el:HTMLImageElement)=>el.complete&&el.naturalWidth>0)).toBe(true);
  122 |         const geometry=await image.evaluate((el:HTMLImageElement)=>({height:el.offsetHeight,width:el.offsetWidth,natural:el.naturalWidth/el.naturalHeight,fit:getComputedStyle(el).objectFit}));
  123 |         expect(geometry.height).toBeLessThanOrEqual(281);expect(geometry.fit).toBe('contain');
  124 |         expect(Math.abs((geometry.width-2)/(geometry.height-2)-geometry.natural)).toBeLessThan(.04);
  125 |       }
  126 |       const links=products.locator('.space-product__links a'),urls=[product.url,product.demo,product.github].filter(Boolean);
  127 |       await expect(links).toHaveCount(urls.length);
  128 |       if(!product.demo)await expect(products.getByRole('link',{name:view.locale==='zh'?'测试预览 ↗':'Try the demo ↗',exact:true})).toHaveCount(0);
  129 |       for(let n=0;n<urls.length;n++){expect(await projectedFontCSS(links.nth(n))).toBeGreaterThanOrEqual(13);await isolatedLinkClick(page,links.nth(n),urls[n]);}
  130 |       // The AI action is checked for reachability only; it is never invoked.
```