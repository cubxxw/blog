# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: p1-p2-ux.spec.ts >> P1-P2 UX regression >> a pending knowledge mount cannot clear an immediate reopen or a later BEAR view
- Location: tests/e2e/p1-p2-ux.spec.ts:342:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-bks-host] .bks__chip').first()
Expected: visible
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('[data-bks-host] .bks__chip').first() with timeout 5000ms
  - waiting for locator('[data-bks-host] .bks__chip').first()
  - Test timeout of 30000ms exceeded.

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - navigation:
    - link "cubxxw":
      - /url: https://cubxxw.com/zh/
    - list:
      - listitem:
        - link "文章":
          - /url: https://cubxxw.com/zh/articles/
      - listitem:
        - link "空间":
          - /url: https://cubxxw.com/zh/projects/
    - button "搜索"
    - button "Toggle theme":
      - img
      - img
    - list "Language":
      - listitem:
        - link "English":
          - /url: /projects/
          - text: EN
      - listitem: / 中
- main:
  - heading "空间 · CUBXXW OS" [level=1]
  - navigation "选择产品视图":
    - button "CUBXXW OS"
    - button "Product Lab" [pressed]
  - paragraph: Product Lab
  - region "空间 · CUBXXW OS"
- contentinfo:
  - text: © 2026
  - link "熊鑫伟（cubxxw）· 公开的实践与思想档案":
    - /url: https://cubxxw.com/zh/
```

# Test source

```ts
  256 |       await page.goto('/zh/projects/?profile=about#identity');
  257 |       const workspace = page.locator('[data-bear-workspace]');
  258 |       await expect(workspace).toHaveAttribute('data-ready', 'true');
  259 |       await enterWorkspace(page);
  260 |       await page.evaluate(() => (window as unknown as { BearSpace: { execute: (name: string, args: object) => unknown } }).BearSpace.execute('note', { text: 'Keep this private note.' }));
  261 |       await workspace.locator('[data-space-dock] [data-open="settings"]').click();
  262 |       const snapshot = () => page.evaluate(() => (window as unknown as { BearSpace: { snapshot: () => unknown } }).BearSpace.snapshot());
  263 |       const before = await snapshot();
  264 |       await page.locator('[data-set-language="en"]').click();
  265 |       if (blocked === 'local') {
  266 |         await expect(page).toHaveURL(/\/zh\/projects\/\?profile=about#identity$/);
  267 |         await expect(workspace.locator('[data-space-toast]')).toContainText('导出');
  268 |       } else {
  269 |         await expect(page).toHaveURL(/\/projects\/\?profile=about#identity$/);
  270 |         await enterWorkspace(page);
  271 |         await expect(page.locator('[data-set-language="en"]')).toHaveAttribute('aria-pressed', 'true');
  272 |       }
  273 |       expect(await snapshot()).toEqual(before);
  274 |       await expect(workspace.locator('[data-space-window="settings"]')).toBeVisible();
  275 |     });
  276 |   }
  277 | 
  278 |   test('Product Lab can enter BEAR knowledge space and return without leaving lab', async ({ page }) => {
  279 |     await page.goto('/zh/projects/');
  280 |     await enterWorkspace(page);
  281 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  282 | 
  283 |     await page.locator('[data-space-menu-trigger]').click();
  284 |     await page.locator('.space-menu [data-product-view-button="lab"]').click();
  285 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  286 | 
  287 |     const host = page.locator('[data-bks-host]');
  288 |     await expect(page).toHaveURL(/#knowledge$/);
  289 |     await expect(host).toBeVisible();
  290 |     await expect(host.locator('.bks__chip').first()).toBeVisible();
  291 |     await expect(host.locator('.bks__title')).toHaveText('产品与写作如何连成一条线');
  292 |     await expect(host.getByText('BEAR 知识空间', { exact: true })).toBeVisible();
  293 |     // Ordinary page scroll stays available (no overflow lock).
  294 |     await expect(page.locator('body')).not.toHaveClass(/overflow-hidden|scroll-locked/);
  295 | 
  296 |     await page.keyboard.press('Escape');
  297 |     await expect(page).toHaveURL(/#product-lab$/);
  298 |     await expect(host).toBeHidden();
  299 |     await expect(page.locator('[data-product-panel="lab"]')).toBeVisible();
  300 |     await expect(page.getByRole('button', { name: '进入知识空间' })).toBeVisible();
  301 |   });
  302 | 
  303 |   test('an already open global search owns shortcuts above the BEAR workspace', async ({ page }) => {
  304 |     await page.goto('/zh/projects/');
  305 |     await enterWorkspace(page);
  306 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  307 |     const globalSearch=page.locator('#search-command-palette');
  308 |     const workspaceSearch=page.locator('[data-space-search]');
  309 |     for(const key of [process.platform==='darwin'?'Meta+k':'Control+k','Escape']) {
  310 |       if (await page.locator('[data-bear-workspace]').isVisible()) { await page.locator('[data-space-menu-trigger]').click(); await page.locator('.space-menu [data-product-view-button="lab"]').click(); }
  311 |       await page.locator('[data-search-trigger="nav"]').click();
  312 |       await expect(globalSearch).toBeVisible();
  313 |       await page.evaluate(()=>{location.hash='';});
  314 |       await expect(page.locator('[data-bear-workspace]')).toBeVisible();
  315 |       await globalSearch.locator('.search-palette__close').focus();
  316 |       await page.keyboard.press(key);
  317 |       await expect(globalSearch).toBeHidden();
  318 |       await expect(workspaceSearch).toBeHidden();
  319 |       await expect(page.locator('[data-space-window="welcome"]')).toBeVisible();
  320 |     }
  321 |   });
  322 | 
  323 |   test('knowledge space stays closed when the reader exits before its module loads', async ({ page }) => {
  324 |     await page.route('**/bear-knowledge-space*.js', async (route) => {
  325 |       await new Promise((resolve) => setTimeout(resolve, 500));
  326 |       await route.fallback();
  327 |     });
  328 |     await page.goto('/zh/projects/');
  329 |     await enterWorkspace(page);
  330 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  331 |     await page.locator('[data-space-menu-trigger]').click();
  332 |     await page.locator('.space-menu [data-product-view-button="lab"]').click();
  333 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  334 |     await page.keyboard.press('Escape');
  335 |     await expect(page).toHaveURL(/#product-lab$/);
  336 |     await page.waitForTimeout(700);
  337 |     await expect(page.locator('[data-bks-host]')).toBeHidden();
  338 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  339 |     await expect(page.locator('[data-bks-host] .bks__chip').first()).toBeVisible();
  340 |   });
  341 | 
  342 |   test('a pending knowledge mount cannot clear an immediate reopen or a later BEAR view', async ({ page }) => {
  343 |     await page.route('**/bear-knowledge-space*.js', async (route) => {
  344 |       await new Promise((resolve) => setTimeout(resolve, 500));
  345 |       await route.fallback();
  346 |     });
  347 |     await page.goto('/zh/projects/');
  348 |     await enterWorkspace(page);
  349 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  350 |     await page.locator('[data-space-menu-trigger]').click();
  351 |     await page.locator('.space-menu [data-product-view-button="lab"]').click();
  352 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  353 |     await page.keyboard.press('Escape');
  354 |     await expect(page).toHaveURL(/#product-lab$/);
  355 |     await page.getByRole('button', { name: '进入知识空间' }).click();
> 356 |     await expect(page.locator('[data-bks-host] .bks__chip').first()).toBeVisible();
      |                                                                      ^ Error: expect(locator).toBeVisible() failed
  357 |     await expect(page.locator('[data-bks-host]')).toHaveCount(1);
  358 |     await page.locator('.bks__back').click();
  359 |     await expect(page).toHaveURL(/#product-lab$/);
  360 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  361 |     await expect(page.locator('[data-bks-host] .bks__chip').first()).toBeVisible();
  362 |     await page.getByRole('button', { name: 'CUBXXW OS', exact: true }).click();
  363 |     await expect(page.locator('[data-bear-workspace]')).toBeVisible();
  364 |     await expect(page.locator('[data-bks-host]')).toBeHidden();
  365 |     await expect(page).not.toHaveURL(/#knowledge$/);
  366 |   });
  367 | });
  368 | 
```