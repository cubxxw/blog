# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: p1-p2-ux.spec.ts >> P1-P2 UX regression >> Space preserves work when session storage fails during a language change
- Location: tests/e2e/p1-p2-ux.spec.ts:246:9

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.getAttribute: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('[data-bear-workspace]')

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=f1e2]:
    - generic [ref=f1e3]:
      - heading "Space · CUBXXW OS" [level=1] [ref=f1e4]
      - paragraph [ref=f1e5]: CUBXXW OS workspace
      - region "CUBXXW OS personal workspace" [ref=f1e6]:
        - generic [ref=f1e7]:
          - generic "3D café. Walk with WASD or arrow keys; drag to look around." [ref=f1e8]
          - generic "CUBXXW OS" [ref=f1e9]:
            - generic:
              - region "Welcome" [ref=f1e10]:
                - generic [ref=f1e11]:
                  - generic [ref=f1e12]:
                    - button "Close window" [ref=f1e13] [cursor=pointer]: ×
                    - button "Minimize window" [ref=f1e14] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=f1e15] [cursor=pointer]: +
                  - strong: Welcome
                  - button "Arrange windows" [ref=f1e16] [cursor=pointer]: ◫
                - article [ref=f1e18]:
                  - generic [ref=f1e19]:
                    - generic [ref=f1e20]: Xinwei Xiong / cubxxw
                    - button "About me ↗" [ref=f1e21] [cursor=pointer]
                  - group [ref=f1e22]:
                    - generic "About me and my story" [ref=f1e23] [cursor=pointer]:
                      - text: About me and my story
                      - generic [aria-hidden] [ref=f1e24]: ↗
                    - generic [ref=f1e25]:
                      - navigation "Profile sections" [ref=f1e26]:
                        - button "Profile" [ref=f1e27] [cursor=pointer]
                        - button "Along the way" [ref=f1e28] [cursor=pointer]
                        - button "Reading paths" [ref=f1e29] [cursor=pointer]
                      - generic [ref=f1e30]:
                        - paragraph [ref=f1e31]: CUBXXW / PROFILE
                        - heading "Xinwei Xiong cubxxw" [level=3] [ref=f1e32]
                        - paragraph [ref=f1e33]: Xinwei Xiong (熊鑫伟, aka cubxxw / BEAR, b. 2001) builds AI products with a focus on agent evaluation and reliable execution. He contributed to OpenIM's engineering and community workflows, and writes about projects and monthly reflections at cubxxw.com. Travel remains part of his life.
                        - paragraph [ref=f1e34]: To know myself more, and to know the world more.
                        - generic [ref=f1e35]:
                          - link "Resume and project evidence ↗" [ref=f1e36] [cursor=pointer]:
                            - /url: https://resume.cubxxw.com/en/
                          - link "GitHub ↗" [ref=f1e37] [cursor=pointer]:
                            - /url: https://github.com/cubxxw
                          - button "Say hello ↗" [ref=f1e38] [cursor=pointer]
                        - group [ref=f1e39]:
                          - generic "Full biography and public records" [ref=f1e40] [cursor=pointer]
                      - generic [ref=f1e41]:
                        - paragraph [ref=f1e42]: CUBXXW / ALONG THE WAY
                        - heading "Along the way" [level=3] [ref=f1e43]
                        - list [ref=f1e44]:
                          - listitem [ref=f1e45]:
                            - time [ref=f1e46]: "2021"
                            - generic [ref=f1e47]:
                              - heading "A first blog post" [level=4] [ref=f1e48]
                              - paragraph [ref=f1e49]: I created my GitHub account and began publishing my notes.
                              - group [ref=f1e50]:
                                - generic "More of the story" [ref=f1e51] [cursor=pointer]
                              - link "Read “My First Blog” ↗" [ref=f1e52] [cursor=pointer]:
                                - /url: /growth/posts/my-first-blog/
                          - listitem [ref=f1e53]:
                            - time [ref=f1e54]: "2023"
                            - generic [ref=f1e55]:
                              - heading "OpenIM and open source" [level=4] [ref=f1e56]
                              - paragraph [ref=f1e57]: I joined OpenIM as an intern, contributed code, and hosted community meetings.
                              - group [ref=f1e58]:
                                - generic "More of the story" [ref=f1e59] [cursor=pointer]
                              - link "Read the 2023 annual review ↗" [ref=f1e60] [cursor=pointer]:
                                - /url: /growth/posts/2023-annual-summary-reflections-and-aspirations/
                          - listitem [ref=f1e61]:
                            - time [ref=f1e62]: "2024"
                            - generic [ref=f1e63]:
                              - heading "Graduation and departure" [level=4] [ref=f1e64]
                              - paragraph [ref=f1e65]: My first trip abroad, graduation, a job, then leaving to travel and build.
                              - group [ref=f1e66]:
                                - generic "More of the story" [ref=f1e67] [cursor=pointer]
                              - link "Read the 2024 annual review ↗" [ref=f1e68] [cursor=pointer]:
                                - /url: /growth/posts/2024-annual-review/
                          - listitem [ref=f1e69]:
                            - time [ref=f1e70]: "2025"
                            - generic [ref=f1e71]:
                              - heading "The Annapurna Circuit" [level=4] [ref=f1e72]
                              - paragraph [ref=f1e73]: My first high-altitude trek. From February, I began writing monthly notes.
                              - group [ref=f1e74]:
                                - generic "More of the story" [ref=f1e75] [cursor=pointer]
                              - link "Read the 2025–2026 annual review ↗" [ref=f1e76] [cursor=pointer]:
                                - /url: /growth/posts/2025-annual-review/
                          - listitem [ref=f1e77]:
                            - time [ref=f1e78]: "2026"
                            - generic [ref=f1e79]:
                              - heading "Products and a new job" [level=4] [ref=f1e80]
                              - paragraph [ref=f1e81]: I kept building and writing. On August 10, after roughly two years away, I started a new job.
                              - group [ref=f1e82]:
                                - generic "More of the story" [ref=f1e83] [cursor=pointer]
                              - link "Read the August 2026 thought notes ↗" [ref=f1e84] [cursor=pointer]:
                                - /url: /growth/posts/2026-08-thought-notes/
                      - generic [ref=f1e85]:
                        - paragraph [ref=f1e86]: CUBXXW / READING PATHS
                        - group [ref=f1e88]:
                          - generic "Want to read my writing? Open four curated reading paths" [ref=f1e89] [cursor=pointer]:
                            - text: Want to read my writing?
                            - generic [ref=f1e90]: Open four curated reading paths
              - region "Settings" [ref=f1e94]:
                - generic [ref=f1e95]:
                  - generic [ref=f1e96]:
                    - button "Close window" [ref=f1e97] [cursor=pointer]: ×
                    - button "Minimize window" [ref=f1e98] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=f1e99] [cursor=pointer]: +
                  - strong: Settings
                  - button "Arrange windows" [ref=f1e100] [cursor=pointer]: ◫
                - generic [ref=f1e102]:
                  - heading "Make this workspace yours." [level=2] [ref=f1e103]
                  - heading "Language" [level=3] [ref=f1e104]
                  - group "Interface language" [ref=f1e105]:
                    - button "中文" [ref=f1e106] [cursor=pointer]
                    - button "English" [pressed] [ref=f1e107] [cursor=pointer]:
                      - text: English
                      - generic [aria-hidden] [ref=f1e108]: ✓
                  - paragraph [ref=f1e109]: Change the language. Keep your notes and windows.
                  - heading "Café" [level=3] [ref=f1e110]
                  - group "Café" [ref=f1e111]:
                    - button "Change the scene" [ref=f1e112] [cursor=pointer]
                    - button "Back to the café" [ref=f1e113] [cursor=pointer]
                  - heading "Appearance" [level=3] [ref=f1e114]
                  - group "Appearance" [ref=f1e115]:
                    - button "Classic light" [pressed] [ref=f1e116] [cursor=pointer]
                    - button "Dark" [ref=f1e117] [cursor=pointer]
                  - heading "Desktop color" [level=3] [ref=f1e118]
                  - group "Desktop color" [ref=f1e119]:
                    - button "Classic teal" [pressed] [ref=f1e120] [cursor=pointer]
                    - button "Evening blue" [ref=f1e121] [cursor=pointer]
                    - button "Sage" [ref=f1e122] [cursor=pointer]
                  - heading "Available here" [level=3] [ref=f1e123]
                  - generic [ref=f1e124]:
                    - generic [ref=f1e125]: Windows, notes, bookmarks
                    - generic [ref=f1e126]: Saved in this browser
                  - generic [ref=f1e127]:
                    - generic [ref=f1e128]: Sign-in and cross-device sync
                    - generic [ref=f1e129]: Not connected
                  - generic [ref=f1e130]:
                    - generic [ref=f1e131]: Immich
                    - generic [ref=f1e132]: Load public content in Photos
                  - generic [ref=f1e133]:
                    - generic [ref=f1e134]: Linux sandbox
                    - generic [ref=f1e135]: Disconnected (local development only)
                  - paragraph [ref=f1e136]: The workspace remembers your layout and notes. Clearing site data removes them; export a copy first. The AI guide reads public material and does not publish or operate personal accounts.
                  - generic [ref=f1e137]:
                    - button "Export workspace" [ref=f1e138] [cursor=pointer]
                    - button "Arrange windows" [ref=f1e139] [cursor=pointer]
            - navigation "Application Dock" [ref=f1e143]:
              - button "CUBXXW OS Space menu" [ref=f1e144] [cursor=pointer]:
                - generic: CUBXXW OS
              - button "Welcome" [ref=f1e149] [cursor=pointer]
              - button "Writing" [ref=f1e157] [cursor=pointer]
              - button "Products" [ref=f1e163] [cursor=pointer]
              - button "Photos" [ref=f1e170] [cursor=pointer]
              - button "Your notes" [ref=f1e177] [cursor=pointer]
              - button "Space companion" [ref=f1e183] [cursor=pointer]
              - button "Settings" [ref=f1e189] [cursor=pointer]
        - navigation "Café navigation":
          - generic:
            - button "Back to the café" [ref=f1e195] [cursor=pointer]: ← Back to the café
            - generic: CUBXXW OS
            - button "Change the view" [ref=f1e196] [cursor=pointer]: Change the view ↗
```

# Test source

```ts
  1  | import {expect,type Page} from './frozen-site';
  2  | export async function enterWorkspace(page:Page) {
  3  |   await page.waitForFunction(()=>{const d=document.querySelector<HTMLElement>('[data-bear-workspace]')?.dataset;return d?.ready==='true'&&(d.worldFailed==='true'||(Number(d.worldFrames)>0&&!d.worldLoading&&d.bootState==='complete'));});
> 4  |   if(await page.locator('[data-bear-workspace]').getAttribute('data-world-failed')==='true'&&await page.locator('[data-boot-skip]').isVisible())await page.locator('[data-boot-skip]').click();
     |                                                  ^ Error: locator.getAttribute: Test timeout of 30000ms exceeded.
  5  |   if(await page.locator('[data-bear-workspace]').getAttribute('data-cafe-mode')==='desktop')return;
  6  |   await page.keyboard.press('Control+k');
  7  |   await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode','desktop');
  8  |   await page.locator('[data-space-search-close]').click();
  9  | }
  10 | 
```