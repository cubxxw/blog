# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: space-arrangement-contracts.spec.ts >> a 1440×900 desktop tiles 4 windows with reachable controls and the original note
- Location: tests/e2e/space-arrangement-contracts.spec.ts:76:30

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('.space-menu [data-space-launchpad-trigger]')
    - locator resolved to <button type="button" aria-haspopup="dialog" data-space-launchpad-trigger="">…</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=e2]:
    - generic [ref=e3]:
      - heading "空间 · CUBXXW OS" [level=1] [ref=e4]
      - paragraph [ref=e5]: CUBXXW OS 工作区
      - region "CUBXXW OS 个人工作区" [ref=e6]:
        - generic [ref=e7]:
          - generic "三维咖啡馆。WASD 或方向键行走，拖动看四周。" [ref=e8]
          - generic "CUBXXW OS" [ref=e9]:
            - generic:
              - region "欢迎" [ref=e10]:
                - generic [ref=e11]:
                  - generic [ref=e12]:
                    - button "关闭窗口" [ref=e13] [cursor=pointer]: ×
                    - button "最小化窗口" [ref=e14] [cursor=pointer]: −
                    - button "最大化或恢复窗口" [ref=e15] [cursor=pointer]: +
                  - strong: 欢迎
                  - button "窗口并排" [ref=e16] [cursor=pointer]: ◫
                - article [ref=e18]:
                  - generic [ref=e19]:
                    - generic [ref=e20]: Xinwei Xiong / cubxxw
                    - button "关于我 ↗" [ref=e21] [cursor=pointer]
                  - group [ref=e22]:
                    - generic "个人介绍与经历" [ref=e23] [cursor=pointer]:
                      - text: 个人介绍与经历
                      - generic [aria-hidden] [ref=e24]: ↗
                    - generic [ref=e25]:
                      - navigation "个人介绍目录" [ref=e26]:
                        - button "个人档案" [ref=e27] [cursor=pointer]
                        - button "这些年" [ref=e28] [cursor=pointer]
                        - button "阅读地图" [ref=e29] [cursor=pointer]
                      - generic [ref=e30]:
                        - paragraph [ref=e31]: CUBXXW / PROFILE
                        - heading "熊鑫伟 cubxxw" [level=3] [ref=e32]
                        - paragraph [ref=e33]: 熊鑫伟（cubxxw / BEAR，2001 年生）构建 AI 产品，关注 Agent 评估与可靠执行。曾参与 OpenIM 的工程和社区协作，在 cubxxw.com 公开项目实践与每月思考，旅行仍是生活的一部分。
                        - paragraph [ref=e34]: 更了解自己，更了解世界。
                        - generic [ref=e35]:
                          - link "简历与项目证据 ↗" [ref=e36] [cursor=pointer]:
                            - /url: https://resume.cubxxw.com
                          - link "GitHub ↗" [ref=e37] [cursor=pointer]:
                            - /url: https://github.com/cubxxw
                          - button "联系我 ↗" [ref=e38] [cursor=pointer]
                        - group [ref=e39]:
                          - generic "完整履历与公开资料" [ref=e40] [cursor=pointer]
                      - generic [ref=e41]:
                        - paragraph [ref=e42]: CUBXXW / ALONG THE WAY
                        - heading "这些年" [level=3] [ref=e43]
                        - list [ref=e44]:
                          - listitem [ref=e45]:
                            - time [ref=e46]: "2021"
                            - generic [ref=e47]:
                              - heading "第一篇博客" [level=4] [ref=e48]
                              - paragraph [ref=e49]: 注册了 GitHub，写下第一篇博客，开始公开自己的笔记。
                              - group [ref=e50]:
                                - generic "多一点细节" [ref=e51] [cursor=pointer]
                              - link "阅读《我的第一个博客》 ↗" [ref=e52] [cursor=pointer]:
                                - /url: /zh/growth/posts/my-first-blog/
                          - listitem [ref=e53]:
                            - time [ref=e54]: "2023"
                            - generic [ref=e55]:
                              - heading "OpenIM 与开源社区" [level=4] [ref=e56]
                              - paragraph [ref=e57]: 进入 OpenIM 实习，贡献代码，设计并主持社区双周会。
                              - group [ref=e58]:
                                - generic "多一点细节" [ref=e59] [cursor=pointer]
                              - link "阅读 2023 年度总结 ↗" [ref=e60] [cursor=pointer]:
                                - /url: /zh/growth/posts/2023-annual-summary-reflections-and-aspirations/
                          - listitem [ref=e61]:
                            - time [ref=e62]: "2024"
                            - generic [ref=e63]:
                              - heading "毕业，出发" [level=4] [ref=e64]
                              - paragraph [ref=e65]: 第一次出国、毕业、工作，再离职，开始一边旅行一边构建。
                              - group [ref=e66]:
                                - generic "多一点细节" [ref=e67] [cursor=pointer]
                              - link "阅读 2024 年度回顾 ↗" [ref=e68] [cursor=pointer]:
                                - /url: /zh/growth/posts/2024-annual-review/
                          - listitem [ref=e69]:
                            - time [ref=e70]: "2025"
                            - generic [ref=e71]:
                              - heading "尼泊尔 ACT" [level=4] [ref=e72]
                              - paragraph [ref=e73]: 走完第一次高原徒步。从 2 月起，开始每月写思考笔记。
                              - group [ref=e74]:
                                - generic "多一点细节" [ref=e75] [cursor=pointer]
                              - link "阅读 2025-2026 年度总结 ↗" [ref=e76] [cursor=pointer]:
                                - /url: /zh/growth/posts/2025-annual-review/
                          - listitem [ref=e77]:
                            - time [ref=e78]: "2026"
                            - generic [ref=e79]:
                              - heading "产品和新的工作" [level=4] [ref=e80]
                              - paragraph [ref=e81]: 继续做产品、写作。8 月 10 日，结束约两年的空窗，开始新的工作。
                              - group [ref=e82]:
                                - generic "多一点细节" [ref=e83] [cursor=pointer]
                              - link "阅读《不会让恐惧替我做决定》 ↗" [ref=e84] [cursor=pointer]:
                                - /url: /zh/growth/posts/2026-08-10-fear-does-not-decide-for-me/
                      - generic [ref=e85]:
                        - paragraph [ref=e86]: CUBXXW / READING PATHS
                        - group [ref=e88]:
                          - generic "想读我的文字？ 展开四条精选阅读路径" [ref=e89] [cursor=pointer]:
                            - text: 想读我的文字？
                            - generic [ref=e90]: 展开四条精选阅读路径
              - region "你的笔记" [ref=e94]:
                - generic [ref=e95]:
                  - generic [ref=e96]:
                    - button "关闭窗口" [ref=e97] [cursor=pointer]: ×
                    - button "最小化窗口" [ref=e98] [cursor=pointer]: −
                    - button "最大化或恢复窗口" [ref=e99] [cursor=pointer]: +
                  - strong: 你的笔记
                  - button "窗口并排" [ref=e100] [cursor=pointer]: ◫
                - generic [ref=e102]:
                  - generic [ref=e103]:
                    - generic [ref=e104]: 属于你的笔记
                    - generic [ref=e105]:
                      - button "保存到沙盒" [ref=e106] [cursor=pointer]
                      - button "导出 .md ↗" [ref=e107] [cursor=pointer]
                  - textbox "你的笔记" [ref=e108]:
                    - /placeholder: "逛到这里，想到了什么？\n\n可以写下来，下次回来继续。"
                    - text: 这份笔记和窗口一起保留。
                  - generic [ref=e109]:
                    - generic [ref=e110]: 仅保存在当前浏览器，不会公开
                    - generic [ref=e111]: 12 / 40000
              - region "去过的地方" [ref=e115]:
                - generic [ref=e116]:
                  - generic [ref=e117]:
                    - button "关闭窗口" [ref=e118] [cursor=pointer]: ×
                    - button "最小化窗口" [ref=e119] [cursor=pointer]: −
                    - button "最大化或恢复窗口" [ref=e120] [cursor=pointer]: +
                  - strong: 去过的地方
                  - button "窗口并排" [ref=e121] [cursor=pointer]: ◫
                - generic [ref=e123]:
                  - generic [ref=e124]:
                    - generic [ref=e125]:
                      - paragraph [ref=e126]: BEAR / PLACES & FIELD NOTES
                      - heading "从一段路，找到一个故事。" [level=2] [ref=e127]
                    - button "浏览相册 ↗" [ref=e128] [cursor=pointer]
                  - generic [ref=e129]:
                    - generic "地图：方向键移动，加减号缩放" [ref=e130]:
                      - group "公开旅行区域地图，可用下方地区列表选择" [ref=e131]:
                        - generic [ref=e133]:
                          - generic: 180°W
                          - generic: 160°W
                          - generic: 140°W
                          - generic: 120°W
                          - generic: 100°W
                          - generic: 80°W
                          - generic: 60°W
                          - generic: 40°W
                          - generic: 20°W
                          - generic: 0°E
                          - generic: 20°E
                          - generic: 40°E
                          - generic: 60°E
                          - generic: 80°E
                          - generic: 100°E
                          - generic: 120°E
                          - generic: 140°E
                          - generic: 160°E
                          - generic: 180°E
                          - generic: 60°S
                          - generic: 40°S
                          - generic: 20°S
                          - generic: 0°N
                          - generic: 20°N
                          - generic: 40°N
                          - generic: 60°N
                          - generic: 80°N
                        - generic [ref=e135]:
                          - generic: 亚洲
                          - generic: 太平洋
                          - generic: 印度洋
                        - button "西藏高原" [pressed] [ref=e136] [cursor=pointer]
                        - button "日本列岛" [ref=e139] [cursor=pointer]
                        - button "东南亚" [ref=e142] [cursor=pointer]
                    - generic "地图控制" [ref=e145]:
                      - button "放大地图" [ref=e146] [cursor=pointer]: +
                      - button "缩小地图" [ref=e147] [cursor=pointer]: −
                      - button "查看所有区域" [ref=e148] [cursor=pointer]
                      - button "世界" [ref=e149] [cursor=pointer]
                    - generic: 等距经纬投影 · 区域中心
                  - navigation "选择旅行区域" [ref=e150]:
                    - button "01 西藏高原 2 张照片" [pressed] [ref=e151] [cursor=pointer]:
                      - generic [ref=e152]: "01"
                      - strong [ref=e153]: 西藏高原
                      - generic [ref=e154]: 2 张照片
                    - button "02 日本列岛 2 张照片" [ref=e155] [cursor=pointer]:
                      - generic [ref=e156]: "02"
                      - strong [ref=e157]: 日本列岛
                      - generic [ref=e158]: 2 张照片
                    - button "03 东南亚 4 张照片" [ref=e159] [cursor=pointer]:
                      - generic [ref=e160]: "03"
                      - strong [ref=e161]: 东南亚
                      - generic [ref=e162]: 4 张照片
                  - article [ref=e163]:
                    - generic [ref=e164]:
                      - paragraph [ref=e165]: 29.65°N / 91.14°E
                      - heading "西藏高原" [level=3] [ref=e166]
                      - paragraph [ref=e167]: 海拔 3650 米，一张强制降速的地图
                      - generic [ref=e168]:
                        - generic [ref=e169]: 2 张公开照片
                        - generic [ref=e170]: 1 篇相关写作
                    - generic [ref=e171]:
                      - article [ref=e172]:
                        - button "沿着 318" [ref=e173] [cursor=pointer]:
                          - img "中国 · 川藏公路" [ref=e175]
                      - article [ref=e177]:
                        - button "风里的经幡" [ref=e178] [cursor=pointer]:
                          - img "中国 · 川西" [ref=e180]
                    - generic [ref=e182]:
                      - heading "走过之后，写了这些。" [level=4] [ref=e183]
                      - button "2026.03.27 拉萨——一座城市的慢与重" [ref=e184] [cursor=pointer]:
                        - generic [ref=e185]:
                          - generic [ref=e186]: 2026.03.27
                          - strong [ref=e187]: 拉萨——一座城市的慢与重
                        - generic [aria-hidden] [ref=e188]: ↗
                  - generic [ref=e189]:
                    - generic [ref=e190]: 标记来自已公开旅行记录，代表区域中心；不是照片 GPS。
                    - link "Natural Earth 1:110m ↗" [ref=e191] [cursor=pointer]:
                      - /url: https://www.naturalearthdata.com/about/terms-of-use/
            - navigation "应用 Dock" [ref=e195]:
              - button "CUBXXW OS 空间菜单" [expanded] [ref=e196] [cursor=pointer]:
                - generic: CUBXXW OS
              - button "欢迎" [ref=e201] [cursor=pointer]
              - button "文章与思考" [ref=e209] [cursor=pointer]
              - button "产品" [ref=e215] [cursor=pointer]
              - button "旅途相册" [ref=e222] [cursor=pointer]
              - button "你的笔记" [ref=e229] [cursor=pointer]
              - button "空间助手" [ref=e235] [cursor=pointer]
              - button "工作区设置" [ref=e241] [cursor=pointer]
            - navigation "空间菜单" [ref=e247]:
              - generic [ref=e248]:
                - strong [ref=e249]: CUBXXW OS
                - generic [ref=e250]: 去过的地方
              - button "回到咖啡馆" [active] [ref=e251] [cursor=pointer]
              - button "换个地方" [ref=e252] [cursor=pointer]
              - button "欢迎与关于我" [ref=e253] [cursor=pointer]
              - button "所有应用 ↗" [ref=e254] [cursor=pointer]:
                - text: 所有应用
                - generic [ref=e255]: ↗
              - button "搜索 ⌘ / Ctrl K" [ref=e256] [cursor=pointer]:
                - text: 搜索
                - generic [ref=e257]: ⌘ / Ctrl K
              - separator [ref=e258]
              - button "窗口概览" [ref=e259] [cursor=pointer]
              - button "窗口并排" [ref=e260] [cursor=pointer]
              - button "显示桌面" [ref=e261] [cursor=pointer]
              - separator [ref=e262]
              - button "工作区设置" [ref=e263] [cursor=pointer]
              - button "Product Lab ↗" [ref=e264] [cursor=pointer]:
                - text: Product Lab
                - generic [ref=e265]: ↗
              - link "返回博客 ↗" [ref=e266] [cursor=pointer]:
                - /url: /zh/
              - time [ref=e267]: 周六03:10
        - navigation "咖啡馆导览":
          - generic:
            - button "回到咖啡馆" [ref=e268] [cursor=pointer]: ← 回到咖啡馆
            - generic: CUBXXW OS
            - button "换个风景" [ref=e269] [cursor=pointer]: 换个风景 ↗
```

# Test source

```ts
  1  | import {test,expect,type Page,type Locator} from '../helpers/frozen-site';
  2  | import {enterWorkspace} from '../helpers/space-entry';
  3  | 
  4  | test.use({reducedMotion:'reduce',channel:'chromium',launchOptions:{args:process.platform==='darwin'?['--enable-gpu','--use-angle=metal']:['--enable-unsafe-swiftshader']}});
  5  | 
  6  | async function openApp(page:Page,app:string) {
  7  |   const dock=page.locator(`[data-space-dock] [data-open="${app}"]`);
  8  |   if(await dock.isVisible())await dock.click();
  9  |   else {
> 10 |     await page.locator('[data-space-menu-trigger]').click();await page.locator('.space-menu [data-space-launchpad-trigger]').click();
     |                                                                                                                              ^ Error: locator.click: Test timeout of 30000ms exceeded.
  11 |     await page.locator(`[data-launchpad-app="${app}"]`).click();
  12 |   }
  13 |   const win=page.locator(`[data-space-window="${app}"]`);await expect(win).toBeVisible();return win;
  14 | }
  15 | async function rectangles(page:Page) {
  16 |   return page.evaluate(()=>Object.fromEntries((window as any).BearSpace.snapshot().windows.map((win:any)=>[win.id,win.rect])));
  17 | }
  18 | async function hit(control:Locator,minimum=44) {
  19 |   const box=(await control.boundingBox())!;expect(box.width).toBeGreaterThanOrEqual(minimum);expect(box.height).toBeGreaterThanOrEqual(minimum);
  20 |   expect(await control.evaluate(el=>{const b=el.getBoundingClientRect();return el.contains(document.elementFromPoint(b.x+b.width/2,b.y+b.height/2));})).toBe(true);
  21 |   return box;
  22 | }
  23 | async function setup(page:Page,count:number,locale='zh') {
  24 |   await page.goto(locale==='zh'?'/zh/projects/':'/projects/');await enterWorkspace(page);
  25 |   await expect(page.locator('[data-space-window="welcome"]')).toHaveCount(1);
  26 |   const notes=await openApp(page,'notes'),editor=notes.locator('[data-note-editor]');await editor.fill('这份笔记和窗口一起保留。');
  27 |   const original=await editor.elementHandle();
  28 |   if(count>=3)await openApp(page,'map');if(count===4)await openApp(page,'terminal');
  29 |   await expect(page.locator('[data-space-window]')).toHaveCount(count);
  30 |   return {editor,original};
  31 | }
  32 | 
  33 | test.describe('limited landscape workspace',()=>{
  34 |   test.use({viewport:{width:844,height:390},hasTouch:true,isMobile:true});
  35 |   for(const count of [3,4])for(const locale of ['zh','en'])test(`${locale} ${count} windows use overview without rewriting their documents or geometry`,async({page})=>{
  36 |     const {editor,original}=await setup(page,count,locale),before=await rectangles(page);
  37 |     expect(await page.evaluate(()=>matchMedia('(pointer:coarse)').matches)).toBe(true);
  38 |     const active=page.locator('[data-space-window][data-active="true"]'),arrange=active.locator('[data-window-action="arrange"]');
  39 |     await expect(arrange).toHaveAttribute('aria-label',locale==='zh'?'窗口概览':'Window overview');
  40 |     await expect(arrange).toHaveAttribute('title',locale==='zh'?'窗口概览':'Window overview');await expect(arrange).toHaveAttribute('aria-haspopup','dialog');
  41 |     const box=await hit(arrange);await page.mouse.click(box.x+box.width/2,box.y+box.height/2);
  42 |     const overview=page.locator('[data-space-overview]');await expect(overview).toBeVisible();expect(await rectangles(page)).toEqual(before);
  43 |     await page.keyboard.press('Escape');await expect(arrange).toBeFocused();
  44 |     await arrange.click();const items=overview.locator('[data-overview-id]');await expect(items).toHaveCount(count);
  45 |     for(const item of await items.all()) {await item.scrollIntoViewIfNeeded();await hit(item);}
  46 |     // The fourth item scrolls inside the list; it must not carry the real
  47 |     // return control offscreen. Click coordinates without auto-scrolling it.
  48 |     const back=overview.locator('[data-space-overview-close]'),backBox=await hit(back),overviewBox=(await overview.boundingBox())!;
  49 |     expect(backBox.y).toBeGreaterThanOrEqual(overviewBox.y);expect(backBox.y+backBox.height).toBeLessThanOrEqual(overviewBox.y+overviewBox.height);
  50 |     if(count===4)expect(await overview.locator('[data-space-overview-list]').evaluate(el=>el.scrollTop)).toBeGreaterThan(0);
  51 |     await page.mouse.click(backBox.x+backBox.width/2,backBox.y+backBox.height/2);await expect(overview).toBeHidden();await expect(arrange).toBeFocused();
  52 |     await arrange.click();
  53 |     await overview.locator('[data-overview-id="notes"]').click();await expect(overview).toBeHidden();
  54 |     expect(await rectangles(page)).toEqual(before);expect(await editor.evaluate((el,previous)=>el===previous,original)).toBe(true);
  55 |     await expect(editor).toHaveValue('这份笔记和窗口一起保留。');await editor.press('End');await editor.pressSequentially('继续写。');
  56 |     await expect(editor).toHaveValue('这份笔记和窗口一起保留。继续写。');
  57 |     await page.locator('[data-space-menu-trigger]').click();
  58 |     const overviewMenu=page.locator('.space-menu [data-space-overview-trigger]');await expect(overviewMenu).toBeVisible();
  59 |     await expect(page.locator('.space-menu [data-space-arrange]')).toBeHidden();
  60 |     await overviewMenu.focus();await page.keyboard.press('ArrowDown');await expect(page.locator('[data-space-show-desktop]')).toBeFocused();
  61 |     await page.keyboard.press('Escape');
  62 |     if(count===4) {
  63 |       const terminal=await openApp(page,'terminal');await terminal.locator('[data-terminal-input]').fill('arrange');await terminal.locator('[data-terminal-input]').press('Enter');
  64 |       await expect(overview).toBeVisible();await expect(terminal.locator('[data-terminal-output]')).toContainText(locale==='zh'?'已打开窗口概览。':'Window overview opened.');
  65 |       await expect(terminal.locator('[data-terminal-output]')).not.toContainText(locale==='zh'?'窗口已并排。':'Windows arranged.');
  66 |       expect(await page.evaluate(()=>document.querySelector('[data-space-overview]')!.contains(document.activeElement))).toBe(true);
  67 |       expect(await rectangles(page)).toEqual(before);await page.keyboard.press('Escape');
  68 |     }
  69 |     expect(await page.evaluate(()=>(window as any).BearSpace.execute('arrange'))).toBe(true);await expect(overview).toBeVisible();
  70 |     expect(await rectangles(page)).toEqual(before);await page.keyboard.press('Escape');
  71 |     expect(await editor.evaluate((el,previous)=>el===previous,original)).toBe(true);
  72 |     expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBeLessThanOrEqual(844);
  73 |   });
  74 | });
  75 | 
  76 | for(const count of [2,4])test(`a 1440×900 desktop tiles ${count} windows with reachable controls and the original note`,async({page})=>{
  77 |   await page.setViewportSize({width:1440,height:900});const {editor,original}=await setup(page,count);
  78 |   const active=page.locator('[data-space-window][data-active="true"]'),arrange=active.locator('[data-window-action="arrange"]');
  79 |   await expect(arrange).toHaveAttribute('aria-label','窗口并排');await expect(arrange).not.toHaveAttribute('aria-haspopup','dialog');
  80 |   await hit(arrange,24);await arrange.click();await expect(page.locator('[data-space-overview]')).toBeHidden();
  81 |   const rects=Object.values(await rectangles(page)) as {x:number,y:number,width:number,height:number}[];
  82 |   for(const rect of rects) {
  83 |     expect(rect.x).toBeGreaterThanOrEqual(8);expect(rect.y).toBeGreaterThanOrEqual(12);
  84 |     expect(rect.width).toBeGreaterThanOrEqual(320);expect(rect.height).toBeGreaterThanOrEqual(260);
  85 |     expect(rect.x+rect.width).toBeLessThanOrEqual(1432.001);expect(rect.y+rect.height).toBeLessThanOrEqual(792.001);
  86 |   }
  87 |   for(let i=0;i<rects.length;i++)for(let j=i+1;j<rects.length;j++) {
  88 |     const a=rects[i],b=rects[j];expect(a.x+a.width+4<=b.x+.001||b.x+b.width+4<=a.x+.001||a.y+a.height+4<=b.y+.001||b.y+b.height+4<=a.y+.001).toBe(true);
  89 |   }
  90 |   for(const win of await page.locator('[data-space-window]').all())for(const button of await win.locator('[data-window-action]').all())await hit(button,24);
  91 |   expect(await editor.evaluate((el,previous)=>el===previous,original)).toBe(true);await editor.press('End');await editor.pressSequentially('继续写。');
  92 |   await expect(editor).toHaveValue('这份笔记和窗口一起保留。继续写。');
  93 |   await page.locator('[data-space-menu-trigger]').click();await expect(page.locator('.space-menu [data-space-arrange]')).toBeVisible();
  94 |   await expect(page.locator('.space-menu [data-space-arrange]')).toHaveText('窗口并排');await page.keyboard.press('Escape');
  95 |   const before=await rectangles(page);expect(await page.evaluate(()=>(window as any).BearSpace.execute('arrange'))).toBe(true);expect(await rectangles(page)).toEqual(before);
  96 | });
  97 | 
```