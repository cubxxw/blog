# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page-wayfinder.spec.ts >> Home and About reading navigation >> homepage primary routes and navigation remain usable without JavaScript
- Location: tests/e2e/page-wayfinder.spec.ts:159:7

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('.hp-entry-actions a').nth(1)
Expected: "/zh/projects/"
Received: "/zh/projects/#studio-products"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" locator('.hp-entry-actions a').nth(1) with timeout 5000ms
  - waiting for locator('.hp-entry-actions a').nth(1)
    14 × locator resolved to <a href="/zh/projects/#studio-products">…</a>
       - unexpected value "/zh/projects/#studio-products"

```

```yaml
- link "探索产品":
  - /url: /zh/projects/#studio-products
```

# Test source

```ts
  64  |   for (const route of ['/', '/about/']) {
  65  |     test(`${route} reading index leaves content unobstructed at every width`, async ({ page }) => {
  66  |       await page.emulateMedia({ reducedMotion: 'reduce' });
  67  |       for (const width of [375, 768, 1024, 1440, 1720]) {
  68  |         await page.setViewportSize({ width, height: 900 });
  69  |         await page.goto(route);
  70  |         const destination = route === '/' ? '#hp-posts' : '#blog-definition';
  71  |         await page.evaluate(selector => {
  72  |           window.scrollTo(0, scrollY + document.querySelector(selector)!.getBoundingClientRect().top + 160);
  73  |         }, destination);
  74  |         await expect.poll(() => page.evaluate(selector => {
  75  |           const nav = document.querySelector('[data-page-wayfinder]')!.getBoundingClientRect();
  76  |           const content = document.querySelector(selector)!.getBoundingClientRect();
  77  |           return nav.bottom <= 0 || nav.right <= content.left - 16;
  78  |         }, destination), { message: `The index must not cover reading content at ${width}px` }).toBe(true);
  79  |         expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  80  |         if (width === 1720) {
  81  |           await expect(page.locator('[data-page-wayfinder]')).toBeInViewport();
  82  |           expect(await page.locator('[data-page-wayfinder]').evaluate(nav => nav.getBoundingClientRect().left)).toBeGreaterThanOrEqual(16);
  83  |           const lastLink = page.locator('[data-page-wayfinder] a').last();
  84  |           await lastLink.click();
  85  |           await expect(lastLink).toHaveAttribute('aria-current', 'location');
  86  |           const target = page.locator((await lastLink.getAttribute('href'))!);
  87  |           await expect(target).toBeFocused();
  88  |           const position = await target.evaluate(section => ({
  89  |             top: section.getBoundingClientRect().top,
  90  |             atEnd: Math.abs(document.documentElement.scrollHeight - scrollY - innerHeight) < 2,
  91  |           }));
  92  |           expect(position.top < 160 || position.atEnd).toBe(true);
  93  |           expect(position.top).toBeLessThan(900 - 100);
  94  |         }
  95  |       }
  96  |     });
  97  |   }
  98  | 
  99  |   for (const prefix of ['', '/zh']) {
  100 |     for (const suffix of ['/', '/about/']) {
  101 |       test(`${prefix || 'en'}${suffix} native index, focus, and scroll position`, async ({ page }) => {
  102 |         await page.emulateMedia({ reducedMotion: 'reduce' });
  103 |         await page.goto(`${prefix}${suffix}`);
  104 |         const nav = page.locator('[data-page-wayfinder]');
  105 |         await expect(nav).toBeVisible();
  106 |         if (suffix === '/') {
  107 |           await page.locator('.hp-entry-actions a[href="#hp-posts"]').click();
  108 |           await expect(page.locator('#hp-posts')).toBeFocused();
  109 |         }
  110 |         const destination = suffix === '/' ? '#hp-projects' : '#studio-products';
  111 |         const link = nav.locator(`a[href="${destination}"]`);
  112 |         await link.click();
  113 |         await expect(page).toHaveURL(new RegExp(`${destination}$`));
  114 |         await expect(page.locator(destination)).toBeFocused();
  115 |         await expect(link).toHaveAttribute('aria-current', 'location');
  116 |         const layout = await page.evaluate((selector) => {
  117 |           const header = document.querySelector('.header-wrapper')!.getBoundingClientRect();
  118 |           const section = document.querySelector(selector)!.getBoundingClientRect();
  119 |           return { headerBottom: header.bottom, sectionTop: section.top, overflow: document.documentElement.scrollWidth > innerWidth };
  120 |         }, destination);
  121 |         expect(layout.overflow).toBe(false);
  122 |         expect(layout.sectionTop).toBeGreaterThanOrEqual(layout.headerBottom - 2);
  123 |         expect(layout.sectionTop).toBeLessThan(layout.headerBottom + 80);
  124 |         // Returning through browser history retains the native anchor semantics.
  125 |         await page.goBack();
  126 |         await expect(page).not.toHaveURL(new RegExp(`${destination}$`));
  127 |         // Natural scrolling, not only clicks, moves the reading indicator.
  128 |         await page.evaluate((selector) => {
  129 |           const target = document.querySelector(selector)!;
  130 |           const header = document.querySelector('.header-wrapper')!;
  131 |           window.scrollTo(0, scrollY + target.getBoundingClientRect().top
  132 |             - header.getBoundingClientRect().height);
  133 |         }, destination);
  134 |         await expect(link).toHaveAttribute('aria-current', 'location');
  135 |       });
  136 |     }
  137 |   }
  138 | 
  139 |   test('About deep links and Enter navigation work with ordinary motion', async ({ page }) => {
  140 |     await page.emulateMedia({ reducedMotion: 'no-preference' });
  141 |     await page.goto('/about/#studio-products');
  142 |     const nav = page.locator('[data-page-wayfinder]');
  143 |     await expect(nav.locator('a[href="#studio-products"]')).toHaveAttribute('aria-current', 'location');
  144 |     const road = nav.locator('a[href="#studio-road"]');
  145 |     await road.focus();
  146 |     await road.press('Enter');
  147 |     await expect(page).toHaveURL(/#studio-road$/);
  148 |     await expect(page.locator('#studio-road')).toBeFocused();
  149 |     await expect(road).toHaveAttribute('aria-current', 'location');
  150 |     await expect.poll(() => page.evaluate(() => {
  151 |       const top = document.querySelector('#studio-road')!.getBoundingClientRect().top;
  152 |       const header = document.querySelector('.header-wrapper')!.getBoundingClientRect();
  153 |       // The site header hides during downward scrolling; reserve its expanded
  154 |       // height so it can return without covering the destination heading.
  155 |       return top >= header.bottom - 2 && top < header.height + 80;
  156 |     })).toBe(true);
  157 |   });
  158 | 
  159 |   test('homepage primary routes and navigation remain usable without JavaScript', async ({ browser, baseURL }, testInfo) => {
  160 |     const context = await newFrozenContext(browser, { baseURL, javaScriptEnabled: false, viewport: testInfo.project.use.viewport });
  161 |     const page = await context.newPage();
  162 |     await page.goto('/zh/');
  163 |     await expect(page.locator('.hp-entry-actions a').first()).toHaveAttribute('href', '#hp-posts');
> 164 |     await expect(page.locator('.hp-entry-actions a').nth(1)).toHaveAttribute('href', '/zh/projects/');
      |                                                              ^ Error: expect(locator).toHaveAttribute(expected) failed
  165 |     await page.locator('[data-page-wayfinder] a[href="#hp-books"]').click();
  166 |     await expect(page).toHaveURL(/#hp-books$/);
  167 |     await expect(page.locator('#hp-books')).toBeVisible();
  168 |     await context.close();
  169 |   });
  170 | });
  171 | 
  172 | for (const route of ['/about/', '/zh/about/']) {
  173 |   test(`${route} a short final destination stays current at the native document boundary`, async ({ page }) => {
  174 |     await page.emulateMedia({ reducedMotion: 'reduce' });
  175 |     await page.setViewportSize({ width: 1720, height: 1100 });
  176 |     await page.goto(route);
  177 |     await page.locator('#studio-road').scrollIntoViewIfNeeded();
  178 |     const link = page.locator('[data-page-wayfinder] a[href="#identity"]');
  179 |     await link.click();
  180 |     await expect(link).toHaveAttribute('aria-current', 'location');
  181 |     await expect(page.locator('#identity')).toBeFocused();
  182 |     await expect.poll(() => page.evaluate(() => Math.abs(document.documentElement.scrollHeight - scrollY - innerHeight))).toBeLessThan(2);
  183 |     await page.evaluate(() => scrollBy({ top: -400, behavior: 'instant' }));
  184 |     await expect(link).not.toHaveAttribute('aria-current', 'location');
  185 |     await link.click();
  186 |     await expect(link).toHaveAttribute('aria-current', 'location');
  187 |     await page.evaluate(() => {
  188 |       // The page's first footer belongs to the collapsed biography. Add a
  189 |       // visible tail so the final section actually leaves the viewport.
  190 |       const footer = document.createElement('footer');
  191 |       footer.style.minHeight = '1600px';
  192 |       document.body.append(footer);
  193 |       scrollTo({ top: document.documentElement.scrollHeight, behavior: 'instant' });
  194 |     });
  195 |     await expect.poll(() => page.locator('#identity').evaluate(el => el.getBoundingClientRect().bottom)).toBeLessThan(0);
  196 |     await expect(link).not.toHaveAttribute('aria-current', 'location');
  197 |   });
  198 | }
  199 | 
```