# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: space-cafe-details-contracts.spec.ts >> six scene changes and both detail views preserve the original Notes node, draft and selection through the live workspace
- Location: tests/e2e/space-cafe-details-contracts.spec.ts:49:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('[data-bear-workspace]')
Expected: "false"
Received: ""

Call log:
  - Expect "toHaveAttribute" locator('[data-bear-workspace]') with timeout 5000ms
  - waiting for locator('[data-bear-workspace]')
  - Protocol error (Runtime.callFunctionOn): Internal server error, session closed.

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=e2]:
    - generic [ref=e3]:
      - heading "空间 · CUBXXW OS" [level=1] [ref=e4]
      - paragraph [ref=e5]: CUBXXW OS 工作区
      - region "CUBXXW OS 个人工作区" [ref=e6]:
        - generic "三维咖啡馆。WASD 或方向键行走，拖动看四周。" [active] [ref=e8]
        - generic:
          - generic:
            - link "返回博客" [ref=e9] [cursor=pointer]:
              - /url: /zh/
              - text: SPACE
              - generic [ref=e10]: CAFÉ
            - generic:
              - button "切换到英文" [ref=e11] [cursor=pointer]: EN
              - button "安静模式" [ref=e12] [cursor=pointer]
              - button "换个地方" [ref=e13] [cursor=pointer]
          - generic:
            - generic:
              - paragraph: A PLACE TO STAY A LITTLE
              - button "禅庭" [ref=e20] [cursor=pointer]:
                - generic [aria-hidden] [ref=e22]: ⌄
              - paragraph: 雨后枫树，苔石与一池静水。
            - paragraph: 不赶时间。坐一会儿。
        - navigation "咖啡馆导览":
          - generic:
            - button "看看咖啡" [ref=e23] [cursor=pointer]
            - button "逛逛书架" [ref=e24] [cursor=pointer]
            - button "看看小猫" [ref=e25] [cursor=pointer]
          - generic:
            - paragraph: 拖动看看四周，或用方向键散步。
            - button "坐下，读一篇" [ref=e26] [cursor=pointer]:
              - text: 坐下，读一篇
              - generic [aria-hidden] [ref=e27]: ↗
            - button "打开工作区" [ref=e28] [cursor=pointer]:
              - text: 打开工作区
              - generic [aria-hidden] [ref=e29]: ↗
```

# Test source

```ts
  1  | import {test,expect,type Page,type Locator} from '../helpers/frozen-site';
  2  | import {enterWorkspace} from '../helpers/space-entry';
  3  | import {readFileSync} from 'node:fs';
  4  | import {parse} from 'yaml';
  5  | 
  6  | test.use({channel:'chromium',reducedMotion:'reduce',launchOptions:{args:process.platform==='darwin'?['--enable-gpu','--use-angle=metal']:['--enable-unsafe-swiftshader']}});
  7  | const root=(page:Page)=>page.locator('[data-bear-workspace]');
  8  | const detail=(page:Page,kind:string)=>page.locator(`[data-cafe-inspect="${kind}"]`);
  9  | const exit=(page:Page)=>page.locator('[data-cafe-inspect-exit]');
  10 | const frames=(page:Page,count=2)=>page.evaluate(count=>new Promise<void>(done=>{const next=()=>--count?requestAnimationFrame(next):done();requestAnimationFrame(next);}),count);
> 11 | async function settled(page:Page,mode:string){await expect(root(page)).toHaveAttribute('data-world-mode',mode);await expect(root(page)).toHaveAttribute('data-world-rendered-mode',mode);await expect(root(page)).toHaveAttribute('data-world-travel','false');}
     |                                                                                                                                                                                                                   ^ Error: expect(locator).toHaveAttribute(expected) failed
  12 | async function ready(page:Page,lang='zh'){
  13 |   await page.goto(`${lang==='zh'?'/zh':''}/projects/`);await page.waitForFunction(()=>{const d=document.querySelector<HTMLElement>('[data-bear-workspace]')?.dataset;return d?.worldReady==='true'&&d.bootState==='complete'&&!d.worldLoading;});await settled(page,'roam');
  14 | }
  15 | async function hit(button:Locator){
  16 |   await expect(button).toBeVisible();const b=(await button.boundingBox())!;expect(b.width).toBeGreaterThanOrEqual(44);expect(b.height).toBeGreaterThanOrEqual(44);expect(await button.evaluate(el=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2));})).toBe(true);
  17 | }
  18 | async function pose(page:Page){return JSON.parse((await root(page).getAttribute('data-world-pose'))!);}
  19 | async function inspect(page:Page,kind:string){await hit(detail(page,kind));await detail(page,kind).click();await settled(page,'inspect');await expect(root(page)).toHaveAttribute('data-world-inspect',kind);await hit(exit(page));}
  20 | async function samePose(page:Page,value:unknown){await settled(page,'roam');expect(await pose(page)).toEqual(value);await expect(root(page)).not.toHaveAttribute('data-world-inspect');}
  21 | async function point(page:Page,position:number[]){
  22 |   return page.evaluate(async position=>{
  23 |     const imports=JSON.parse(document.querySelector('script[type="importmap"]')!.textContent!).imports;
  24 |     const THREE=await import(imports.three),el=document.querySelector<HTMLElement>('[data-bear-workspace]')!,p=JSON.parse(el.dataset.worldPose!),r=el.getBoundingClientRect();
  25 |     const camera=new THREE.PerspectiveCamera(p.fov,r.width/r.height,.08,220);camera.position.set(p.x,p.y,p.z);camera.rotation.set(p.pitch,p.yaw,0,'YXZ');camera.updateMatrixWorld();const v=new THREE.Vector3(...position).project(camera);return {x:r.x+(v.x+1)*r.width/2,y:r.y+(1-v.y)*r.height/2};
  26 |   },position);
  27 | }
  28 | 
  29 | for(const view of [{width:1440,height:900,lang:'zh'},{width:390,height:844,lang:'en'},{width:320,height:740,lang:'zh'}])test.describe(`${view.width}px true café detail entry`,()=>{
  30 |   test.use({viewport:{width:view.width,height:view.height},isMobile:view.width<640,hasTouch:view.width<640});
  31 |   test('the ten real source books and coffee views have reachable exits and restore their exact roam pose and native trigger',async({page})=>{
  32 |     await ready(page,view.lang);const source=parse(readFileSync('data/travel.yml','utf8')).books,books=await page.locator('[data-cafe-catalog]').evaluate(el=>JSON.parse(el.textContent!).books);
  33 |     expect(books).toEqual(source.map((b:any)=>({title:b[`title_${view.lang}`],author:b[`author_${view.lang}`],own:b.own===true,url:b.url||''})));expect(books).toHaveLength(10);
  34 |     const osBooks=await page.locator('[data-space-catalog]').evaluate(el=>JSON.parse(el.textContent!).books);expect(osBooks).toHaveLength(4);expect(osBooks.map((b:any)=>b.title)).toEqual(books.filter((b:any)=>b.own).map((b:any)=>b.title));
  35 |     await expect(root(page)).toHaveAttribute('data-world-reflection','room');const before=await pose(page);expect(before.y).toBe(1.52);expect(before.pitch).toBeGreaterThan(-.35);await inspect(page,'coffee');await expect(exit(page)).toBeFocused();await expect(page.locator('[data-cafe-inspect-coffee]')).toBeVisible();await page.keyboard.press('Escape');await samePose(page,before);await expect(detail(page,'coffee')).toBeFocused();
  36 |     await inspect(page,'books');const zoom=page.locator('[data-cafe-bookzoom]');await hit(zoom);await zoom.click();await settled(page,'inspect');await expect(root(page)).toHaveAttribute('data-world-inspect','spines');await expect(zoom).toBeFocused();await expect(zoom).toHaveAttribute('aria-pressed','true');await expect(detail(page,'books')).toHaveAttribute('aria-pressed','true');await page.keyboard.press('Escape');await samePose(page,before);await expect(detail(page,'books')).toBeFocused();await inspect(page,'books');await zoom.click();await settled(page,'inspect');await zoom.click();await settled(page,'inspect');await expect(root(page)).toHaveAttribute('data-world-inspect','books');await expect(zoom).toBeFocused();await expect(zoom).toHaveAttribute('aria-pressed','false');const list=page.locator('[data-cafe-inspect-books] ul'),toggle=page.locator('[data-cafe-booklist-toggle]');await expect(list).toBeHidden();await expect(toggle).toHaveAttribute('aria-expanded','false');await expect(toggle).toHaveAttribute('aria-controls','space-cafe-booklist');await hit(toggle);await toggle.click();await expect(toggle).toHaveAttribute('aria-expanded','true');await expect(list.locator('li strong')).toHaveText(books.map((b:any)=>b.title));await expect(list.locator('li span')).toHaveText(books.map((b:any)=>b.author));await expect(list.locator('a')).toHaveCount(0);
  37 |     for(const title of books.filter((b:any)=>b.own).map((b:any)=>b.title)){const label=list.locator('strong').filter({hasText:title}).first();await label.scrollIntoViewIfNeeded();await expect(label).toBeVisible();}
  38 |     await list.locator('li').last().scrollIntoViewIfNeeded();await expect(list.locator('li').last()).toBeVisible();await hit(exit(page));await exit(page).click();await samePose(page,before);await expect(detail(page,'books')).toBeFocused();await inspect(page,'books');await expect(list).toBeHidden();await expect(toggle).toHaveAttribute('aria-expanded','false');await exit(page).click();await samePose(page,before);expect(await root(page).evaluate(el=>el.scrollWidth<=el.clientWidth+1)).toBe(true);
  39 |   });
  40 | });
  41 | 
  42 | test('the actual cup and book raycasts enter the same detail views; a drag retains the computer hit instead of creating a click',async({page})=>{
  43 |   await page.setViewportSize({width:1440,height:900});await ready(page);const before=await pose(page),coffee=await point(page,[-.05,.865,1.3]);await page.mouse.click(coffee.x,coffee.y);await settled(page,'inspect');await expect(root(page)).toHaveAttribute('data-world-inspect','coffee');await page.keyboard.press('Escape');await samePose(page,before);await expect(page.locator('.space-world__canvas')).toBeFocused();
  44 |   const book=await point(page,[-.37,.809,1.5]);await page.mouse.click(book.x,book.y);await settled(page,'inspect');await expect(root(page)).toHaveAttribute('data-world-inspect','books');await exit(page).click();await samePose(page,before);
  45 |   const p=await pose(page),yaw=Math.atan2(-(3.65-p.x),-(-2.63-p.z)),pitch=Math.atan2(1.86-p.y,Math.hypot(3.65-p.x,-2.63-p.z)),b=(await root(page).boundingBox())!,x=b.x+b.width*.55,y=b.y+b.height*.55;
  46 |   await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x-(yaw-p.yaw)/.0035,y-(pitch-p.pitch)/.003,{steps:6});await page.mouse.up();await settled(page,'roam');const monitor=await point(page,[3.65,1.86,-2.63]);await page.mouse.click(monitor.x,monitor.y);await settled(page,'workspace');await expect(root(page)).toHaveAttribute('data-cafe-mode','desktop');
  47 | });
  48 | 
  49 | test('six scene changes and both detail views preserve the original Notes node, draft and selection through the live workspace',async({page})=>{
  50 |   await page.setViewportSize({width:1440,height:900});await ready(page);await enterWorkspace(page);await page.locator('[data-space-dock] [data-open="notes"]').click();const editor=page.locator('[data-note-editor]'),original=await editor.elementHandle(),draft='Coffee on the table.\nContinue this same notebook.';await editor.fill(draft);await editor.evaluate((el:HTMLTextAreaElement)=>el.setSelectionRange(3,18,'backward'));const selection=await editor.evaluate((el:HTMLTextAreaElement)=>[el.selectionStart,el.selectionEnd,el.selectionDirection]);
  51 |   await page.locator('.space-world-hud [data-cafe-visit]').click();await settled(page,'roam');const before=await pose(page);await inspect(page,'coffee');await exit(page).click();await samePose(page,before);await inspect(page,'books');await page.keyboard.press('Escape');await samePose(page,before);
  52 |   for(const id of ['zen','garden','coast','mountain','lake','rain']){await page.locator('.space-cafe__utilities [data-cafe-picker]').click();await page.locator(`[data-cafe-theme="${id}"]`).click();await expect(root(page)).toHaveAttribute('data-world-theme',id);await expect(page.locator('[data-cafe-dialog]')).not.toHaveAttribute('open');}
  53 |   await page.locator('[data-cafe-enter]').click();await settled(page,'workspace');expect(await editor.evaluate((el,old)=>el===old,original)).toBe(true);await expect(editor).toHaveValue(draft);expect(await editor.evaluate((el:HTMLTextAreaElement)=>[el.selectionStart,el.selectionEnd,el.selectionDirection])).toEqual(selection);
  54 | });
  55 | 
  56 | test('runtime quiet/reduce and resize settle inspection without a late focus grab or an idle render loop',async({page})=>{
  57 |   await page.setViewportSize({width:1440,height:900});await page.emulateMedia({reducedMotion:'no-preference'});await ready(page,'en');const before=await pose(page);await detail(page,'coffee').click();await expect(exit(page)).toBeFocused();const quiet=page.locator('[data-cafe-quiet]');await quiet.click();await expect(quiet).toHaveAttribute('aria-pressed','true');await settled(page,'inspect');await expect(quiet).toBeFocused();await page.setViewportSize({width:390,height:844});await frames(page);await expect(root(page)).toHaveAttribute('data-world-inspect','coffee');await expect(quiet).toBeFocused();
  58 |   await expect.poll(async()=>{const value=await root(page).getAttribute('data-world-frames');await frames(page,6);return await root(page).getAttribute('data-world-frames')===value;}).toBe(true);await page.keyboard.press('Escape');await samePose(page,before);await expect(quiet).toBeFocused();
  59 |   await quiet.click();await detail(page,'books').click();await expect(exit(page)).toBeFocused();await page.keyboard.press('Tab');const zoom=page.locator('[data-cafe-bookzoom]');await expect(zoom).toBeFocused();await zoom.press('Enter');await expect(root(page)).toHaveAttribute('data-world-inspect','spines');await expect(zoom).toBeFocused();await zoom.press('Enter');await expect(root(page)).toHaveAttribute('data-world-inspect','books');await page.keyboard.press('Tab');const toggle=page.locator('[data-cafe-booklist-toggle]');await expect(toggle).toBeFocused();await toggle.press('Enter');await expect(toggle).toHaveAttribute('aria-expanded','true');await page.keyboard.press('Tab');const list=page.locator('[data-cafe-inspect-books] ul');await expect(list).toBeFocused();await page.emulateMedia({reducedMotion:'reduce'});await settled(page,'inspect');await expect(list).toBeFocused();await page.setViewportSize({width:320,height:740});await frames(page);await expect(list).toBeFocused();await page.keyboard.press('Escape');await samePose(page,before);await expect(detail(page,'books')).toBeFocused();
  60 | });
  61 | 
  62 | test('a held then failed latte image never blocks the first room; simulated context loss restores the same Notes document',async({page})=>{
  63 |   await page.setViewportSize({width:1440,height:900});let release=()=>{},requests=0;const gate=new Promise<void>(done=>{release=done;});await page.route('**/images/space/cafe/latte-rosetta-v1.jpg',async route=>{requests++;await gate;await route.abort('failed');});
  64 |   try{await ready(page);expect(requests).toBe(1);await inspect(page,'coffee');await expect(root(page)).not.toHaveAttribute('data-world-failed');expect(Number(await root(page).getAttribute('data-world-triangles'))).toBeGreaterThan(10000);release();await frames(page);await exit(page).click();await enterWorkspace(page);await page.locator('[data-space-dock] [data-open="notes"]').click();const editor=page.locator('[data-note-editor]'),old=await editor.elementHandle();await editor.fill('This document survives a renderer failure.');await page.locator('.space-world-hud [data-cafe-visit]').click();await settled(page,'roam');await inspect(page,'books');await page.locator('.space-world__canvas').evaluate(el=>el.dispatchEvent(new Event('webglcontextlost',{cancelable:true})));await expect(root(page)).toHaveAttribute('data-world-failed','true');await expect(root(page)).toHaveAttribute('data-cafe-mode','desktop');await expect(page.locator('[data-cafe-inspect-panel]')).toBeHidden();expect(await page.locator('[data-space-window="notes"]').evaluate(el=>el.contains(document.activeElement))).toBe(true);expect(await editor.evaluate((el,old)=>el===old,old)).toBe(true);await expect(editor).toHaveValue('This document survives a renderer failure.');}
  65 |   finally{release();await page.unrouteAll({behavior:'wait'});}
  66 | });
  67 | 
```