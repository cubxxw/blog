# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: product-entry-contracts.spec.ts >> English home products section opens the actual products app in the current tab
- Location: tests/e2e/product-entry-contracts.spec.ts:11:7

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Test timeout of 30000ms exceeded
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=f1e2]:
    - generic [ref=f1e3]:
      - heading "Space · CUBXXW OS" [level=1] [ref=f1e4]
      - paragraph [ref=f1e5]: CUBXXW OS workspace
      - region "CUBXXW OS personal workspace" [ref=f1e6]:
        - generic [ref=f1e7]:
          - generic "3D café. Walk with WASD or arrow keys; drag to look around." [ref=f1e8]
          - generic "CUBXXW OS" [ref=f1e9]:
            - generic:
              - region "Welcome" [ref=f1e10]:
                - generic [ref=f1e11]:
                  - generic [ref=f1e12]:
                    - button "Close window" [ref=f1e13] [cursor=pointer]: ×
                    - button "Minimize window" [ref=f1e14] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=f1e15] [cursor=pointer]: +
                  - strong: Welcome
                  - button "Arrange windows" [ref=f1e16] [cursor=pointer]: ◫
                - article [ref=f1e18]:
                  - generic [ref=f1e19]:
                    - generic [ref=f1e20]: Xinwei Xiong / cubxxw
                    - button "About me ↗" [ref=f1e21] [cursor=pointer]
                  - group [ref=f1e22]:
                    - generic "About me and my story" [ref=f1e23] [cursor=pointer]:
                      - text: About me and my story
                      - generic [aria-hidden] [ref=f1e24]: ↗
                    - generic [ref=f1e25]:
                      - navigation "Profile sections" [ref=f1e26]:
                        - button "Profile" [ref=f1e27] [cursor=pointer]
                        - button "Along the way" [ref=f1e28] [cursor=pointer]
                        - button "Reading paths" [ref=f1e29] [cursor=pointer]
                      - generic [ref=f1e30]:
                        - paragraph [ref=f1e31]: CUBXXW / PROFILE
                        - heading "Xinwei Xiong cubxxw" [level=3] [ref=f1e32]
                        - paragraph [ref=f1e33]: Xinwei Xiong (熊鑫伟, aka cubxxw / BEAR, b. 2001) builds AI products with a focus on agent evaluation and reliable execution. He contributed to OpenIM's engineering and community workflows, and writes about projects and monthly reflections at cubxxw.com. Travel remains part of his life.
                        - paragraph [ref=f1e34]: To know myself more, and to know the world more.
                        - generic [ref=f1e35]:
                          - link "Resume and project evidence ↗" [ref=f1e36] [cursor=pointer]:
                            - /url: https://resume.cubxxw.com/en/
                          - link "GitHub ↗" [ref=f1e37] [cursor=pointer]:
                            - /url: https://github.com/cubxxw
                          - button "Say hello ↗" [ref=f1e38] [cursor=pointer]
                        - group [ref=f1e39]:
                          - generic "Full biography and public records" [ref=f1e40] [cursor=pointer]
                      - generic [ref=f1e41]:
                        - paragraph [ref=f1e42]: CUBXXW / ALONG THE WAY
                        - heading "Along the way" [level=3] [ref=f1e43]
                        - list [ref=f1e44]:
                          - listitem [ref=f1e45]:
                            - time [ref=f1e46]: "2021"
                            - generic [ref=f1e47]:
                              - heading "A first blog post" [level=4] [ref=f1e48]
                              - paragraph [ref=f1e49]: I created my GitHub account and began publishing my notes.
                              - group [ref=f1e50]:
                                - generic "More of the story" [ref=f1e51] [cursor=pointer]
                              - link "Read “My First Blog” ↗" [ref=f1e52] [cursor=pointer]:
                                - /url: /growth/posts/my-first-blog/
                          - listitem [ref=f1e53]:
                            - time [ref=f1e54]: "2023"
                            - generic [ref=f1e55]:
                              - heading "OpenIM and open source" [level=4] [ref=f1e56]
                              - paragraph [ref=f1e57]: I joined OpenIM as an intern, contributed code, and hosted community meetings.
                              - group [ref=f1e58]:
                                - generic "More of the story" [ref=f1e59] [cursor=pointer]
                              - link "Read the 2023 annual review ↗" [ref=f1e60] [cursor=pointer]:
                                - /url: /growth/posts/2023-annual-summary-reflections-and-aspirations/
                          - listitem [ref=f1e61]:
                            - time [ref=f1e62]: "2024"
                            - generic [ref=f1e63]:
                              - heading "Graduation and departure" [level=4] [ref=f1e64]
                              - paragraph [ref=f1e65]: My first trip abroad, graduation, a job, then leaving to travel and build.
                              - group [ref=f1e66]:
                                - generic "More of the story" [ref=f1e67] [cursor=pointer]
                              - link "Read the 2024 annual review ↗" [ref=f1e68] [cursor=pointer]:
                                - /url: /growth/posts/2024-annual-review/
                          - listitem [ref=f1e69]:
                            - time [ref=f1e70]: "2025"
                            - generic [ref=f1e71]:
                              - heading "The Annapurna Circuit" [level=4] [ref=f1e72]
                              - paragraph [ref=f1e73]: My first high-altitude trek. From February, I began writing monthly notes.
                              - group [ref=f1e74]:
                                - generic "More of the story" [ref=f1e75] [cursor=pointer]
                              - link "Read the 2025–2026 annual review ↗" [ref=f1e76] [cursor=pointer]:
                                - /url: /growth/posts/2025-annual-review/
                          - listitem [ref=f1e77]:
                            - time [ref=f1e78]: "2026"
                            - generic [ref=f1e79]:
                              - heading "Products and a new job" [level=4] [ref=f1e80]
                              - paragraph [ref=f1e81]: I kept building and writing. On August 10, after roughly two years away, I started a new job.
                              - group [ref=f1e82]:
                                - generic "More of the story" [ref=f1e83] [cursor=pointer]
                              - link "Read the August 2026 thought notes ↗" [ref=f1e84] [cursor=pointer]:
                                - /url: /growth/posts/2026-08-thought-notes/
                      - generic [ref=f1e85]:
                        - paragraph [ref=f1e86]: CUBXXW / READING PATHS
                        - group [ref=f1e88]:
                          - generic "Want to read my writing? Open four curated reading paths" [ref=f1e89] [cursor=pointer]:
                            - text: Want to read my writing?
                            - generic [ref=f1e90]: Open four curated reading paths
              - region "Products" [ref=f1e94]:
                - generic [ref=f1e95]:
                  - generic [ref=f1e96]:
                    - button "Close window" [ref=f1e97] [cursor=pointer]: ×
                    - button "Minimize window" [ref=f1e98] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=f1e99] [cursor=pointer]: +
                  - strong: Products
                  - button "Arrange windows" [ref=f1e100] [cursor=pointer]: ◫
                - generic [ref=f1e102]:
                  - complementary [ref=f1e103]:
                    - generic [ref=f1e104]:
                      - paragraph [ref=f1e105]: Products
                      - button "Talent Signal" [pressed] [ref=f1e106] [cursor=pointer]
                      - button "Leafhour" [ref=f1e107] [cursor=pointer]
                      - button "IMStage" [ref=f1e108] [cursor=pointer]
                      - button "Solo Compass" [ref=f1e109] [cursor=pointer]
                      - button "DayPage" [ref=f1e110] [cursor=pointer]
                      - button "Telepace" [ref=f1e111] [cursor=pointer]
                      - button "Apply Agent" [ref=f1e112] [cursor=pointer]
                      - button "Agent Diff Guard" [ref=f1e113] [cursor=pointer]
                    - navigation "Explore more" [ref=f1e114]:
                      - button "Build notes" [ref=f1e115] [cursor=pointer]
                      - button "Books" [ref=f1e116] [cursor=pointer]
                  - article [ref=f1e117]:
                    - paragraph [ref=f1e118]: In testing
                    - heading "Talent Signal" [level=2] [ref=f1e119]
                    - paragraph [ref=f1e120]: Know who needs you now, and why.
                    - img "Talent Signal homepage showing its product claim beside an evidence map where four confirmed facts converge on one next action" [ref=f1e121]
                    - paragraph [ref=f1e122]: Relationship intelligence for independent recruiters, turning meaningful conversations into reviewable momentum, source-linked evidence, and one clear next move.
                    - generic [ref=f1e123]:
                      - link "Open the product ↗" [ref=f1e124] [cursor=pointer]:
                        - /url: https://gettalentsignal.com/
                      - link "Try the demo ↗" [ref=f1e125] [cursor=pointer]:
                        - /url: https://gettalentsignal.com/demo
                      - link "Source ↗" [ref=f1e126] [cursor=pointer]:
                        - /url: https://github.com/getyak/talent-signal
                      - button "✳ Ask about this project" [ref=f1e127] [cursor=pointer]
                    - paragraph [ref=f1e128]: "Current boundary: The current foundation uses synthetic data to test product language, review states, and the cross-platform loop. It is not yet a production candidate-data system."
            - navigation "Application Dock" [ref=f1e132]:
              - button "CUBXXW OS Space menu" [ref=f1e133] [cursor=pointer]:
                - generic: CUBXXW OS
              - button "Welcome" [ref=f1e138] [cursor=pointer]
              - button "Writing" [ref=f1e146] [cursor=pointer]
              - button "Products" [ref=f1e152] [cursor=pointer]
              - button "Photos" [ref=f1e159] [cursor=pointer]
              - button "Your notes" [ref=f1e166] [cursor=pointer]
              - button "Space companion" [ref=f1e172] [cursor=pointer]
              - button "Settings" [ref=f1e178] [cursor=pointer]
        - navigation "Café navigation":
          - generic:
            - button "Back to the café" [ref=f1e184] [cursor=pointer]: ← Back to the café
            - generic: CUBXXW OS
            - button "Change the view" [ref=f1e185] [cursor=pointer]: Change the view ↗
```

# Test source

```ts
  1  | import {test,expect} from '../helpers/frozen-site';
  2  | import {enterWorkspace} from '../helpers/space-entry';
  3  | 
  4  | test.use({reducedMotion:'reduce',channel:'chromium',launchOptions:{args:process.platform==='darwin'?['--enable-gpu','--use-angle=metal']:['--enable-unsafe-swiftshader']}});
  5  | 
  6  | for(const entry of [
  7  |   {name:'Chinese home introduction',path:'/zh/',selector:'.hp-entry-actions a[href$="#studio-products"]',destination:'/zh/projects/#studio-products',label:'产品'},
  8  |   {name:'English home products section',path:'/',selector:'#hp-projects .hp-section-action',destination:'/projects/#studio-products',label:'Products'},
  9  |   {name:'Chinese shared footer',path:'/zh/engineering/posts/use-go-tools-dlv/',selector:'.sf-more[href$="#studio-products"]',destination:'/zh/projects/#studio-products',label:'产品'},
  10 | ]) {
  11 |   test(`${entry.name} opens the actual products app in the current tab`,async({page,context})=>{
  12 |     await page.setViewportSize({width:1440,height:900});await page.goto(entry.path);
  13 |     const link=page.locator(entry.selector);await expect(link).toHaveAttribute('href',entry.destination);
  14 |     expect(await link.getAttribute('target')).not.toBe('_blank');
  15 |     const pages=context.pages().length;await link.click();await expect(page).toHaveURL(entry.destination);
  16 |     await expect(page.locator('#studio-products')).toHaveCount(1);
  17 |     const space=page.locator('#studio-products[data-product-space]');await expect(space).toHaveCount(1);
  18 |     await expect(space).toHaveAttribute('data-product-view','bear');await expect(space.locator('[data-bear-workspace]')).toHaveCount(1);
  19 |     await enterWorkspace(page);
  20 |     const products=page.locator('[data-space-window="products"]');await expect(products).toBeVisible();
  21 |     await expect(products).toHaveAttribute('aria-label',entry.label);
  22 |     await expect(space.locator('[data-space-window="products"]')).toBeVisible();
> 23 |     await expect.poll(()=>products.evaluate(el=>el.contains(document.activeElement))).toBe(true);
     |                                                                                       ^ Error: expect(received).toBe(expected) // Object.is equality
  24 |     await expect(products.locator('.space-product h2')).not.toBeEmpty();
  25 |     await expect(page.locator('[data-space-dock] [data-open="products"]')).toHaveAttribute('aria-label',entry.label);
  26 |     expect(context.pages()).toHaveLength(pages);
  27 |   });
  28 | }
  29 | 
  30 | test('the unqualified Space entrance still begins in the café in both languages',async({page})=>{
  31 |   await page.setViewportSize({width:390,height:844});
  32 |   for(const path of ['/zh/projects/','/projects/']) {
  33 |     await page.goto(path);const space=page.locator('[data-bear-workspace]');
  34 |     await expect(space).toHaveAttribute('data-ready','true');
  35 |     await expect(space).toHaveAttribute('data-cafe-mode','cafe');
  36 |     await expect(page.locator('[data-space-dock]')).toBeHidden();
  37 |     await expect(page.locator('[data-space-window="products"]')).toBeHidden();
  38 |   }
  39 | });
  40 | 
```