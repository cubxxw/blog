# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: product-entry-contracts.spec.ts >> Chinese shared footer opens the actual products app in the current tab
- Location: tests/e2e/product-entry-contracts.spec.ts:11:7

# Error details

```
Error: Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=f1e2]:
    - generic [ref=f1e3]:
      - heading "空间 · CUBXXW OS" [level=1] [ref=f1e4]
      - paragraph [ref=f1e5]: CUBXXW OS 工作区
      - region "CUBXXW OS 个人工作区" [ref=f1e6]:
        - generic [ref=f1e7]:
          - generic "三维咖啡馆。WASD 或方向键行走，拖动看四周。" [ref=f1e8]
          - generic "CUBXXW OS" [ref=f1e9]:
            - generic:
              - region "欢迎" [ref=f1e10]:
                - generic [ref=f1e11]:
                  - generic [ref=f1e12]:
                    - button "关闭窗口" [ref=f1e13] [cursor=pointer]: ×
                    - button "最小化窗口" [ref=f1e14] [cursor=pointer]: −
                    - button "最大化或恢复窗口" [ref=f1e15] [cursor=pointer]: +
                  - strong: 欢迎
                  - button "窗口并排" [ref=f1e16] [cursor=pointer]: ◫
                - article [ref=f1e18]:
                  - generic [ref=f1e19]:
                    - generic [ref=f1e20]: Xinwei Xiong / cubxxw
                    - button "关于我 ↗" [ref=f1e21] [cursor=pointer]
                  - group [ref=f1e22]:
                    - generic "个人介绍与经历" [ref=f1e23] [cursor=pointer]:
                      - text: 个人介绍与经历
                      - generic [aria-hidden] [ref=f1e24]: ↗
                    - generic [ref=f1e25]:
                      - navigation "个人介绍目录" [ref=f1e26]:
                        - button "个人档案" [ref=f1e27] [cursor=pointer]
                        - button "这些年" [ref=f1e28] [cursor=pointer]
                        - button "阅读地图" [ref=f1e29] [cursor=pointer]
                      - generic [ref=f1e30]:
                        - paragraph [ref=f1e31]: CUBXXW / PROFILE
                        - heading "熊鑫伟 cubxxw" [level=3] [ref=f1e32]
                        - paragraph [ref=f1e33]: 熊鑫伟（cubxxw / BEAR，2001 年生）构建 AI 产品，关注 Agent 评估与可靠执行。曾参与 OpenIM 的工程和社区协作，在 cubxxw.com 公开项目实践与每月思考，旅行仍是生活的一部分。
                        - paragraph [ref=f1e34]: 更了解自己，更了解世界。
                        - generic [ref=f1e35]:
                          - link "简历与项目证据 ↗" [ref=f1e36] [cursor=pointer]:
                            - /url: https://resume.cubxxw.com
                          - link "GitHub ↗" [ref=f1e37] [cursor=pointer]:
                            - /url: https://github.com/cubxxw
                          - button "联系我 ↗" [ref=f1e38] [cursor=pointer]
                        - group [ref=f1e39]:
                          - generic "完整履历与公开资料" [ref=f1e40] [cursor=pointer]
                      - generic [ref=f1e41]:
                        - paragraph [ref=f1e42]: CUBXXW / ALONG THE WAY
                        - heading "这些年" [level=3] [ref=f1e43]
                        - list [ref=f1e44]:
                          - listitem [ref=f1e45]:
                            - time [ref=f1e46]: "2021"
                            - generic [ref=f1e47]:
                              - heading "第一篇博客" [level=4] [ref=f1e48]
                              - paragraph [ref=f1e49]: 注册了 GitHub，写下第一篇博客，开始公开自己的笔记。
                              - group [ref=f1e50]:
                                - generic "多一点细节" [ref=f1e51] [cursor=pointer]
                              - link "阅读《我的第一个博客》 ↗" [ref=f1e52] [cursor=pointer]:
                                - /url: /zh/growth/posts/my-first-blog/
                          - listitem [ref=f1e53]:
                            - time [ref=f1e54]: "2023"
                            - generic [ref=f1e55]:
                              - heading "OpenIM 与开源社区" [level=4] [ref=f1e56]
                              - paragraph [ref=f1e57]: 进入 OpenIM 实习，贡献代码，设计并主持社区双周会。
                              - group [ref=f1e58]:
                                - generic "多一点细节" [ref=f1e59] [cursor=pointer]
                              - link "阅读 2023 年度总结 ↗" [ref=f1e60] [cursor=pointer]:
                                - /url: /zh/growth/posts/2023-annual-summary-reflections-and-aspirations/
                          - listitem [ref=f1e61]:
                            - time [ref=f1e62]: "2024"
                            - generic [ref=f1e63]:
                              - heading "毕业，出发" [level=4] [ref=f1e64]
                              - paragraph [ref=f1e65]: 第一次出国、毕业、工作，再离职，开始一边旅行一边构建。
                              - group [ref=f1e66]:
                                - generic "多一点细节" [ref=f1e67] [cursor=pointer]
                              - link "阅读 2024 年度回顾 ↗" [ref=f1e68] [cursor=pointer]:
                                - /url: /zh/growth/posts/2024-annual-review/
                          - listitem [ref=f1e69]:
                            - time [ref=f1e70]: "2025"
                            - generic [ref=f1e71]:
                              - heading "尼泊尔 ACT" [level=4] [ref=f1e72]
                              - paragraph [ref=f1e73]: 走完第一次高原徒步。从 2 月起，开始每月写思考笔记。
                              - group [ref=f1e74]:
                                - generic "多一点细节" [ref=f1e75] [cursor=pointer]
                              - link "阅读 2025-2026 年度总结 ↗" [ref=f1e76] [cursor=pointer]:
                                - /url: /zh/growth/posts/2025-annual-review/
                          - listitem [ref=f1e77]:
                            - time [ref=f1e78]: "2026"
                            - generic [ref=f1e79]:
                              - heading "产品和新的工作" [level=4] [ref=f1e80]
                              - paragraph [ref=f1e81]: 继续做产品、写作。8 月 10 日，结束约两年的空窗，开始新的工作。
                              - group [ref=f1e82]:
                                - generic "多一点细节" [ref=f1e83] [cursor=pointer]
                              - link "阅读《不会让恐惧替我做决定》 ↗" [ref=f1e84] [cursor=pointer]:
                                - /url: /zh/growth/posts/2026-08-10-fear-does-not-decide-for-me/
                      - generic [ref=f1e85]:
                        - paragraph [ref=f1e86]: CUBXXW / READING PATHS
                        - group [ref=f1e88]:
                          - generic "想读我的文字？ 展开四条精选阅读路径" [ref=f1e89] [cursor=pointer]:
                            - text: 想读我的文字？
                            - generic [ref=f1e90]: 展开四条精选阅读路径
              - region "产品" [ref=f1e94]:
                - generic [ref=f1e95]:
                  - generic [ref=f1e96]:
                    - button "关闭窗口" [ref=f1e97] [cursor=pointer]: ×
                    - button "最小化窗口" [ref=f1e98] [cursor=pointer]: −
                    - button "最大化或恢复窗口" [ref=f1e99] [cursor=pointer]: +
                  - strong: 产品
                  - button "窗口并排" [ref=f1e100] [cursor=pointer]: ◫
                - generic [ref=f1e102]:
                  - complementary [ref=f1e103]:
                    - generic [ref=f1e104]:
                      - paragraph [ref=f1e105]: 产品目录
                      - button "Talent Signal" [pressed] [ref=f1e106] [cursor=pointer]
                      - button "Leafhour" [ref=f1e107] [cursor=pointer]
                      - button "IMStage" [ref=f1e108] [cursor=pointer]
                      - button "Solo Compass" [ref=f1e109] [cursor=pointer]
                      - button "DayPage" [ref=f1e110] [cursor=pointer]
                      - button "Telepace" [ref=f1e111] [cursor=pointer]
                      - button "Apply Agent" [ref=f1e112] [cursor=pointer]
                      - button "Agent Diff Guard" [ref=f1e113] [cursor=pointer]
                    - navigation "继续探索" [ref=f1e114]:
                      - button "构建笔记" [ref=f1e115] [cursor=pointer]
                      - button "我的书架" [ref=f1e116] [cursor=pointer]
                  - article [ref=f1e117]:
                    - paragraph [ref=f1e118]: 测试中
                    - heading "Talent Signal" [level=2] [ref=f1e119]
                    - paragraph [ref=f1e120]: 知道现在谁需要你，以及为什么。
                    - img "Talent Signal 首页，左侧呈现产品主张，右侧用证据关系图展示四条确认事实汇聚成一个下一步行动" [ref=f1e121]
                    - paragraph [ref=f1e122]: 面向独立猎头的关系智能工具，把关键对话变成可核对的候选人动态、证据链和一个明确下一步，同时把最终判断留给猎头。
                    - generic [ref=f1e123]:
                      - link "打开真实产品 ↗" [ref=f1e124] [cursor=pointer]:
                        - /url: https://gettalentsignal.com/
                      - link "测试预览 ↗" [ref=f1e125] [cursor=pointer]:
                        - /url: https://gettalentsignal.com/demo
                      - link "源码 ↗" [ref=f1e126] [cursor=pointer]:
                        - /url: https://github.com/getyak/talent-signal
                      - button "✳ 聊聊这个产品" [ref=f1e127] [cursor=pointer]
                    - paragraph [ref=f1e128]: 当前边界：当前使用合成数据验证产品语言、审阅状态和跨端流程，还不是生产候选人数据系统。
            - navigation "应用 Dock" [ref=f1e132]:
              - button "CUBXXW OS 空间菜单" [ref=f1e133] [cursor=pointer]:
                - generic: CUBXXW OS
              - button "欢迎" [ref=f1e138] [cursor=pointer]
              - button "文章与思考" [ref=f1e146] [cursor=pointer]
              - button "产品" [ref=f1e152] [cursor=pointer]
              - button "旅途相册" [ref=f1e159] [cursor=pointer]
              - button "你的笔记" [ref=f1e166] [cursor=pointer]
              - button "空间助手" [ref=f1e172] [cursor=pointer]
              - button "工作区设置" [ref=f1e178] [cursor=pointer]
        - navigation "咖啡馆导览":
          - generic:
            - button "回到咖啡馆" [ref=f1e184] [cursor=pointer]: ← 回到咖啡馆
            - generic: CUBXXW OS
            - button "换个风景" [ref=f1e185] [cursor=pointer]: 换个风景 ↗
```

# Test source

```ts
  1  | import {test,expect} from '../helpers/frozen-site';
  2  | import {enterWorkspace} from '../helpers/space-entry';
  3  | 
  4  | test.use({reducedMotion:'reduce',channel:'chromium',launchOptions:{args:process.platform==='darwin'?['--enable-gpu','--use-angle=metal']:['--enable-unsafe-swiftshader']}});
  5  | 
  6  | for(const entry of [
  7  |   {name:'Chinese home introduction',path:'/zh/',selector:'.hp-entry-actions a[href$="#studio-products"]',destination:'/zh/projects/#studio-products',label:'产品'},
  8  |   {name:'English home products section',path:'/',selector:'#hp-projects .hp-section-action',destination:'/projects/#studio-products',label:'Products'},
  9  |   {name:'Chinese shared footer',path:'/zh/engineering/posts/use-go-tools-dlv/',selector:'.sf-more[href$="#studio-products"]',destination:'/zh/projects/#studio-products',label:'产品'},
  10 | ]) {
  11 |   test(`${entry.name} opens the actual products app in the current tab`,async({page,context})=>{
  12 |     await page.setViewportSize({width:1440,height:900});await page.goto(entry.path);
  13 |     const link=page.locator(entry.selector);await expect(link).toHaveAttribute('href',entry.destination);
  14 |     expect(await link.getAttribute('target')).not.toBe('_blank');
  15 |     const pages=context.pages().length;await link.click();await expect(page).toHaveURL(entry.destination);
  16 |     await expect(page.locator('#studio-products')).toHaveCount(1);
  17 |     const space=page.locator('#studio-products[data-product-space]');await expect(space).toHaveCount(1);
  18 |     await expect(space).toHaveAttribute('data-product-view','bear');await expect(space.locator('[data-bear-workspace]')).toHaveCount(1);
  19 |     await enterWorkspace(page);
  20 |     const products=page.locator('[data-space-window="products"]');await expect(products).toBeVisible();
  21 |     await expect(products).toHaveAttribute('aria-label',entry.label);
  22 |     await expect(space.locator('[data-space-window="products"]')).toBeVisible();
> 23 |     await expect.poll(()=>products.evaluate(el=>el.contains(document.activeElement))).toBe(true);
     |                                                                                       ^ Error: Timeout 5000ms exceeded while waiting on the predicate
  24 |     await expect(products.locator('.space-product h2')).not.toBeEmpty();
  25 |     await expect(page.locator('[data-space-dock] [data-open="products"]')).toHaveAttribute('aria-label',entry.label);
  26 |     expect(context.pages()).toHaveLength(pages);
  27 |   });
  28 | }
  29 | 
  30 | test('the unqualified Space entrance still begins in the café in both languages',async({page})=>{
  31 |   await page.setViewportSize({width:390,height:844});
  32 |   for(const path of ['/zh/projects/','/projects/']) {
  33 |     await page.goto(path);const space=page.locator('[data-bear-workspace]');
  34 |     await expect(space).toHaveAttribute('data-ready','true');
  35 |     await expect(space).toHaveAttribute('data-cafe-mode','cafe');
  36 |     await expect(page.locator('[data-space-dock]')).toBeHidden();
  37 |     await expect(page.locator('[data-space-window="products"]')).toBeHidden();
  38 |   }
  39 | });
  40 | 
```