# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: p1-p2-ux.spec.ts >> P1-P2 UX regression >> BEAR OS product search uses workspace search and restores the selected product
- Location: tests/e2e/p1-p2-ux.spec.ts:156:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: expect(locator).toBeHidden() failed

Locator:  getByRole('dialog', { name: '搜索工作区' })
Expected: hidden
Received: undefined

Call log:
  - Expect "toBeHidden" getByRole('dialog', { name: '搜索工作区' }) with timeout 5000ms
  - waiting for getByRole('dialog', { name: '搜索工作区' })
  - Protocol error (Runtime.callFunctionOn): Internal server error, session closed.

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=e2]:
    - generic [ref=e3]:
      - heading "空间 · CUBXXW OS" [level=1] [ref=e4]
      - paragraph [ref=e5]: CUBXXW OS 工作区
      - region "CUBXXW OS 个人工作区" [ref=e6]:
        - generic [ref=e7]:
          - generic "三维咖啡馆。WASD 或方向键行走，拖动看四周。" [ref=e8]
          - generic "CUBXXW OS" [ref=e9]:
            - generic:
              - region "欢迎" [ref=e10]:
                - generic [ref=e11]:
                  - generic [ref=e12]:
                    - button "关闭窗口" [ref=e13] [cursor=pointer]: ×
                    - button "最小化窗口" [ref=e14] [cursor=pointer]: −
                    - button "最大化或恢复窗口" [ref=e15] [cursor=pointer]: +
                  - strong: 欢迎
                  - button "窗口并排" [ref=e16] [cursor=pointer]: ◫
                - article [ref=e18]:
                  - generic [ref=e19]:
                    - generic [ref=e20]: Xinwei Xiong / cubxxw
                    - button "关于我 ↗" [ref=e21] [cursor=pointer]
                  - group [ref=e22]:
                    - generic "个人介绍与经历" [ref=e23] [cursor=pointer]:
                      - text: 个人介绍与经历
                      - generic [aria-hidden] [ref=e24]: ↗
                    - generic [ref=e25]:
                      - navigation "个人介绍目录" [ref=e26]:
                        - button "个人档案" [ref=e27] [cursor=pointer]
                        - button "这些年" [ref=e28] [cursor=pointer]
                        - button "阅读地图" [ref=e29] [cursor=pointer]
                      - generic [ref=e30]:
                        - paragraph [ref=e31]: CUBXXW / PROFILE
                        - heading "熊鑫伟 cubxxw" [level=3] [ref=e32]
                        - paragraph [ref=e33]: 熊鑫伟（cubxxw / BEAR，2001 年生）构建 AI 产品，关注 Agent 评估与可靠执行。曾参与 OpenIM 的工程和社区协作，在 cubxxw.com 公开项目实践与每月思考，旅行仍是生活的一部分。
                        - paragraph [ref=e34]: 更了解自己，更了解世界。
                        - generic [ref=e35]:
                          - link "简历与项目证据 ↗" [ref=e36] [cursor=pointer]:
                            - /url: https://resume.cubxxw.com
                          - link "GitHub ↗" [ref=e37] [cursor=pointer]:
                            - /url: https://github.com/cubxxw
                          - button "联系我 ↗" [ref=e38] [cursor=pointer]
                        - group [ref=e39]:
                          - generic "完整履历与公开资料" [ref=e40] [cursor=pointer]
                      - generic [ref=e41]:
                        - paragraph [ref=e42]: CUBXXW / ALONG THE WAY
                        - heading "这些年" [level=3] [ref=e43]
                        - list [ref=e44]:
                          - listitem [ref=e45]:
                            - time [ref=e46]: "2021"
                            - generic [ref=e47]:
                              - heading "第一篇博客" [level=4] [ref=e48]
                              - paragraph [ref=e49]: 注册了 GitHub，写下第一篇博客，开始公开自己的笔记。
                              - group [ref=e50]:
                                - generic "多一点细节" [ref=e51] [cursor=pointer]
                              - link "阅读《我的第一个博客》 ↗" [ref=e52] [cursor=pointer]:
                                - /url: /zh/growth/posts/my-first-blog/
                          - listitem [ref=e53]:
                            - time [ref=e54]: "2023"
                            - generic [ref=e55]:
                              - heading "OpenIM 与开源社区" [level=4] [ref=e56]
                              - paragraph [ref=e57]: 进入 OpenIM 实习，贡献代码，设计并主持社区双周会。
                              - group [ref=e58]:
                                - generic "多一点细节" [ref=e59] [cursor=pointer]
                              - link "阅读 2023 年度总结 ↗" [ref=e60] [cursor=pointer]:
                                - /url: /zh/growth/posts/2023-annual-summary-reflections-and-aspirations/
                          - listitem [ref=e61]:
                            - time [ref=e62]: "2024"
                            - generic [ref=e63]:
                              - heading "毕业，出发" [level=4] [ref=e64]
                              - paragraph [ref=e65]: 第一次出国、毕业、工作，再离职，开始一边旅行一边构建。
                              - group [ref=e66]:
                                - generic "多一点细节" [ref=e67] [cursor=pointer]
                              - link "阅读 2024 年度回顾 ↗" [ref=e68] [cursor=pointer]:
                                - /url: /zh/growth/posts/2024-annual-review/
                          - listitem [ref=e69]:
                            - time [ref=e70]: "2025"
                            - generic [ref=e71]:
                              - heading "尼泊尔 ACT" [level=4] [ref=e72]
                              - paragraph [ref=e73]: 走完第一次高原徒步。从 2 月起，开始每月写思考笔记。
                              - group [ref=e74]:
                                - generic "多一点细节" [ref=e75] [cursor=pointer]
                              - link "阅读 2025-2026 年度总结 ↗" [ref=e76] [cursor=pointer]:
                                - /url: /zh/growth/posts/2025-annual-review/
                          - listitem [ref=e77]:
                            - time [ref=e78]: "2026"
                            - generic [ref=e79]:
                              - heading "产品和新的工作" [level=4] [ref=e80]
                              - paragraph [ref=e81]: 继续做产品、写作。8 月 10 日，结束约两年的空窗，开始新的工作。
                              - group [ref=e82]:
                                - generic "多一点细节" [ref=e83] [cursor=pointer]
                              - link "阅读《不会让恐惧替我做决定》 ↗" [ref=e84] [cursor=pointer]:
                                - /url: /zh/growth/posts/2026-08-10-fear-does-not-decide-for-me/
                      - generic [ref=e85]:
                        - paragraph [ref=e86]: CUBXXW / READING PATHS
                        - group [ref=e88]:
                          - generic "想读我的文字？ 展开四条精选阅读路径" [ref=e89] [cursor=pointer]:
                            - text: 想读我的文字？
                            - generic [ref=e90]: 展开四条精选阅读路径
              - region "Solo Compass" [active] [ref=e94]:
                - generic [ref=e95]:
                  - generic [ref=e96]:
                    - button "关闭窗口" [ref=e97] [cursor=pointer]: ×
                    - button "最小化窗口" [ref=e98] [cursor=pointer]: −
                    - button "最大化或恢复窗口" [ref=e99] [cursor=pointer]: +
                  - strong: Solo Compass
                  - button "窗口并排" [ref=e100] [cursor=pointer]: ◫
                - generic [ref=e102]:
                  - complementary [ref=e103]:
                    - generic [ref=e104]:
                      - paragraph [ref=e105]: 产品目录
                      - button "Talent Signal" [ref=e106] [cursor=pointer]
                      - button "Leafhour" [ref=e107] [cursor=pointer]
                      - button "IMStage" [ref=e108] [cursor=pointer]
                      - button "Solo Compass" [pressed] [ref=e109] [cursor=pointer]
                      - button "DayPage" [ref=e110] [cursor=pointer]
                      - button "Telepace" [ref=e111] [cursor=pointer]
                      - button "Apply Agent" [ref=e112] [cursor=pointer]
                      - button "Agent Diff Guard" [ref=e113] [cursor=pointer]
                    - navigation "继续探索" [ref=e114]:
                      - button "构建笔记" [ref=e115] [cursor=pointer]
                      - button "我的书架" [ref=e116] [cursor=pointer]
                  - article [ref=e117]:
                    - paragraph [ref=e118]: TestFlight 准备中
                    - heading "Solo Compass" [level=2] [ref=e119]
                    - paragraph [ref=e120]: 打开地图，找到附近真正值得去做的事。
                    - img "Solo Compass at github.com/getyak/solo-compass" [ref=e121]
                    - paragraph [ref=e122]: 面向独自旅行者的活地图：把附近地点变成具体、有故事感的体验，并用 AI 缩小选择范围，而不是替你做决定。
                    - generic [ref=e123]:
                      - link "打开真实产品 ↗" [ref=e124] [cursor=pointer]:
                        - /url: https://github.com/getyak/solo-compass
                      - link "源码 ↗" [ref=e125] [cursor=pointer]:
                        - /url: https://github.com/getyak/solo-compass
                      - button "✳ 聊聊这个产品" [ref=e126] [cursor=pointer]
                    - heading "从构建到思考" [level=3] [ref=e127]
                    - button "2025.06.02 我如何学会观察自己的思考：四个月的元认知转变复盘 一篇基于四个月真实记录的元认知复盘：我如何识别自动想法、身体感受、情绪与自我叙事，在过度思考和实际行动之间拉开距离，重新获得选择权；也讨论自我观察何时会变成另一种逃避。" [ref=e128] [cursor=pointer]:
                      - text: 2025.06.02
                      - strong [ref=e129]: 我如何学会观察自己的思考：四个月的元认知转变复盘
                      - generic [ref=e130]: 一篇基于四个月真实记录的元认知复盘：我如何识别自动想法、身体感受、情绪与自我叙事，在过度思考和实际行动之间拉开距离，重新获得选择权；也讨论自我观察何时会变成另一种逃避。
                    - button "2026.07.14 拆到最后，剩下的才是你：一场关于无我、痛苦与\"怎么说都可以\"的追问 从一束阳光穿过白内障眼球的意象出发，一路拆解自我——无我、五蕴、缘起，直到概念的相对性让人眩晕：\"怎么说都可以，那还追求什么？\"这篇文章不给现成答案，只主张一点：相对性是站在生命外面看的性质，不是走在路上的性质。拆到最后，那个你怎么用\"空\"\"无常\"\"执著\"都消解不掉、依然压手的残余，才是你的地面。痛，正是它压手的证据。" [ref=e131] [cursor=pointer]:
                      - text: 2026.07.14
                      - strong [ref=e132]: 拆到最后，剩下的才是你：一场关于无我、痛苦与"怎么说都可以"的追问
                      - generic [ref=e133]: 从一束阳光穿过白内障眼球的意象出发，一路拆解自我——无我、五蕴、缘起，直到概念的相对性让人眩晕："怎么说都可以，那还追求什么？"这篇文章不给现成答案，只主张一点：相对性是站在生命外面看的性质，不是走在路上的性质。拆到最后，那个你怎么用"空""无常""执著"都消解不掉、依然压手的残余，才是你的地面。痛，正是它压手的证据。
            - navigation "应用 Dock" [ref=e137]:
              - button "CUBXXW OS 空间菜单" [ref=e138] [cursor=pointer]:
                - generic: CUBXXW OS
              - button "欢迎" [ref=e143] [cursor=pointer]
              - button "文章与思考" [ref=e151] [cursor=pointer]
              - button "产品" [ref=e157] [cursor=pointer]
              - button "旅途相册" [ref=e164] [cursor=pointer]
              - button "你的笔记" [ref=e171] [cursor=pointer]
              - button "空间助手" [ref=e177] [cursor=pointer]
              - button "工作区设置" [ref=e183] [cursor=pointer]
        - navigation "咖啡馆导览":
          - generic:
            - button "回到咖啡馆" [ref=e189] [cursor=pointer]: ← 回到咖啡馆
            - generic: CUBXXW OS
            - button "换个风景" [ref=e190] [cursor=pointer]: 换个风景 ↗
```

# Test source

```ts
  84  |     await expect(launchpad.locator('[data-launchpad-app]')).toHaveCount(11);
  85  |     await launchpad.locator('[data-launchpad-app="settings"]').click();
  86  |     const settings = workspace.locator('[data-space-window="settings"]');
  87  |     await expect(settings).toBeVisible();
  88  |     const nextTheme = await workspace.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  89  |     await settings.locator(`[data-set-theme="${nextTheme}"]`).click();
  90  |     await expect(workspace).toHaveAttribute('data-theme', nextTheme);
  91  |     await expect(settings.locator(`[data-set-theme="${nextTheme}"]`)).toHaveAttribute('aria-pressed', 'true');
  92  |     await expect.poll(() => page.evaluate(() => (
  93  |       window as unknown as { BearSpace: { snapshot: () => { theme: string } } }
  94  |     ).BearSpace.snapshot().theme)).toBe(nextTheme);
  95  | 
  96  |     for (const action of ['close', 'minimize', 'maximize', 'arrange']) {
  97  |       const control = settings.locator(`[data-window-action="${action}"]`);
  98  |       await expect(control).toBeVisible();
  99  |       await expect.poll(async () => (await control.boundingBox())?.width ?? 0).toBeGreaterThanOrEqual(44);
  100 |       await expect.poll(async () => (await control.boundingBox())?.height ?? 0).toBeGreaterThanOrEqual(44);
  101 |     }
  102 | 
  103 |     for (const app of ['welcome', 'products', 'reader', 'photos', 'map', 'books', 'notes', 'contact', 'terminal', 'agent', 'settings']) {
  104 |       await workspace.locator('[data-space-menu-trigger]').click();
  105 |     await allApps.click();
  106 |       await expect(launchpad).toBeVisible();
  107 |       await launchpad.locator(`[data-launchpad-app="${app}"]`).click();
  108 |       await expect(launchpad).toBeHidden();
  109 |       await expect(workspace.locator(`[data-space-window="${app}"]`)).toBeVisible();
  110 |       if(app === 'contact') {
  111 |         await page.locator('[data-message-draft]').fill('A private contact draft.');
  112 |         await expect(page.locator('[data-contact-email]')).toHaveAttribute('href',/A%20private%20contact%20draft/);
  113 |       }
  114 |     }
  115 |     await settings.locator('[data-window-action="close"]').click();
  116 |     await expect(settings).toHaveCount(0);
  117 |     await expect(workspace.locator('[data-space-window][data-active="true"]')).toBeVisible();
  118 |     expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(page.viewportSize()!.width);
  119 |     expect(errors).toEqual([]);
  120 |   });
  121 | 
  122 |   test('space defaults to CUBXXW OS and switches to Product Lab and back', async ({ page }) => {
  123 |     await page.goto('/zh/projects/');
  124 |     await enterWorkspace(page);
  125 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  126 | 
  127 |     const space = page.locator('[data-product-space]');
  128 |     const bearButton = page.locator('.product-view-switch [data-product-view-button="bear"]');
  129 |     const labButton = page.locator('.space-menu [data-product-view-button="lab"]');
  130 |     const bearPanel = page.locator('[data-product-panel="bear"]');
  131 | 
  132 |     await expect(space).toHaveAttribute('data-product-view', 'bear');
  133 |     await expect(bearButton).toHaveAttribute('aria-pressed', 'true');
  134 |     await expect(bearPanel).toBeVisible();
  135 |     await expect(page.locator('[data-product-panel="lab"]')).toHaveCount(0);
  136 | 
  137 |     await page.locator('[data-space-menu-trigger]').click();
  138 |     await labButton.click();
  139 |     const labPanel = page.locator('[data-product-panel="lab"]');
  140 |     await expect(space).toHaveAttribute('data-product-view', 'lab');
  141 |     await expect(labButton).toHaveAttribute('aria-pressed', 'true');
  142 |     await expect(bearPanel).toBeHidden();
  143 |     await expect(labPanel).toBeVisible();
  144 |     await expect(page.locator('.product-view-switch [data-product-view-button="lab"]')).toBeFocused();
  145 |     await expect(page).toHaveURL(/#product-lab$/);
  146 | 
  147 |     await bearButton.click();
  148 |     await expect(space).toHaveAttribute('data-product-view', 'bear');
  149 |     await expect(bearButton).toHaveAttribute('aria-pressed', 'true');
  150 |     await expect(bearPanel).toBeVisible();
  151 |     await expect(labPanel).toBeHidden();
  152 |     await expect(page).not.toHaveURL(/#product-lab$/);
  153 |     await expect(page.locator('[data-space-menu-trigger]')).toBeFocused();
  154 |   });
  155 | 
  156 |   test('BEAR OS product search uses workspace search and restores the selected product', async ({ page }) => {
  157 |     await page.goto('/zh/projects/');
  158 |     await enterWorkspace(page);
  159 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  160 |     const workspace = page.locator('[data-bear-workspace]');
  161 |     await expect(workspace).toHaveAttribute('data-ready', 'true');
  162 |     const searchTrigger = workspace.locator('[data-space-menu-trigger]');
  163 |     await expect(searchTrigger).toBeVisible();
  164 |     await searchTrigger.focus();
  165 |     await page.keyboard.press(process.platform === 'darwin' ? 'Meta+k' : 'Control+k');
  166 |     const dialog = page.getByRole('dialog', { name: '搜索工作区' });
  167 |     await expect(dialog).toBeVisible();
  168 |     await expect(dialog.locator('[data-space-search-input]')).toBeFocused();
  169 |     await page.keyboard.press('Escape');
  170 |     await expect(dialog).toBeHidden();
  171 |     await expect(searchTrigger).toBeFocused();
  172 |     await expect(workspace.locator('[data-space-window="welcome"]')).toBeVisible();
  173 | 
  174 |     await searchTrigger.click();
  175 |     await workspace.locator('.space-menu [data-space-search-trigger]').click();
  176 |     await expect(dialog).toBeVisible();
  177 |     await dialog.locator('[data-space-search-input]').fill('solo');
  178 |     const result = dialog.locator('[data-search-kind="product"][data-search-payload="solo-compass"]');
  179 |     await expect(result).toHaveCount(1);
  180 |     await expect(result).toContainText('Solo Compass');
  181 |     await page.keyboard.press('ArrowDown');
  182 |     await expect(result).toBeFocused();
  183 |     await page.keyboard.press('Enter');
> 184 |     await expect(dialog).toBeHidden();
      |                          ^ Error: expect(locator).toBeHidden() failed
  185 |     const product = workspace.locator('[data-space-window="products"]');
  186 |     await expect(product).toBeVisible();
  187 |     await expect(product.locator('.space-product h2')).toHaveText('Solo Compass');
  188 |     await expect(product.locator('[data-select-product="solo-compass"]')).toHaveAttribute('aria-pressed', 'true');
  189 |     const productState = () => page.evaluate(() => {
  190 |       const state = (window as unknown as {
  191 |         BearSpace: { snapshot: () => { windows: Array<{ app: string; payload: string; minimized: boolean }> } };
  192 |       }).BearSpace.snapshot().windows.find((win) => win.app === 'products');
  193 |       return { payload: state?.payload, minimized: state?.minimized };
  194 |     });
  195 |     await expect.poll(productState).toEqual({ payload: 'solo-compass', minimized: false });
  196 |     await product.locator('[data-window-action="minimize"]').click();
  197 |     await expect(product).toBeHidden();
  198 |     await expect.poll(productState).toEqual({ payload: 'solo-compass', minimized: true });
  199 |     await workspace.locator('[data-space-dock] [data-open="products"]').click();
  200 |     await expect(product).toBeVisible();
  201 |     await expect(product.locator('.space-product h2')).toHaveText('Solo Compass');
  202 |     await expect.poll(productState).toEqual({ payload: 'solo-compass', minimized: false });
  203 |   });
  204 | 
  205 |   test('Space language changes preserve private work and the open article', async ({ page }) => {
  206 |     await page.goto('/zh/projects/?profile=about#identity');
  207 |     const workspace = page.locator('[data-bear-workspace]');
  208 |     await expect(workspace).toHaveAttribute('data-ready', 'true');
  209 |     await enterWorkspace(page);
  210 |     const openApp = async (app: string) => {
  211 |       const dock = workspace.locator(`[data-space-dock] [data-open="${app}"]`);
  212 |       if (await dock.isVisible()) await dock.click();
  213 |       else {
  214 |         await workspace.locator('[data-space-menu-trigger]').click();
  215 |         await workspace.locator('.space-menu [data-space-launchpad-trigger]').click();
  216 |         await workspace.locator(`[data-launchpad-app="${app}"]`).click();
  217 |       }
  218 |     };
  219 |     await openApp('reader');
  220 |     await page.locator('[data-library-list] [data-open="reader"]').first().click();
  221 |     const article = page.locator('[data-reader-body] .post-content');
  222 |     await expect(article).toBeVisible();
  223 |     const original = await article.innerText();
  224 |     await openApp('notes');
  225 |     await page.locator('[data-note-editor]').fill('Private note stays here.');
  226 |     await openApp('contact');
  227 |     await page.locator('[data-message-draft]').fill('A draft, not sent.');
  228 |     await openApp('settings');
  229 |     const snapshot = () => page.evaluate(() => (window as unknown as { BearSpace: { snapshot: () => unknown } }).BearSpace.snapshot());
  230 |     const before = await snapshot();
  231 |     await page.locator('[data-set-language="en"]').click();
  232 |     await expect(page).toHaveURL(/\/projects\/\?profile=about#identity$/);
  233 |     await expect(workspace).toHaveAttribute('data-ready', 'true');
  234 |     await enterWorkspace(page);
  235 |     await expect(page.locator('[data-set-language="en"]')).toHaveAttribute('aria-pressed', 'true');
  236 |     expect(await snapshot()).toEqual(before);
  237 |     await openApp('reader');
  238 |     await expect.poll(() => article.innerText()).toBe(original);
  239 |     await openApp('notes');
  240 |     await expect(page.locator('[data-note-editor]')).toHaveValue('Private note stays here.');
  241 |     await openApp('contact');
  242 |     await expect(page.locator('[data-message-draft]')).toHaveValue('A draft, not sent.');
  243 |   });
  244 | 
  245 |   for (const blocked of ['local', 'session'] as const) {
  246 |     test(`Space preserves work when ${blocked} storage fails during a language change`, async ({ page }) => {
  247 |       await page.addInitScript((blocked) => {
  248 |         const original = Storage.prototype.setItem;
  249 |         Storage.prototype.setItem = function (key, value) {
  250 |           if ((blocked === 'local' && this === localStorage && key === 'bear-space:v1') || (blocked === 'session' && this === sessionStorage)) {
  251 |             throw new DOMException('Storage is unavailable', 'QuotaExceededError');
  252 |           }
  253 |           return original.call(this, key, value);
  254 |         };
  255 |       }, blocked);
  256 |       await page.goto('/zh/projects/?profile=about#identity');
  257 |       const workspace = page.locator('[data-bear-workspace]');
  258 |       await expect(workspace).toHaveAttribute('data-ready', 'true');
  259 |       await enterWorkspace(page);
  260 |       await page.evaluate(() => (window as unknown as { BearSpace: { execute: (name: string, args: object) => unknown } }).BearSpace.execute('note', { text: 'Keep this private note.' }));
  261 |       await workspace.locator('[data-space-dock] [data-open="settings"]').click();
  262 |       const snapshot = () => page.evaluate(() => (window as unknown as { BearSpace: { snapshot: () => unknown } }).BearSpace.snapshot());
  263 |       const before = await snapshot();
  264 |       await page.locator('[data-set-language="en"]').click();
  265 |       if (blocked === 'local') {
  266 |         await expect(page).toHaveURL(/\/zh\/projects\/\?profile=about#identity$/);
  267 |         await expect(workspace.locator('[data-space-toast]')).toContainText('导出');
  268 |       } else {
  269 |         await expect(page).toHaveURL(/\/projects\/\?profile=about#identity$/);
  270 |         await enterWorkspace(page);
  271 |         await expect(page.locator('[data-set-language="en"]')).toHaveAttribute('aria-pressed', 'true');
  272 |       }
  273 |       expect(await snapshot()).toEqual(before);
  274 |       await expect(workspace.locator('[data-space-window="settings"]')).toBeVisible();
  275 |     });
  276 |   }
  277 | 
  278 |   test('Product Lab can enter BEAR knowledge space and return without leaving lab', async ({ page }) => {
  279 |     await page.goto('/zh/projects/');
  280 |     await enterWorkspace(page);
  281 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  282 | 
  283 |     await page.locator('[data-space-menu-trigger]').click();
  284 |     await page.locator('.space-menu [data-product-view-button="lab"]').click();
```