# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: p1-p2-ux.spec.ts >> P1-P2 UX regression >> an already open global search owns shortcuts above the BEAR workspace
- Location: tests/e2e/p1-p2-ux.spec.ts:303:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.focus: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('#search-command-palette').locator('.search-palette__close')

```

# Test source

```ts
  215 |         await workspace.locator('.space-menu [data-space-launchpad-trigger]').click();
  216 |         await workspace.locator(`[data-launchpad-app="${app}"]`).click();
  217 |       }
  218 |     };
  219 |     await openApp('reader');
  220 |     await page.locator('[data-library-list] [data-open="reader"]').first().click();
  221 |     const article = page.locator('[data-reader-body] .post-content');
  222 |     await expect(article).toBeVisible();
  223 |     const original = await article.innerText();
  224 |     await openApp('notes');
  225 |     await page.locator('[data-note-editor]').fill('Private note stays here.');
  226 |     await openApp('contact');
  227 |     await page.locator('[data-message-draft]').fill('A draft, not sent.');
  228 |     await openApp('settings');
  229 |     const snapshot = () => page.evaluate(() => (window as unknown as { BearSpace: { snapshot: () => unknown } }).BearSpace.snapshot());
  230 |     const before = await snapshot();
  231 |     await page.locator('[data-set-language="en"]').click();
  232 |     await expect(page).toHaveURL(/\/projects\/\?profile=about#identity$/);
  233 |     await expect(workspace).toHaveAttribute('data-ready', 'true');
  234 |     await enterWorkspace(page);
  235 |     await expect(page.locator('[data-set-language="en"]')).toHaveAttribute('aria-pressed', 'true');
  236 |     expect(await snapshot()).toEqual(before);
  237 |     await openApp('reader');
  238 |     await expect.poll(() => article.innerText()).toBe(original);
  239 |     await openApp('notes');
  240 |     await expect(page.locator('[data-note-editor]')).toHaveValue('Private note stays here.');
  241 |     await openApp('contact');
  242 |     await expect(page.locator('[data-message-draft]')).toHaveValue('A draft, not sent.');
  243 |   });
  244 | 
  245 |   for (const blocked of ['local', 'session'] as const) {
  246 |     test(`Space preserves work when ${blocked} storage fails during a language change`, async ({ page }) => {
  247 |       await page.addInitScript((blocked) => {
  248 |         const original = Storage.prototype.setItem;
  249 |         Storage.prototype.setItem = function (key, value) {
  250 |           if ((blocked === 'local' && this === localStorage && key === 'bear-space:v1') || (blocked === 'session' && this === sessionStorage)) {
  251 |             throw new DOMException('Storage is unavailable', 'QuotaExceededError');
  252 |           }
  253 |           return original.call(this, key, value);
  254 |         };
  255 |       }, blocked);
  256 |       await page.goto('/zh/projects/?profile=about#identity');
  257 |       const workspace = page.locator('[data-bear-workspace]');
  258 |       await expect(workspace).toHaveAttribute('data-ready', 'true');
  259 |       await enterWorkspace(page);
  260 |       await page.evaluate(() => (window as unknown as { BearSpace: { execute: (name: string, args: object) => unknown } }).BearSpace.execute('note', { text: 'Keep this private note.' }));
  261 |       await workspace.locator('[data-space-dock] [data-open="settings"]').click();
  262 |       const snapshot = () => page.evaluate(() => (window as unknown as { BearSpace: { snapshot: () => unknown } }).BearSpace.snapshot());
  263 |       const before = await snapshot();
  264 |       await page.locator('[data-set-language="en"]').click();
  265 |       if (blocked === 'local') {
  266 |         await expect(page).toHaveURL(/\/zh\/projects\/\?profile=about#identity$/);
  267 |         await expect(workspace.locator('[data-space-toast]')).toContainText('导出');
  268 |       } else {
  269 |         await expect(page).toHaveURL(/\/projects\/\?profile=about#identity$/);
  270 |         await enterWorkspace(page);
  271 |         await expect(page.locator('[data-set-language="en"]')).toHaveAttribute('aria-pressed', 'true');
  272 |       }
  273 |       expect(await snapshot()).toEqual(before);
  274 |       await expect(workspace.locator('[data-space-window="settings"]')).toBeVisible();
  275 |     });
  276 |   }
  277 | 
  278 |   test('Product Lab can enter BEAR knowledge space and return without leaving lab', async ({ page }) => {
  279 |     await page.goto('/zh/projects/');
  280 |     await enterWorkspace(page);
  281 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  282 | 
  283 |     await page.locator('[data-space-menu-trigger]').click();
  284 |     await page.locator('.space-menu [data-product-view-button="lab"]').click();
  285 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  286 | 
  287 |     const host = page.locator('[data-bks-host]');
  288 |     await expect(page).toHaveURL(/#knowledge$/);
  289 |     await expect(host).toBeVisible();
  290 |     await expect(host.locator('.bks__chip').first()).toBeVisible();
  291 |     await expect(host.locator('.bks__title')).toHaveText('产品与写作如何连成一条线');
  292 |     await expect(host.getByText('BEAR 知识空间', { exact: true })).toBeVisible();
  293 |     // Ordinary page scroll stays available (no overflow lock).
  294 |     await expect(page.locator('body')).not.toHaveClass(/overflow-hidden|scroll-locked/);
  295 | 
  296 |     await page.keyboard.press('Escape');
  297 |     await expect(page).toHaveURL(/#product-lab$/);
  298 |     await expect(host).toBeHidden();
  299 |     await expect(page.locator('[data-product-panel="lab"]')).toBeVisible();
  300 |     await expect(page.getByRole('button', { name: '进入知识空间' })).toBeVisible();
  301 |   });
  302 | 
  303 |   test('an already open global search owns shortcuts above the BEAR workspace', async ({ page }) => {
  304 |     await page.goto('/zh/projects/');
  305 |     await enterWorkspace(page);
  306 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  307 |     const globalSearch=page.locator('#search-command-palette');
  308 |     const workspaceSearch=page.locator('[data-space-search]');
  309 |     for(const key of [process.platform==='darwin'?'Meta+k':'Control+k','Escape']) {
  310 |       if (await page.locator('[data-bear-workspace]').isVisible()) { await page.locator('[data-space-menu-trigger]').click(); await page.locator('.space-menu [data-product-view-button="lab"]').click(); }
  311 |       await page.locator('[data-search-trigger="nav"]').click();
  312 |       await expect(globalSearch).toBeVisible();
  313 |       await page.evaluate(()=>{location.hash='';});
  314 |       await expect(page.locator('[data-bear-workspace]')).toBeVisible();
> 315 |       await globalSearch.locator('.search-palette__close').focus();
      |                                                            ^ Error: locator.focus: Test timeout of 30000ms exceeded.
  316 |       await page.keyboard.press(key);
  317 |       await expect(globalSearch).toBeHidden();
  318 |       await expect(workspaceSearch).toBeHidden();
  319 |       await expect(page.locator('[data-space-window="welcome"]')).toBeVisible();
  320 |     }
  321 |   });
  322 | 
  323 |   test('knowledge space stays closed when the reader exits before its module loads', async ({ page }) => {
  324 |     await page.route('**/bear-knowledge-space*.js', async (route) => {
  325 |       await new Promise((resolve) => setTimeout(resolve, 500));
  326 |       await route.fallback();
  327 |     });
  328 |     await page.goto('/zh/projects/');
  329 |     await enterWorkspace(page);
  330 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  331 |     await page.locator('[data-space-menu-trigger]').click();
  332 |     await page.locator('.space-menu [data-product-view-button="lab"]').click();
  333 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  334 |     await page.keyboard.press('Escape');
  335 |     await expect(page).toHaveURL(/#product-lab$/);
  336 |     await page.waitForTimeout(700);
  337 |     await expect(page.locator('[data-bks-host]')).toBeHidden();
  338 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  339 |     await expect(page.locator('[data-bks-host] .bks__chip').first()).toBeVisible();
  340 |   });
  341 | 
  342 |   test('a pending knowledge mount cannot clear an immediate reopen or a later BEAR view', async ({ page }) => {
  343 |     await page.route('**/bear-knowledge-space*.js', async (route) => {
  344 |       await new Promise((resolve) => setTimeout(resolve, 500));
  345 |       await route.fallback();
  346 |     });
  347 |     await page.goto('/zh/projects/');
  348 |     await enterWorkspace(page);
  349 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  350 |     await page.locator('[data-space-menu-trigger]').click();
  351 |     await page.locator('.space-menu [data-product-view-button="lab"]').click();
  352 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  353 |     await page.keyboard.press('Escape');
  354 |     await expect(page).toHaveURL(/#product-lab$/);
  355 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  356 |     await expect(page.locator('[data-bks-host] .bks__chip').first()).toBeVisible();
  357 |     await expect(page.locator('[data-bks-host]')).toHaveCount(1);
  358 |     await page.locator('.bks__back').click();
  359 |     await expect(page).toHaveURL(/#product-lab$/);
  360 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  361 |     await expect(page.locator('[data-bks-host] .bks__chip').first()).toBeVisible();
  362 |     await page.getByRole('button', { name: 'CUBXXW OS', exact: true }).click();
  363 |     await expect(page.locator('[data-bear-workspace]')).toBeVisible();
  364 |     await expect(page.locator('[data-bks-host]')).toBeHidden();
  365 |     await expect(page).not.toHaveURL(/#knowledge$/);
  366 |   });
  367 | });
  368 | 
```