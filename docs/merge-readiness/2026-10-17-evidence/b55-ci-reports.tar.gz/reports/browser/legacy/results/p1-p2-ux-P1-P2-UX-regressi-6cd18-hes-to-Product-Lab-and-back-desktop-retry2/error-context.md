# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: p1-p2-ux.spec.ts >> P1-P2 UX regression >> space defaults to CUBXXW OS and switches to Product Lab and back
- Location: tests/e2e/p1-p2-ux.spec.ts:122:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('[data-space-search-close]')
    - locator resolved to <button type="button" aria-label="关闭搜索" data-space-search-close="">Esc</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - performing click action

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=e2]:
    - generic [ref=e3]:
      - heading "空间 · CUBXXW OS" [level=1] [ref=e4]
      - paragraph [ref=e5]: CUBXXW OS 工作区
      - region "CUBXXW OS 个人工作区" [ref=e6]:
        - generic [ref=e7]:
          - generic "三维咖啡馆。WASD 或方向键行走，拖动看四周。" [ref=e8]
          - generic "CUBXXW OS" [ref=e9]:
            - region "欢迎" [ref=e10]:
              - generic [ref=e11]:
                - generic [ref=e12]:
                  - button "关闭窗口" [ref=e13] [cursor=pointer]: ×
                  - button "最小化窗口" [ref=e14] [cursor=pointer]: −
                  - button "最大化或恢复窗口" [ref=e15] [cursor=pointer]: +
                - strong: 欢迎
                - button "适应工作区" [ref=e16] [cursor=pointer]: ◫
              - article [ref=e18]:
                - generic [ref=e19]:
                  - generic [ref=e20]: Xinwei Xiong / cubxxw
                  - button "关于我 ↗" [ref=e21] [cursor=pointer]
                - group [ref=e22]:
                  - generic "个人介绍与经历" [ref=e23] [cursor=pointer]:
                    - text: 个人介绍与经历
                    - generic [aria-hidden] [ref=e24]: ↗
                  - generic [ref=e25]:
                    - navigation "个人介绍目录" [ref=e26]:
                      - button "个人档案" [ref=e27] [cursor=pointer]
                      - button "这些年" [ref=e28] [cursor=pointer]
                      - button "阅读地图" [ref=e29] [cursor=pointer]
                    - generic [ref=e30]:
                      - paragraph [ref=e31]: CUBXXW / PROFILE
                      - heading "熊鑫伟 cubxxw" [level=3] [ref=e32]
                      - paragraph [ref=e33]: 熊鑫伟（cubxxw / BEAR，2001 年生）构建 AI 产品，关注 Agent 评估与可靠执行。曾参与 OpenIM 的工程和社区协作，在 cubxxw.com 公开项目实践与每月思考，旅行仍是生活的一部分。
                      - paragraph [ref=e34]: 更了解自己，更了解世界。
                      - generic [ref=e35]:
                        - link "简历与项目证据 ↗" [ref=e36] [cursor=pointer]:
                          - /url: https://resume.cubxxw.com
                        - link "GitHub ↗" [ref=e37] [cursor=pointer]:
                          - /url: https://github.com/cubxxw
                        - button "联系我 ↗" [ref=e38] [cursor=pointer]
                      - group [ref=e39]:
                        - generic "完整履历与公开资料" [ref=e40] [cursor=pointer]
                    - generic [ref=e41]:
                      - paragraph [ref=e42]: CUBXXW / ALONG THE WAY
                      - heading "这些年" [level=3] [ref=e43]
                      - list [ref=e44]:
                        - listitem [ref=e45]:
                          - time [ref=e46]: "2021"
                          - generic [ref=e47]:
                            - heading "第一篇博客" [level=4] [ref=e48]
                            - paragraph [ref=e49]: 注册了 GitHub，写下第一篇博客，开始公开自己的笔记。
                            - group [ref=e50]:
                              - generic "多一点细节" [ref=e51] [cursor=pointer]
                            - link "阅读《我的第一个博客》 ↗" [ref=e52] [cursor=pointer]:
                              - /url: /zh/growth/posts/my-first-blog/
                        - listitem [ref=e53]:
                          - time [ref=e54]: "2023"
                          - generic [ref=e55]:
                            - heading "OpenIM 与开源社区" [level=4] [ref=e56]
                            - paragraph [ref=e57]: 进入 OpenIM 实习，贡献代码，设计并主持社区双周会。
                            - group [ref=e58]:
                              - generic "多一点细节" [ref=e59] [cursor=pointer]
                            - link "阅读 2023 年度总结 ↗" [ref=e60] [cursor=pointer]:
                              - /url: /zh/growth/posts/2023-annual-summary-reflections-and-aspirations/
                        - listitem [ref=e61]:
                          - time [ref=e62]: "2024"
                          - generic [ref=e63]:
                            - heading "毕业，出发" [level=4] [ref=e64]
                            - paragraph [ref=e65]: 第一次出国、毕业、工作，再离职，开始一边旅行一边构建。
                            - group [ref=e66]:
                              - generic "多一点细节" [ref=e67] [cursor=pointer]
                            - link "阅读 2024 年度回顾 ↗" [ref=e68] [cursor=pointer]:
                              - /url: /zh/growth/posts/2024-annual-review/
                        - listitem [ref=e69]:
                          - time [ref=e70]: "2025"
                          - generic [ref=e71]:
                            - heading "尼泊尔 ACT" [level=4] [ref=e72]
                            - paragraph [ref=e73]: 走完第一次高原徒步。从 2 月起，开始每月写思考笔记。
                            - group [ref=e74]:
                              - generic "多一点细节" [ref=e75] [cursor=pointer]
                            - link "阅读 2025-2026 年度总结 ↗" [ref=e76] [cursor=pointer]:
                              - /url: /zh/growth/posts/2025-annual-review/
                        - listitem [ref=e77]:
                          - time [ref=e78]: "2026"
                          - generic [ref=e79]:
                            - heading "产品和新的工作" [level=4] [ref=e80]
                            - paragraph [ref=e81]: 继续做产品、写作。8 月 10 日，结束约两年的空窗，开始新的工作。
                            - group [ref=e82]:
                              - generic "多一点细节" [ref=e83] [cursor=pointer]
                            - link "阅读《不会让恐惧替我做决定》 ↗" [ref=e84] [cursor=pointer]:
                              - /url: /zh/growth/posts/2026-08-10-fear-does-not-decide-for-me/
                    - generic [ref=e85]:
                      - paragraph [ref=e86]: CUBXXW / READING PATHS
                      - group [ref=e88]:
                        - generic "想读我的文字？ 展开四条精选阅读路径" [ref=e89] [cursor=pointer]:
                          - text: 想读我的文字？
                          - generic [ref=e90]: 展开四条精选阅读路径
            - navigation "应用 Dock" [ref=e94]:
              - button "CUBXXW OS 空间菜单" [ref=e95] [cursor=pointer]:
                - generic: CUBXXW OS
              - button "欢迎" [ref=e100] [cursor=pointer]
              - button "文章与思考" [ref=e108] [cursor=pointer]
              - button "产品" [ref=e114] [cursor=pointer]
              - button "旅途相册" [ref=e121] [cursor=pointer]
              - button "你的笔记" [ref=e128] [cursor=pointer]
              - button "空间助手" [ref=e134] [cursor=pointer]
              - button "工作区设置" [ref=e140] [cursor=pointer]
        - navigation "咖啡馆导览":
          - generic:
            - button "回到咖啡馆" [ref=e146] [cursor=pointer]: ← 回到咖啡馆
            - generic: CUBXXW OS
            - button "换个风景" [ref=e147] [cursor=pointer]: 换个风景 ↗
        - dialog "搜索工作区" [ref=e148]:
          - generic [ref=e149]:
            - generic [aria-hidden] [ref=e150]: ⌕
            - searchbox "搜索词" [active] [ref=e151]
            - button "关闭搜索" [ref=e152] [cursor=pointer]: Esc
          - status [ref=e153]: 19 个结果
          - generic [ref=e154]:
            - button [ref=e155] [cursor=pointer]:
              - generic [ref=e162]:
                - strong [ref=e163]: 欢迎
                - text: 应用
            - button [ref=e164] [cursor=pointer]:
              - generic [ref=e170]:
                - strong [ref=e171]: 产品
                - text: 应用
            - button [ref=e172] [cursor=pointer]:
              - generic [ref=e177]:
                - strong [ref=e178]: 文章与思考
                - text: 应用
            - button [ref=e179] [cursor=pointer]:
              - generic [ref=e185]:
                - strong [ref=e186]: 旅途相册
                - text: 应用
            - button [ref=e187] [cursor=pointer]:
              - generic [ref=e192]:
                - strong [ref=e193]: 去过的地方
                - text: 应用
            - button [ref=e194] [cursor=pointer]:
              - generic [ref=e199]:
                - strong [ref=e200]: 我的书架
                - text: 应用
            - button [ref=e201] [cursor=pointer]:
              - generic [ref=e206]:
                - strong [ref=e207]: 你的笔记
                - text: 应用
            - button [ref=e208] [cursor=pointer]:
              - generic [ref=e212]:
                - strong [ref=e213]: 联系与留言
                - text: 应用
            - button [ref=e214] [cursor=pointer]:
              - generic [ref=e219]:
                - strong [ref=e220]: 终端
                - text: 应用
            - button [ref=e221] [cursor=pointer]:
              - generic [ref=e226]:
                - strong [ref=e227]: 空间助手
                - text: 应用
            - button [ref=e228] [cursor=pointer]:
              - generic [ref=e233]:
                - strong [ref=e234]: 工作区设置
                - text: 应用
            - button [ref=e235] [cursor=pointer]:
              - generic [ref=e241]:
                - strong [ref=e242]: Talent Signal
                - text: 测试中
            - button [ref=e243] [cursor=pointer]:
              - generic [ref=e249]:
                - strong [ref=e250]: Leafhour
                - text: 已上线
            - button [ref=e251] [cursor=pointer]:
              - generic [ref=e257]:
                - strong [ref=e258]: IMStage
                - text: 已上线
            - button [ref=e259] [cursor=pointer]:
              - generic [ref=e265]:
                - strong [ref=e266]: Solo Compass
                - text: TestFlight 准备中
            - button [ref=e267] [cursor=pointer]:
              - generic [ref=e273]:
                - strong [ref=e274]: DayPage
                - text: 已上线
            - button [ref=e275] [cursor=pointer]:
              - generic [ref=e281]:
                - strong [ref=e282]: Telepace
                - text: 公开测试
            - button [ref=e283] [cursor=pointer]:
              - generic [ref=e289]:
                - strong [ref=e290]: Apply Agent
                - text: 公开测试
            - button [ref=e291] [cursor=pointer]:
              - generic [ref=e297]:
                - strong [ref=e298]: Agent Diff Guard
                - text: 内部使用
          - generic [ref=e299]:
            - text: ↑ ↓ 选择 ↵ 打开
            - generic [ref=e300]: BEAR / SPOTLIGHT
```

# Test source

```ts
  1  | import {expect,type Page} from './frozen-site';
  2  | export async function enterWorkspace(page:Page) {
  3  |   await page.waitForFunction(()=>{const d=document.querySelector<HTMLElement>('[data-bear-workspace]')?.dataset;return d?.ready==='true'&&(d.worldFailed==='true'||(Number(d.worldFrames)>0&&!d.worldLoading&&d.bootState==='complete'));});
  4  |   if(await page.locator('[data-bear-workspace]').getAttribute('data-world-failed')==='true'&&await page.locator('[data-boot-skip]').isVisible())await page.locator('[data-boot-skip]').click();
  5  |   if(await page.locator('[data-bear-workspace]').getAttribute('data-cafe-mode')==='desktop')return;
  6  |   await page.keyboard.press('Control+k');
  7  |   await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode','desktop');
> 8  |   await page.locator('[data-space-search-close]').click();
     |                                                   ^ Error: locator.click: Test timeout of 30000ms exceeded.
  9  | }
  10 | 
```