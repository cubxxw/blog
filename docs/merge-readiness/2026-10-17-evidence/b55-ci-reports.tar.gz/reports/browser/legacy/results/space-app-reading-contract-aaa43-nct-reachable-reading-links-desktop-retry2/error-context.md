# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: space-app-reading-contracts.spec.ts >> 1440×900 en dark products and books >> real choices retain focus, readable content and distinct reachable reading links
- Location: tests/e2e/space-app-reading-contracts.spec.ts:52:7

# Error details

```
Error: Test timeout of 30000ms exceeded
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=e2]:
    - generic [ref=e3]:
      - heading "Space · CUBXXW OS" [level=1] [ref=e4]
      - paragraph [ref=e5]: CUBXXW OS workspace
      - region "CUBXXW OS personal workspace" [ref=e6]:
        - generic [ref=e7]:
          - generic "3D café. Walk with WASD or arrow keys; drag to look around." [ref=e8]
          - generic "CUBXXW OS" [ref=e9]:
            - generic:
              - region "Welcome" [ref=e10]:
                - generic [ref=e11]:
                  - generic [ref=e12]:
                    - button "Close window" [ref=e13] [cursor=pointer]: ×
                    - button "Minimize window" [ref=e14] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=e15] [cursor=pointer]: +
                  - strong: Welcome
                  - button "Arrange windows" [ref=e16] [cursor=pointer]: ◫
                - article [ref=e18]:
                  - generic [ref=e19]:
                    - generic [ref=e20]: Xinwei Xiong / cubxxw
                    - button "About me ↗" [ref=e21] [cursor=pointer]
                  - group [ref=e22]:
                    - generic "About me and my story" [ref=e23] [cursor=pointer]:
                      - text: About me and my story
                      - generic [aria-hidden] [ref=e24]: ↗
                    - generic [ref=e25]:
                      - navigation "Profile sections" [ref=e26]:
                        - button "Profile" [ref=e27] [cursor=pointer]
                        - button "Along the way" [ref=e28] [cursor=pointer]
                        - button "Reading paths" [ref=e29] [cursor=pointer]
                      - generic [ref=e30]:
                        - paragraph [ref=e31]: CUBXXW / PROFILE
                        - heading "Xinwei Xiong cubxxw" [level=3] [ref=e32]
                        - paragraph [ref=e33]: Xinwei Xiong (熊鑫伟, aka cubxxw / BEAR, b. 2001) builds AI products with a focus on agent evaluation and reliable execution. He contributed to OpenIM's engineering and community workflows, and writes about projects and monthly reflections at cubxxw.com. Travel remains part of his life.
                        - paragraph [ref=e34]: To know myself more, and to know the world more.
                        - generic [ref=e35]:
                          - link "Resume and project evidence ↗" [ref=e36] [cursor=pointer]:
                            - /url: https://resume.cubxxw.com/en/
                          - link "GitHub ↗" [ref=e37] [cursor=pointer]:
                            - /url: https://github.com/cubxxw
                          - button "Say hello ↗" [ref=e38] [cursor=pointer]
                        - group [ref=e39]:
                          - generic "Full biography and public records" [ref=e40] [cursor=pointer]
                      - generic [ref=e41]:
                        - paragraph [ref=e42]: CUBXXW / ALONG THE WAY
                        - heading "Along the way" [level=3] [ref=e43]
                        - list [ref=e44]:
                          - listitem [ref=e45]:
                            - time [ref=e46]: "2021"
                            - generic [ref=e47]:
                              - heading "A first blog post" [level=4] [ref=e48]
                              - paragraph [ref=e49]: I created my GitHub account and began publishing my notes.
                              - group [ref=e50]:
                                - generic "More of the story" [ref=e51] [cursor=pointer]
                              - link "Read “My First Blog” ↗" [ref=e52] [cursor=pointer]:
                                - /url: /growth/posts/my-first-blog/
                          - listitem [ref=e53]:
                            - time [ref=e54]: "2023"
                            - generic [ref=e55]:
                              - heading "OpenIM and open source" [level=4] [ref=e56]
                              - paragraph [ref=e57]: I joined OpenIM as an intern, contributed code, and hosted community meetings.
                              - group [ref=e58]:
                                - generic "More of the story" [ref=e59] [cursor=pointer]
                              - link "Read the 2023 annual review ↗" [ref=e60] [cursor=pointer]:
                                - /url: /growth/posts/2023-annual-summary-reflections-and-aspirations/
                          - listitem [ref=e61]:
                            - time [ref=e62]: "2024"
                            - generic [ref=e63]:
                              - heading "Graduation and departure" [level=4] [ref=e64]
                              - paragraph [ref=e65]: My first trip abroad, graduation, a job, then leaving to travel and build.
                              - group [ref=e66]:
                                - generic "More of the story" [ref=e67] [cursor=pointer]
                              - link "Read the 2024 annual review ↗" [ref=e68] [cursor=pointer]:
                                - /url: /growth/posts/2024-annual-review/
                          - listitem [ref=e69]:
                            - time [ref=e70]: "2025"
                            - generic [ref=e71]:
                              - heading "The Annapurna Circuit" [level=4] [ref=e72]
                              - paragraph [ref=e73]: My first high-altitude trek. From February, I began writing monthly notes.
                              - group [ref=e74]:
                                - generic "More of the story" [ref=e75] [cursor=pointer]
                              - link "Read the 2025–2026 annual review ↗" [ref=e76] [cursor=pointer]:
                                - /url: /growth/posts/2025-annual-review/
                          - listitem [ref=e77]:
                            - time [ref=e78]: "2026"
                            - generic [ref=e79]:
                              - heading "Products and a new job" [level=4] [ref=e80]
                              - paragraph [ref=e81]: I kept building and writing. On August 10, after roughly two years away, I started a new job.
                              - group [ref=e82]:
                                - generic "More of the story" [ref=e83] [cursor=pointer]
                              - link "Read the August 2026 thought notes ↗" [ref=e84] [cursor=pointer]:
                                - /url: /growth/posts/2026-08-thought-notes/
                      - generic [ref=e85]:
                        - paragraph [ref=e86]: CUBXXW / READING PATHS
                        - group [ref=e88]:
                          - generic "Want to read my writing? Open four curated reading paths" [ref=e89] [cursor=pointer]:
                            - text: Want to read my writing?
                            - generic [ref=e90]: Open four curated reading paths
              - region "Your notes" [ref=e94]:
                - generic [ref=e95]:
                  - generic [ref=e96]:
                    - button "Close window" [ref=e97] [cursor=pointer]: ×
                    - button "Minimize window" [ref=e98] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=e99] [cursor=pointer]: +
                  - strong: Your notes
                  - button "Arrange windows" [ref=e100] [cursor=pointer]: ◫
                - generic [ref=e102]:
                  - generic [ref=e103]:
                    - generic [ref=e104]: A note of your own
                    - generic [ref=e105]:
                      - button "Save to sandbox" [ref=e106] [cursor=pointer]
                      - button "Export .md ↗" [ref=e107] [cursor=pointer]
                  - textbox "Your note" [ref=e108]:
                    - /placeholder: "What did this place make you think of?\n\nWrite it down. Come back and pick it up later."
                    - text: 同一个输入框，先读产品和书，再接着写。
                  - generic [ref=e109]:
                    - generic [ref=e110]: Saved in this browser, never published
                    - generic [ref=e111]: 19 / 40000
              - region "IMStage" [ref=e115]:
                - generic [ref=e116]:
                  - generic [ref=e117]:
                    - button "Close window" [ref=e118] [cursor=pointer]: ×
                    - button "Minimize window" [ref=e119] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=e120] [cursor=pointer]: +
                  - strong: IMStage
                  - button "Arrange windows" [ref=e121] [cursor=pointer]: ◫
                - generic [ref=e123]:
                  - complementary [ref=e124]:
                    - generic [ref=e125]:
                      - paragraph [ref=e126]: Products
                      - button "Talent Signal" [ref=e127] [cursor=pointer]
                      - button "Leafhour" [ref=e128] [cursor=pointer]
                      - button "IMStage" [active] [pressed] [ref=e129] [cursor=pointer]
                      - button "Solo Compass" [ref=e130] [cursor=pointer]
                      - button "DayPage" [ref=e131] [cursor=pointer]
                      - button "Telepace" [ref=e132] [cursor=pointer]
                      - button "Apply Agent" [ref=e133] [cursor=pointer]
                      - button "Agent Diff Guard" [ref=e134] [cursor=pointer]
                    - navigation "Explore more" [ref=e135]:
                      - button "Build notes" [ref=e136] [cursor=pointer]
                      - button "Books" [ref=e137] [cursor=pointer]
                  - article [ref=e138]:
                    - paragraph [ref=e139]: Live
                    - heading "IMStage" [level=2] [ref=e140]
                    - paragraph [ref=e141]: Turn a conversation into an editable scene.
                    - img "The IMStage scene prompt beside a WhatsApp preview with fictional characters and an AI-generated photo" [ref=e142]
                    - paragraph [ref=e143]: Start with a premise. Generate dialogue, people and photos, edit each detail, reuse a template, or make a series of stories in one project. Export the result as a PNG.
                    - generic [ref=e144]:
                      - link "Open the product ↗" [ref=e145] [cursor=pointer]:
                        - /url: https://imstage.org/?lang=en
                      - link "Source ↗" [ref=e146] [cursor=pointer]:
                        - /url: https://github.com/kubbot/imstage
                      - button "✳ Ask about this project" [ref=e147] [cursor=pointer]
                    - paragraph [ref=e148]: "Current boundary: For demos and fiction. AI generation uses account credits; screenshot reconstruction creates an approximate editable layout."
                    - heading "Related writing" [level=3] [ref=e149]
                    - 'button "2026.09.23 IMStage: Editable Chat Scenes Create editable chat scenes with IMStage. Generate dialogue and photos, reuse templates, make project variations, and export PNGs with automatic draft saving." [ref=e150] [cursor=pointer]':
                      - text: 2026.09.23
                      - strong [ref=e151]: "IMStage: Editable Chat Scenes"
                      - generic [ref=e152]: Create editable chat scenes with IMStage. Generate dialogue and photos, reuse templates, make project variations, and export PNGs with automatic draft saving.
            - navigation "Application Dock" [ref=e156]:
              - button "CUBXXW OS Space menu" [ref=e157] [cursor=pointer]:
                - generic: CUBXXW OS
              - button "Welcome" [ref=e162] [cursor=pointer]
              - button "Writing" [ref=e170] [cursor=pointer]
              - button "Products" [ref=e176] [cursor=pointer]
              - button "Photos" [ref=e183] [cursor=pointer]
              - button "Your notes" [ref=e190] [cursor=pointer]
              - button "Space companion" [ref=e196] [cursor=pointer]
              - button "Settings" [ref=e202] [cursor=pointer]
        - navigation "Café navigation":
          - generic:
            - button "Back to the café" [ref=e208] [cursor=pointer]: ← Back to the café
            - generic: CUBXXW OS
            - button "Change the view" [ref=e209] [cursor=pointer]: Change the view ↗
```

# Test source

```ts
  21  |   const win=page.locator(`[data-space-window="${app}"]`);await expect(win).toBeVisible();return win;
  22  | }
  23  | const projectedFontCSS=(node:Locator)=>node.evaluate((el:HTMLElement)=>parseFloat(getComputedStyle(el).fontSize)*el.getBoundingClientRect().width/el.offsetWidth);
  24  | const fitsHorizontally=(node:Locator)=>node.evaluate(el=>el.scrollWidth<=el.clientWidth+1);
  25  | const nextFrame=(page:Page)=>page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>resolve())));
  26  | async function hit(control:Locator) {
  27  |   await control.scrollIntoViewIfNeeded();
  28  |   const box=(await control.boundingBox())!;
  29  |   expect(box.width).toBeGreaterThanOrEqual(44);expect(box.height).toBeGreaterThanOrEqual(44);
  30  |   expect(await control.evaluate(el=>{const b=el.getBoundingClientRect();return el.contains(document.elementFromPoint(b.x+b.width/2,b.y+b.height/2));})).toBe(true);
  31  |   return box;
  32  | }
  33  | async function isolatedLinkClick(page:Page,control:Locator,url:string) {
  34  |   await expect(control).toHaveAttribute('href',new URL(url,page.url()).href);
  35  |   await expect(control).toHaveAttribute('target','_blank');await expect(control).toHaveAttribute('rel',/noopener/);
  36  |   const box=await hit(control),previous=await page.evaluate(()=>(window as any).__spaceLinkClicks.length);
  37  |   await page.mouse.click(box.x+box.width/2,box.y+box.height/2);
  38  |   const clicks=await page.evaluate(()=>(window as any).__spaceLinkClicks as {href:string,target:string}[]);
  39  |   expect(clicks).toHaveLength(previous+1);expect(clicks[clicks.length-1]).toEqual({href:new URL(url,page.url()).href,target:'_blank'});
  40  | }
  41  | 
  42  | const cases=[
  43  |   {width:320,height:844,locale:'zh',theme:'light',coarse:true},
  44  |   {width:390,height:844,locale:'en',theme:'light',coarse:true},
  45  |   {width:620,height:844,locale:'zh',theme:'dark',coarse:true},
  46  |   {width:844,height:390,locale:'en',theme:'dark',coarse:true},
  47  |   {width:1440,height:900,locale:'zh',theme:'light',coarse:false},
  48  |   {width:1440,height:900,locale:'en',theme:'dark',coarse:false},
  49  | ];
  50  | for(const view of cases)test.describe(`${view.width}×${view.height} ${view.locale} ${view.theme} products and books`,()=>{
  51  |   test.use({viewport:{width:view.width,height:view.height},hasTouch:view.coarse,isMobile:view.coarse});
  52  |   test('real choices retain focus, readable content and distinct reachable reading links',async({page})=>{
  53  |     await page.goto(view.locale==='zh'?'/zh/projects/':'/projects/');await enterWorkspace(page);
  54  |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-world-ready','true');
  55  |     expect(await page.evaluate(()=>matchMedia('(pointer:coarse)').matches)).toBe(view.coarse);
  56  |     // The public theme tool only establishes this fixture's appearance;
  57  |     // settings choice focus is deliberately outside this App contract.
  58  |     await page.evaluate(theme=>(window as any).BearSpace.execute('theme',{value:theme}),view.theme);
  59  |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-theme',view.theme);
  60  |     const catalog=await page.locator('[data-space-catalog]').evaluate(el=>JSON.parse(el.textContent||'{}')) as {products:Product[],books:Book[]};
  61  |     const locale=view.locale==='zh'?'zh':'en';
  62  |     const expectedProducts=sourceProducts.map(product=>({id:product.id,name:product.name,headline:product[`headline_${locale}`],description:product[`desc_${locale}`],url:product[`url_${locale}`]||product.url,demo:product.demo||'',github:product.github||''}));
  63  |     expect(catalog.products.length).toBeGreaterThan(0);expect(catalog.products).toHaveLength(sourceProducts.length);
  64  |     expect(new Set(catalog.products.map(product=>product.id)).size).toBe(sourceProducts.length);
  65  |     expect(catalog.products.map(({id,name,headline,description,url,demo,github})=>({id,name,headline,description,url,demo,github}))).toEqual(expectedProducts);
  66  |     expect(catalog.products.find(product=>product.id==='leafhour')).toMatchObject({name:'Leafhour',url:locale==='zh'?'https://leafhour.com':'https://leafhour.com/en',demo:'https://leafhour.com/read?book=gutenberg-alice',github:'https://github.com/getyak/leafhour'});
  67  |     expect(catalog.books).toHaveLength(4);
  68  |     const notes=await openApp(page,'notes'),editor=notes.locator('[data-note-editor]');await editor.fill('同一个输入框，先读产品和书，再接着写。');
  69  |     const original=await editor.elementHandle(),products=await openApp(page,'products');
  70  |     // Capture real clicks at the document boundary so no external product,
  71  |     // bookstore or API is contacted during this offline verification.
  72  |     await page.evaluate(()=>{
  73  |       (window as any).__spaceLinkClicks=[];
  74  |       document.addEventListener('click',event=>{
  75  |         const anchor=(event.target as Element).closest<HTMLAnchorElement>('.space-product__links a,.space-book > a');
  76  |         if(anchor){event.preventDefault();(window as any).__spaceLinkClicks.push({href:anchor.href,target:anchor.target});}
  77  |       },true);
  78  |     });
  79  |     const compact=view.width<=640||view.coarse&&view.height<=420,picker=products.locator('[data-product-select]');
  80  |     const directory=products.locator('.space-product-directory');
  81  |     if(compact) {
  82  |       await expect(directory).toBeHidden();await expect(picker).toBeVisible();await expect(picker.locator('option')).toHaveCount(sourceProducts.length);
  83  |       expect(await picker.locator('option').evaluateAll(nodes=>nodes.map(n=>(n as HTMLOptionElement).value))).toEqual(catalog.products.map(p=>p.id));
  84  |     } else {await expect(directory).toBeVisible();await expect(picker).toBeHidden();await expect(directory.locator('button')).toHaveCount(sourceProducts.length);
  85  |       expect(await directory.locator('[data-select-product]').evaluateAll(nodes=>nodes.map(node=>node.getAttribute('data-select-product')))).toEqual(sourceProducts.map(product=>product.id));}
  86  |     for(let i=0;i<catalog.products.length;i++) {
  87  |       const product=catalog.products[i];
  88  |       if(compact) {
  89  |         await hit(picker);await picker.focus();
  90  |         // Home/End and ArrowDown are native select keyboard operations.
  91  |         // They also exercise reconstruction while the choice owns focus.
  92  |         if(i===0){await picker.press('End');await picker.press('Home');}else await picker.press('ArrowDown');
  93  |         await expect(picker).toHaveValue(product.id);await nextFrame(page);await expect(picker).toBeFocused();
  94  |       } else {
  95  |         const choice=directory.locator(`[data-select-product="${product.id}"]`);await hit(choice);await choice.focus();await choice.press('Space');
  96  |         await expect(choice).toHaveAttribute('aria-pressed','true');await nextFrame(page);await expect(choice).toBeFocused();
  97  |         expect(await projectedFontCSS(choice)).toBeGreaterThanOrEqual(13);
  98  |       }
  99  |       await expect(products.locator('.space-product h2')).toHaveText(product.name);
  100 |       expect(await page.evaluate(()=>(window as any).BearSpace.snapshot().windows.find((w:any)=>w.app==='products').payload)).toBe(product.id);
  101 |       const paragraphs=products.locator('.space-product > p:not(.space-product__stage):not(.space-product__boundary)');
  102 |       await expect(paragraphs.first()).toHaveText(product.headline);await expect(paragraphs.last()).toHaveText(product.description);
  103 |       expect(await projectedFontCSS(paragraphs.first())).toBeGreaterThanOrEqual(16);
  104 |       expect(await fitsHorizontally(products.locator('[data-window-body]'))).toBe(true);
  105 |       if(view.width===844&&view.height===390) {
  106 |         const body=products.locator('[data-window-body]');await body.evaluate(el=>{el.scrollTop=0;});await nextFrame(page);
  107 |         // Entry means the top of this real scroll container, before any
  108 |         // automatic image/link scrolling. Measure the projected first line.
  109 |         const entry=await body.evaluate((el:HTMLElement)=>{
  110 |           const rect=el.getBoundingClientRect(),title=el.querySelector('.space-product h2')!.getBoundingClientRect();
  111 |           const headline=el.querySelector('.space-product h2 + p')!,line=headline.getBoundingClientRect();
  112 |           return {scrollTop:el.scrollTop,bodyTop:rect.top,bodyBottom:rect.bottom,titleTop:title.top,titleBottom:title.bottom,lineTop:line.top,lineBottom:line.top+parseFloat(getComputedStyle(headline).lineHeight)*rect.height/el.offsetHeight};
  113 |         });
  114 |         expect(entry.scrollTop).toBe(0);expect(entry.titleTop).toBeGreaterThanOrEqual(entry.bodyTop);
  115 |         expect(entry.titleBottom).toBeLessThanOrEqual(entry.bodyBottom);expect(entry.lineTop).toBeGreaterThanOrEqual(entry.bodyTop);
  116 |         expect(entry.lineBottom).toBeLessThanOrEqual(entry.bodyBottom);
  117 |       }
  118 |       if(product.image) {
  119 |         const image=products.locator('.space-product__shot');await image.scrollIntoViewIfNeeded();
  120 |         await expect(image).toHaveAttribute('src',product.image);await expect(image).toHaveAttribute('alt',product.alt);
> 121 |         await expect.poll(()=>image.evaluate((el:HTMLImageElement)=>el.complete&&el.naturalWidth>0)).toBe(true);
      |                                                                                                      ^ Error: Test timeout of 30000ms exceeded
  122 |         const geometry=await image.evaluate((el:HTMLImageElement)=>({height:el.offsetHeight,width:el.offsetWidth,natural:el.naturalWidth/el.naturalHeight,fit:getComputedStyle(el).objectFit}));
  123 |         expect(geometry.height).toBeLessThanOrEqual(281);expect(geometry.fit).toBe('contain');
  124 |         expect(Math.abs((geometry.width-2)/(geometry.height-2)-geometry.natural)).toBeLessThan(.04);
  125 |       }
  126 |       const links=products.locator('.space-product__links a'),urls=[product.url,product.demo,product.github].filter(Boolean);
  127 |       await expect(links).toHaveCount(urls.length);
  128 |       if(!product.demo)await expect(products.getByRole('link',{name:view.locale==='zh'?'测试预览 ↗':'Try the demo ↗',exact:true})).toHaveCount(0);
  129 |       for(let n=0;n<urls.length;n++){expect(await projectedFontCSS(links.nth(n))).toBeGreaterThanOrEqual(13);await isolatedLinkClick(page,links.nth(n),urls[n]);}
  130 |       // The AI action is checked for reachability only; it is never invoked.
  131 |       await hit(products.locator('[data-product-ask]'));
  132 |     }
  133 |     for(const app of ['reader','books'])await hit(products.locator(`.space-product-explore [data-open="${app}"]`));
  134 |     await products.locator('.space-product-explore [data-open="reader"]').click();await expect(page.locator('[data-space-window="reader"] [data-library-query]')).toBeVisible();
  135 |     await openApp(page,'products');await products.locator('.space-product-explore [data-open="books"]').click();
  136 |     const books=page.locator('[data-space-window="books"]'),cards=books.locator('.space-book');await expect(books).toBeVisible();await expect(cards).toHaveCount(4);
  137 |     for(let i=0;i<catalog.books.length;i++) {
  138 |       const book=catalog.books[i],card=cards.nth(i),cover=card.locator('.space-book__cover');
  139 |       await expect(cover.locator('strong')).toHaveText(book.title);await expect(cover.locator('.space-book__author')).toHaveText(book.author);await expect(card.locator('p')).toHaveText(book.description);
  140 |       expect(await projectedFontCSS(card.locator('p'))).toBeGreaterThanOrEqual(16);
  141 |       const measured=await cover.evaluate(el=>{
  142 |         const rgb=(value:string)=>{const n=value.match(/[\d.]+/g)!.map(Number);return {c:n.slice(0,3),a:n[3]??1};};
  143 |         const luminance=(c:number[])=>c.map(n=>n/255).map(n=>n<=.04045?n/12.92:((n+.055)/1.055)**2.4).reduce((sum,n,i)=>sum+n*[.2126,.7152,.0722][i],0);
  144 |         const background=rgb(getComputedStyle(el).backgroundColor),coverRect=el.getBoundingClientRect();
  145 |         return [...el.querySelectorAll('strong,small')].map(text=>{
  146 |           const foreground=rgb(getComputedStyle(text).color);let opacity=foreground.a;
  147 |           for(let node:Element|null=text;node;node=node.parentElement){opacity*=Number(getComputedStyle(node).opacity);if(node===el)break;}
  148 |           const composite=foreground.c.map((n,i)=>n*opacity+background.c[i]*(1-opacity));
  149 |           const a=luminance(composite),b=luminance(background.c),rect=text.getBoundingClientRect();
  150 |           return {text:text.textContent,ratio:(Math.max(a,b)+.05)/(Math.min(a,b)+.05),opaque:background.a===1,fits:rect.left>=coverRect.left&&rect.right<=coverRect.right+1&&rect.top>=coverRect.top&&rect.bottom<=coverRect.bottom+1};
  151 |         });
  152 |       });
  153 |       for(const text of measured){expect(text.opaque).toBe(true);expect(text.ratio,`${book.title}: ${text.text}`).toBeGreaterThanOrEqual(4.5);expect(text.fits).toBe(true);}
  154 |       const read=card.getByRole('link',{name:view.locale==='zh'?`阅读《${book.title}》 ↗`:`Read ${book.title} ↗`,exact:true});
  155 |       expect(await projectedFontCSS(read)).toBeGreaterThanOrEqual(13);await isolatedLinkClick(page,read,book.url);
  156 |     }
  157 |     expect(await fitsHorizontally(books.locator('[data-window-body]'))).toBe(true);
  158 |     if(view.width<=640) {
  159 |       const first=(await cards.nth(0).boundingBox())!,second=(await cards.nth(1).boundingBox())!;
  160 |       expect(second.y).toBeGreaterThan(first.y+first.height);expect(Math.abs(second.x-first.x)).toBeLessThan(1);
  161 |     }
  162 |     await hit(books.locator('.space-books-toolbar [data-open="reader"]'));await books.locator('.space-books-toolbar [data-open="reader"]').click();
  163 |     await expect(page.locator('[data-space-window="reader"] [data-library-query]')).toBeVisible();
  164 |     await openApp(page,'notes');expect(await editor.evaluate((el,previous)=>el===previous,original)).toBe(true);
  165 |     await expect(editor).toHaveValue('同一个输入框，先读产品和书，再接着写。');await editor.press('End');await editor.pressSequentially('继续。');
  166 |     await expect(editor).toHaveValue('同一个输入框，先读产品和书，再接着写。继续。');
  167 |     expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBeLessThanOrEqual(view.width);
  168 |   });
  169 | });
  170 | 
```