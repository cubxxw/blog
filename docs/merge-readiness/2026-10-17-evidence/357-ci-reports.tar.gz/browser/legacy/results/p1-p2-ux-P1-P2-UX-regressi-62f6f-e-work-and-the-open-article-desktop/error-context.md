# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: p1-p2-ux.spec.ts >> P1-P2 UX regression >> Space language changes preserve private work and the open article
- Location: tests/e2e/p1-p2-ux.spec.ts:205:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.isVisible: Test timeout of 30000ms exceeded.
Call log:
    - checking visibility of locator('[data-bear-workspace]').locator('[data-space-dock] [data-open="reader"]')

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=f1e2]:
    - generic [ref=f1e3]:
      - heading "Space · CUBXXW OS" [level=1] [ref=f1e4]
      - paragraph [ref=f1e5]: CUBXXW OS workspace
      - region "CUBXXW OS personal workspace" [ref=f1e6]:
        - generic [ref=f1e7]:
          - generic "3D café. Walk with WASD or arrow keys; drag to look around." [ref=f1e8]
          - generic "CUBXXW OS" [ref=f1e9]:
            - generic:
              - region "Welcome" [ref=f1e10]:
                - generic [ref=f1e11]:
                  - generic [ref=f1e12]:
                    - button "Close window" [ref=f1e13] [cursor=pointer]: ×
                    - button "Minimize window" [ref=f1e14] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=f1e15] [cursor=pointer]: +
                  - strong: Welcome
                  - button "Arrange windows" [ref=f1e16] [cursor=pointer]: ◫
                - article [ref=f1e18]:
                  - generic [ref=f1e19]:
                    - generic [ref=f1e20]: Xinwei Xiong / cubxxw
                    - button "About me ↗" [ref=f1e21] [cursor=pointer]
                  - group [ref=f1e22]:
                    - generic "About me and my story" [ref=f1e23] [cursor=pointer]:
                      - text: About me and my story
                      - generic [aria-hidden] [ref=f1e24]: ↗
                    - generic [ref=f1e25]:
                      - navigation "Profile sections" [ref=f1e26]:
                        - button "Profile" [ref=f1e27] [cursor=pointer]
                        - button "Along the way" [ref=f1e28] [cursor=pointer]
                        - button "Reading paths" [ref=f1e29] [cursor=pointer]
                      - generic [ref=f1e30]:
                        - paragraph [ref=f1e31]: CUBXXW / PROFILE
                        - heading "Xinwei Xiong cubxxw" [level=3] [ref=f1e32]
                        - paragraph [ref=f1e33]: Xinwei Xiong (熊鑫伟, aka cubxxw / BEAR, b. 2001) builds AI products with a focus on agent evaluation and reliable execution. He contributed to OpenIM's engineering and community workflows, and writes about projects and monthly reflections at cubxxw.com. Travel remains part of his life.
                        - paragraph [ref=f1e34]: To know myself more, and to know the world more.
                        - generic [ref=f1e35]:
                          - link "Resume and project evidence ↗" [ref=f1e36] [cursor=pointer]:
                            - /url: https://resume.cubxxw.com/en/
                          - link "GitHub ↗" [ref=f1e37] [cursor=pointer]:
                            - /url: https://github.com/cubxxw
                          - button "Say hello ↗" [ref=f1e38] [cursor=pointer]
                        - group [ref=f1e39]:
                          - generic "Full biography and public records" [ref=f1e40] [cursor=pointer]
                      - generic [ref=f1e41]:
                        - paragraph [ref=f1e42]: CUBXXW / ALONG THE WAY
                        - heading "Along the way" [level=3] [ref=f1e43]
                        - list [ref=f1e44]:
                          - listitem [ref=f1e45]:
                            - time [ref=f1e46]: "2021"
                            - generic [ref=f1e47]:
                              - heading "A first blog post" [level=4] [ref=f1e48]
                              - paragraph [ref=f1e49]: I created my GitHub account and began publishing my notes.
                              - group [ref=f1e50]:
                                - generic "More of the story" [ref=f1e51] [cursor=pointer]
                              - link "Read “My First Blog” ↗" [ref=f1e52] [cursor=pointer]:
                                - /url: /growth/posts/my-first-blog/
                          - listitem [ref=f1e53]:
                            - time [ref=f1e54]: "2023"
                            - generic [ref=f1e55]:
                              - heading "OpenIM and open source" [level=4] [ref=f1e56]
                              - paragraph [ref=f1e57]: I joined OpenIM as an intern, contributed code, and hosted community meetings.
                              - group [ref=f1e58]:
                                - generic "More of the story" [ref=f1e59] [cursor=pointer]
                              - link "Read the 2023 annual review ↗" [ref=f1e60] [cursor=pointer]:
                                - /url: /growth/posts/2023-annual-summary-reflections-and-aspirations/
                          - listitem [ref=f1e61]:
                            - time [ref=f1e62]: "2024"
                            - generic [ref=f1e63]:
                              - heading "Graduation and departure" [level=4] [ref=f1e64]
                              - paragraph [ref=f1e65]: My first trip abroad, graduation, a job, then leaving to travel and build.
                              - group [ref=f1e66]:
                                - generic "More of the story" [ref=f1e67] [cursor=pointer]
                              - link "Read the 2024 annual review ↗" [ref=f1e68] [cursor=pointer]:
                                - /url: /growth/posts/2024-annual-review/
                          - listitem [ref=f1e69]:
                            - time [ref=f1e70]: "2025"
                            - generic [ref=f1e71]:
                              - heading "The Annapurna Circuit" [level=4] [ref=f1e72]
                              - paragraph [ref=f1e73]: My first high-altitude trek. From February, I began writing monthly notes.
                              - group [ref=f1e74]:
                                - generic "More of the story" [ref=f1e75] [cursor=pointer]
                              - link "Read the 2025–2026 annual review ↗" [ref=f1e76] [cursor=pointer]:
                                - /url: /growth/posts/2025-annual-review/
                          - listitem [ref=f1e77]:
                            - time [ref=f1e78]: "2026"
                            - generic [ref=f1e79]:
                              - heading "Products and a new job" [level=4] [ref=f1e80]
                              - paragraph [ref=f1e81]: I kept building and writing. On August 10, after roughly two years away, I started a new job.
                              - group [ref=f1e82]:
                                - generic "More of the story" [ref=f1e83] [cursor=pointer]
                              - link "Read the August 2026 thought notes ↗" [ref=f1e84] [cursor=pointer]:
                                - /url: /growth/posts/2026-08-thought-notes/
                      - generic [ref=f1e85]:
                        - paragraph [ref=f1e86]: CUBXXW / READING PATHS
                        - group [ref=f1e88]:
                          - generic "Want to read my writing? Open four curated reading paths" [ref=f1e89] [cursor=pointer]:
                            - text: Want to read my writing?
                            - generic [ref=f1e90]: Open four curated reading paths
              - region "2026年10月思考笔记：日常与其他、AI 与 Agent 系统、工程与开源" [ref=f1e94]:
                - generic [ref=f1e95]:
                  - generic [ref=f1e96]:
                    - button "Close window" [ref=f1e97] [cursor=pointer]: ×
                    - button "Minimize window" [ref=f1e98] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=f1e99] [cursor=pointer]: +
                  - strong: 2026年10月思考笔记：日常与其他、AI 与 Agent 系统、工程与开源
                  - button "Arrange windows" [ref=f1e100] [cursor=pointer]: ◫
                - generic [ref=f1e101]:
                  - generic [ref=f1e102]:
                    - button "← Library" [ref=f1e103] [cursor=pointer]
                    - generic [ref=f1e104]:
                      - link "Original ↗" [ref=f1e105] [cursor=pointer]:
                        - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/
                      - 'button "Bookmark article: 2026年10月思考笔记：日常与其他、AI 与 Agent 系统、工程与开源" [ref=f1e106] [cursor=pointer]':
                        - generic [aria-hidden] [ref=f1e107]: ☆
                        - text: Save
                  - button "✳ Summarize this article" [ref=f1e109] [cursor=pointer]
                  - generic [ref=f1e110]:
                    - heading "2026年10月思考笔记：日常与其他、AI 与 Agent 系统、工程与开源" [level=2] [ref=f1e111]
                    - paragraph [ref=f1e112]: 2026.10.08 · growth
                  - generic [ref=f1e114]:
                    - blockquote [ref=f1e115]:
                      - paragraph [ref=f1e116]:
                        - strong [ref=f1e117]: 截至 10 月 8 日共 68 条公开笔记
                        - text: "| 记录时间：2026-10-01 — 2026-10-08"
                      - paragraph [ref=f1e118]:
                        - strong [ref=f1e119]: 主题分布
                        - text: ：日常与其他 20 条 · AI 与 Agent 系统 18 条 · 产品、工程与开源 11 条 · 自我认知与心理 10 条 · 阅读、思想与历史 3 条 · 旅行、地理与城市 3 条 · 内容、创作与记录 2 条 · 身体、健康与日常 1 条
                      - paragraph [ref=f1e120]: 以下保留截至 10 月 8 日的阅读摘录、产品设想和个人感受，按主题归档，条目内保留原始时间戳。本月仍在继续记录，一条私人谈话中的未核实指控未纳入公开归档。
                    - heading [level=2] [ref=f1e121]:
                      - text: 本月导航
                      - link "#" [ref=f1e122] [cursor=pointer]:
                        - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%9C%AC%E6%9C%88%E5%AF%BC%E8%88%AA
                    - paragraph [ref=f1e123]:
                      - strong [ref=f1e124]: 本月 68 条记录，按 8 个大方向归档：
                    - list [ref=f1e125]:
                      - listitem [ref=f1e126]:
                        - link "日常与其他" [ref=f1e127] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%e6%97%a5%e5%b8%b8%e4%b8%8e%e5%85%b6%e4%bb%96
                        - text: · 20 条
                      - listitem [ref=f1e128]:
                        - link "AI 与 Agent 系统" [ref=f1e129] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#ai-%e4%b8%8e-agent-%e7%b3%bb%e7%bb%9f
                        - text: · 18 条
                      - listitem [ref=f1e130]:
                        - link "产品、工程与开源" [ref=f1e131] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%e4%ba%a7%e5%93%81%e5%b7%a5%e7%a8%8b%e4%b8%8e%e5%bc%80%e6%ba%90
                        - text: · 11 条
                      - listitem [ref=f1e132]:
                        - link "自我认知与心理" [ref=f1e133] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%e8%87%aa%e6%88%91%e8%ae%a4%e7%9f%a5%e4%b8%8e%e5%bf%83%e7%90%86
                        - text: · 10 条
                      - listitem [ref=f1e134]:
                        - link "阅读、思想与历史" [ref=f1e135] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%e9%98%85%e8%af%bb%e6%80%9d%e6%83%b3%e4%b8%8e%e5%8e%86%e5%8f%b2
                        - text: · 3 条
                      - listitem [ref=f1e136]:
                        - link "旅行、地理与城市" [ref=f1e137] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%e6%97%85%e8%a1%8c%e5%9c%b0%e7%90%86%e4%b8%8e%e5%9f%8e%e5%b8%82
                        - text: · 3 条
                      - listitem [ref=f1e138]:
                        - link "内容、创作与记录" [ref=f1e139] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%e5%86%85%e5%ae%b9%e5%88%9b%e4%bd%9c%e4%b8%8e%e8%ae%b0%e5%bd%95
                        - text: · 2 条
                      - listitem [ref=f1e140]:
                        - link "身体、健康与日常" [ref=f1e141] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%e8%ba%ab%e4%bd%93%e5%81%a5%e5%ba%b7%e4%b8%8e%e6%97%a5%e5%b8%b8
                        - text: · 1 条
                    - separator [ref=f1e142]
                    - heading [level=2] [ref=f1e143]:
                      - text: 日常与其他
                      - link "#" [ref=f1e144] [cursor=pointer]:
                        - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%97%A5%E5%B8%B8%E4%B8%8E%E5%85%B6%E4%BB%96
                    - paragraph [ref=f1e145]:
                      - emphasis [ref=f1e146]: 20 条记录
                    - article [ref=f1e147]:
                      - heading [level=3] [ref=f1e148]:
                        - text: 群聊的本质是分类
                        - link "#" [ref=f1e149] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E7%BE%A4%E8%81%8A%E7%9A%84%E6%9C%AC%E8%B4%A8%E6%98%AF%E5%88%86%E7%B1%BB
                      - generic [ref=f1e150]: 2026-10-01 16:21:12
                      - paragraph [ref=f1e151]: 群聊的本质是分类
                    - article [ref=f1e152]:
                      - heading [level=3] [ref=f1e153]:
                        - text: town 的 Desktop setup
                        - link "#" [ref=f1e154] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#town-%E7%9A%84-desktop-setup
                      - generic [ref=f1e155]: 2026-10-03 17:30:26
                      - paragraph [ref=f1e156]: 很优雅，一条一条的链路一点点的开始和配置
                      - paragraph [ref=f1e157]: 配置的链路很长，所以一点点一点点的给用户一些反馈
                    - article [ref=f1e158]:
                      - heading [level=3] [ref=f1e159]:
                        - text: Nango 免费额度太低了
                        - link "#" [ref=f1e160] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#nango-%E5%85%8D%E8%B4%B9%E9%A2%9D%E5%BA%A6%E5%A4%AA%E4%BD%8E%E4%BA%86
                      - generic [ref=f1e161]: 2026-10-03 21:20:45
                      - paragraph [ref=f1e162]: 仅仅只是支持十个链接！！
                    - article [ref=f1e163]:
                      - heading [level=3] [ref=f1e164]:
                        - text: 阿嬷知道木生60年就死了，第一句话就是谢南枝她带这么
                        - link "#" [ref=f1e165] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E9%98%BF%E5%AC%B7%E7%9F%A5%E9%81%93%E6%9C%A8%E7%94%9F60%E5%B9%B4%E5%B0%B1%E6%AD%BB%E4%BA%86%E7%AC%AC%E4%B8%80%E5%8F%A5%E8%AF%9D%E5%B0%B1%E6%98%AF%E8%B0%A2%E5%8D%97%E6%9E%9D%E5%A5%B9%E5%B8%A6%E8%BF%99%E4%B9%88
                      - generic [ref=f1e166]:
                        - text: 2026-10-04 15:09:54 ·
                        - code [ref=f1e167]: "#阿嬷的情书"
                      - paragraph [ref=f1e168]: 阿嬷知道木生60年就死了，第一句话就是谢南枝她带这么多孩子得多辛苦啊
                    - article [ref=f1e169]:
                      - heading [level=3] [ref=f1e170]:
                        - text: 江海万里，心中念你，便不觉遥远
                        - link "#" [ref=f1e171] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%B1%9F%E6%B5%B7%E4%B8%87%E9%87%8C%E5%BF%83%E4%B8%AD%E5%BF%B5%E4%BD%A0%E4%BE%BF%E4%B8%8D%E8%A7%89%E9%81%A5%E8%BF%9C
                      - generic [ref=f1e172]:
                        - text: 2026-10-04 15:13:56 ·
                        - code [ref=f1e173]: "#阿嬷的情书"
                      - paragraph [ref=f1e174]: 湄南河畔木棉花盛开，像极了家乡的春天
                      - paragraph [ref=f1e175]: 压了一朵在信中，望你也能闻到花香
                    - article [ref=f1e176]:
                      - heading [level=3] [ref=f1e177]:
                        - text: 死亡率相对来说还好
                        - link "#" [ref=f1e178] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%AD%BB%E4%BA%A1%E7%8E%87%E7%9B%B8%E5%AF%B9%E6%9D%A5%E8%AF%B4%E8%BF%98%E5%A5%BD
                      - generic [ref=f1e179]:
                        - text: 2026-10-04 15:33:45 ·
                        - code [ref=f1e180]: "#阿嬷的情书"
                      - paragraph [ref=f1e181]: 1940 年代潮汕，汕头—曼谷已经是运行几十年的固定轮船航线，不再是早期那种主要靠木帆船、甚至被当猪仔塞进远洋船舱的时代
                      - paragraph [ref=f1e182]: 海航最大的问题的一般是的霍乱的问题
                      - paragraph [ref=f1e183]: 最早有段时间的是贩卖人口的年代
                      - paragraph [ref=f1e184]: 1847—1874 年，尤其集中在广东、福建沿海，经澳门、厦门、香港等港口，把大量中国青壮年运往古巴、秘鲁等地的糖厂、种植园、铁路和鸟粪矿
                      - paragraph [ref=f1e185]: 村里一个二十几岁的男人 → 被骗说去海外赚大钱 → 被带到澳门 → 关进猪仔馆 → 被迫签八年合同 → 上船 → 几个月横跨太平洋/大西洋 → 抵达秘鲁或古巴 → 被交给种植园或矿场。
                      - paragraph [ref=f1e186]: 几百个人在没有空调、没有现代厕所、通风极差的木船底层，连续航行几个月，死亡概率很高，是个有一二个死掉
                    - article [ref=f1e187]:
                      - heading [level=3] [ref=f1e188]:
                        - text: 或多或少经历过的一些人，也许都会信命吧
                        - link "#" [ref=f1e189] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%88%96%E5%A4%9A%E6%88%96%E5%B0%91%E7%BB%8F%E5%8E%86%E8%BF%87%E7%9A%84%E4%B8%80%E4%BA%9B%E4%BA%BA%E4%B9%9F%E8%AE%B8%E9%83%BD%E4%BC%9A%E4%BF%A1%E5%91%BD%E5%90%A7
                      - generic [ref=f1e190]: 2026-10-04 16:27:43
                      - paragraph [ref=f1e191]: 我觉得或多或少经历过的一些人，也许都会信命吧。因为命运带来的推拉感太重了，而且且也需要命运给自己带来一些支撑，带来一些力量。因为自己永远不知道这条路到底选择是不是对的。所以无非是从心学层面上给予自己的一些慰藉。
                    - article [ref=f1e192]:
                      - heading [level=3] [ref=f1e193]:
                        - text: 非常有意思的一部电影，由8个独立短片组成
                        - link "#" [ref=f1e194] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E9%9D%9E%E5%B8%B8%E6%9C%89%E6%84%8F%E6%80%9D%E7%9A%84%E4%B8%80%E9%83%A8%E7%94%B5%E5%BD%B1%E7%94%B18%E4%B8%AA%E7%8B%AC%E7%AB%8B%E7%9F%AD%E7%89%87%E7%BB%84%E6%88%90
                      - generic [ref=f1e195]:
                        - text: 2026-10-04 17:41:19 ·
                        - code [ref=f1e196]: "#黑泽明-梦"
                      - paragraph [ref=f1e197]: 我觉得这可能是黑泽明自己的天命，因为他自己做了，每个段开头都是“我做了这样一个梦”，据说这来自于他自己的梦
                      - paragraph [ref=f1e198]: 这部片就是同一个他，从小孩一直到老年，由8个梦连串起来，所以这部片是他在80岁的时候拍的
                      - paragraph [ref=f1e199]: 然后我们来看一看，为什么这部电影的视觉效果非常非常好。虽然没有那么多特效，整部片也没有连串的剧情，基本上都是各种动画色彩和氛围，像一幅画一样，像会动的画一样
                      - paragraph [ref=f1e200]: 但就很迷惑，这个画面是很美的，每一帧都可以当画去看。所以这就是黑泽明晚年最私人的一种作品：他对于自己战争的思考、对于自己核能的思考、人与自然关系的思考。然后包括有红色富士山，有一种寓言的感觉
                    - article [ref=f1e201]:
                      - heading [level=3] [ref=f1e202]:
                        - text: 用户会记住联系人而不是会记住会话
                        - link "#" [ref=f1e203] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E7%94%A8%E6%88%B7%E4%BC%9A%E8%AE%B0%E4%BD%8F%E8%81%94%E7%B3%BB%E4%BA%BA%E8%80%8C%E4%B8%8D%E6%98%AF%E4%BC%9A%E8%AE%B0%E4%BD%8F%E4%BC%9A%E8%AF%9D
                      - generic [ref=f1e204]: 2026-10-05 14:36:23
                      - paragraph [ref=f1e205]: 用户会记住联系人而不是会记住会话
                    - article [ref=f1e206]:
                      - heading [level=3] [ref=f1e207]:
                        - text: 对 rsi 的一些思考
                        - link "#" [ref=f1e208] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%AF%B9-rsi-%E7%9A%84%E4%B8%80%E4%BA%9B%E6%80%9D%E8%80%83
                      - generic [ref=f1e209]:
                        - text: 2026-10-05 16:47:42 ·
                        - code [ref=f1e210]: "#rsi"
                      - paragraph [ref=f1e211]: 通过开发更强大的模型来完善开发模型对应的方法等能力
                      - paragraph [ref=f1e212]: 但是核心的问题是效果越来越好未必代表智能程度提升
                      - paragraph [ref=f1e213]: 确实完成效果更好、成本更便宜，速度更快
                    - article [ref=f1e214]:
                      - heading [level=3] [ref=f1e215]:
                        - text: 我一直在思考，就是我们当前生活的世界到底是不是真实的
                        - link "#" [ref=f1e216] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%88%91%E4%B8%80%E7%9B%B4%E5%9C%A8%E6%80%9D%E8%80%83%E5%B0%B1%E6%98%AF%E6%88%91%E4%BB%AC%E5%BD%93%E5%89%8D%E7%94%9F%E6%B4%BB%E7%9A%84%E4%B8%96%E7%95%8C%E5%88%B0%E5%BA%95%E6%98%AF%E4%B8%8D%E6%98%AF%E7%9C%9F%E5%AE%9E%E7%9A%84
                      - generic [ref=f1e217]: 2026-10-05 23:18:50
                      - paragraph [ref=f1e218]: 好像自从我们出现之后，我们的世界变化飞快。从小时候开始陆续的通电和通水，再到后面，我们拥有了飞机，拥有了互联网，我们还拥有了智能手机，我们现在又出现了人工智能。也许再过 10 年，我们真的就像《骇客任务》那样，我们进入到一个虚拟世界，然后体验沉浸式的人生。可能随着世界模型的发展和演变，3D、VR 和 AR 的成熟，真的有可能到那一个阶段
                      - paragraph [ref=f1e219]: 包括，其实任天堂的游戏也是一样，就是数百万的玩家投入到其中，本质上就是参与一种轻量级的模拟。超级马里奥在屏幕上奔跑，他的世界可能并非是完整的存在的，但是随着他的前进立马就生效了，你走在墙后墙后才会被模拟出来。这就像我们现在这个世界，然后随着时间这个变量，然后往后延展，慢慢的。这个世界出现一些新的视图
                      - paragraph [ref=f1e220]: 也许我们就这样处于在一个模拟的世界，现在这个世界可能是虚假的，但也许我们眼中的世界是真实的，其实这样看之后，生活中好像很多压力都消散了。这个世界就是一个模拟的游戏，那我们能做的就是在这个游戏里面，去认真的生活，分辨哪些是命运，不过度紧张。然后遇到挑战，视为一个关卡，专心的去寻找解决方法就行！真的会给自己带来很大的松弛感。认真生活、热恋工作，不把自己看得太重了
                    - article [ref=f1e221]:
                      - heading [level=3] [ref=f1e222]:
                        - text: 日历设置一些重复的规则本身是很反人性以及约束人的
                        - link "#" [ref=f1e223] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%97%A5%E5%8E%86%E8%AE%BE%E7%BD%AE%E4%B8%80%E4%BA%9B%E9%87%8D%E5%A4%8D%E7%9A%84%E8%A7%84%E5%88%99%E6%9C%AC%E8%BA%AB%E6%98%AF%E5%BE%88%E5%8F%8D%E4%BA%BA%E6%80%A7%E4%BB%A5%E5%8F%8A%E7%BA%A6%E6%9D%9F%E4%BA%BA%E7%9A%84
                      - generic [ref=f1e224]: 2026-10-06 11:57:56
                      - paragraph [ref=f1e225]: 我每一次都不想看，一些之前定时调度的一些日历
                      - paragraph [ref=f1e226]: 每一阶段都有每一阶段的问题，对我来说，日历设置重复这个行为本身仅仅可以接受的是以月为单位或者以年 为单位或者有生命周期的周为单位，以及生命周期极短的天为单位
                    - article [ref=f1e227]:
                      - heading [level=3] [ref=f1e228]:
                        - text: 面对用户，永远做正确的事情
                        - link "#" [ref=f1e229] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E9%9D%A2%E5%AF%B9%E7%94%A8%E6%88%B7%E6%B0%B8%E8%BF%9C%E5%81%9A%E6%AD%A3%E7%A1%AE%E7%9A%84%E4%BA%8B%E6%83%85
                      - generic [ref=f1e230]: 2026-10-06 16:58:28
                      - paragraph [ref=f1e231]: 理解用户，保护用户的利益，为用户服务
                      - paragraph [ref=f1e232]: 这是最基本的产品道德
                    - article [ref=f1e233]:
                      - heading [level=3] [ref=f1e234]:
                        - text: 表达准确
                        - link "#" [ref=f1e235] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E8%A1%A8%E8%BE%BE%E5%87%86%E7%A1%AE
                      - generic [ref=f1e236]: 2026-10-06 22:09:06
                      - paragraph [ref=f1e237]: 不去浪费任何人的时间和精力
                      - paragraph [ref=f1e238]: 珍惜自己的时间，每一刻时间
                      - paragraph [ref=f1e239]: 自己是自由的
                      - paragraph [ref=f1e240]: 用于说不
                      - paragraph [ref=f1e241]: 用于拒绝
                      - paragraph [ref=f1e242]: 能发信息绝不电话，能电话绝不见面
                      - paragraph [ref=f1e243]: 能不做就不做
                    - article [ref=f1e244]:
                      - heading [level=3] [ref=f1e245]:
                        - text: 世界上有两种游戏，一种可称之为有限游戏
                        - link "#" [ref=f1e246] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E4%B8%96%E7%95%8C%E4%B8%8A%E6%9C%89%E4%B8%A4%E7%A7%8D%E6%B8%B8%E6%88%8F%E4%B8%80%E7%A7%8D%E5%8F%AF%E7%A7%B0%E4%B9%8B%E4%B8%BA%E6%9C%89%E9%99%90%E6%B8%B8%E6%88%8F
                      - generic [ref=f1e247]: 2026-10-08 12:41:40
                      - paragraph [ref=f1e248]: 世界上有两种游戏，一种可称之为有限游戏，另外一种称之为无限游戏
                      - paragraph [ref=f1e249]: 有限游戏以取胜为目的，无限游戏以延续游戏为目的
                      - paragraph [ref=f1e250]: 游戏有一个前提，无论是有限游戏还是无限游戏，除非的参与者自愿参加，否则就不存在游戏
                    - article [ref=f1e251]:
                      - heading [level=3] [ref=f1e252]:
                        - text: 有个很核心的点，是关于User input的过程
                        - link "#" [ref=f1e253] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%9C%89%E4%B8%AA%E5%BE%88%E6%A0%B8%E5%BF%83%E7%9A%84%E7%82%B9%E6%98%AF%E5%85%B3%E4%BA%8Euser-input%E7%9A%84%E8%BF%87%E7%A8%8B
                      - generic [ref=f1e254]: 2026-10-08 13:09:31
                      - paragraph [ref=f1e255]: 我觉得有个很核心的点，是关于User input的过程。User尽可能取决于它的intent，如果intent的意思足够明确，是一个确定性答案，而不是模糊答案的话，相对来说，我觉得这个过程应该尽可能轻量、直接。最好是在macOS上，以一种非常便捷、快速的方式去做input，我觉得这样会很方便
                      - paragraph [ref=f1e256]: 实际上，包括macOS在内，我自己在使用的时候也养成了一种习惯。因为macOS有语音输入，所以我在想，它的语音输入一般需要按option，长按option来唤醒，然后持续做一些转录
                      - paragraph [ref=f1e257]: 如果是关于macOS一些其他应用，比如笔记类应用，实际上用户打字记载是一件非常反心智的事情。这时候如果能快速积累这些原料，我觉得还是要把这个入口尽可能做得轻量，越轻量越好，所以它是一个很关键的能力
                    - article [ref=f1e258]:
                      - heading [level=3] [ref=f1e259]:
                        - text: 承诺不舒服也可以同时承认批评
                        - link "#" [ref=f1e260] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%89%BF%E8%AF%BA%E4%B8%8D%E8%88%92%E6%9C%8D%E4%B9%9F%E5%8F%AF%E4%BB%A5%E5%90%8C%E6%97%B6%E6%89%BF%E8%AE%A4%E6%89%B9%E8%AF%84
                      - generic [ref=f1e261]: 2026-10-08 13:43:29
                      - paragraph [ref=f1e262]: 承诺不舒服也可以同时承认批评
                    - article [ref=f1e263]:
                      - heading [level=3] [ref=f1e264]:
                        - text: 演员的本质就是忘掉自己，包括忘掉的自己的情感
                        - link "#" [ref=f1e265] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%BC%94%E5%91%98%E7%9A%84%E6%9C%AC%E8%B4%A8%E5%B0%B1%E6%98%AF%E5%BF%98%E6%8E%89%E8%87%AA%E5%B7%B1%E5%8C%85%E6%8B%AC%E5%BF%98%E6%8E%89%E7%9A%84%E8%87%AA%E5%B7%B1%E7%9A%84%E6%83%85%E6%84%9F
                      - generic [ref=f1e266]: 2026-10-08 13:43:38
                      - paragraph [ref=f1e267]: 演员的本质就是忘掉自己，包括忘掉的自己的情感，自己在那一刻成为角色本身，拥有角色的情感变化
                      - paragraph [ref=f1e268]: 所以要想进入一个角色，需要带入角色本身的情景，but 有些人可能非常认真的遮蔽自己本身，以至于他自己也相信自己的表演，忽略了目前的情感和自身情感的差别
                    - article [ref=f1e269]:
                      - heading [level=3] [ref=f1e270]:
                        - text: 人的所有的社会化属性，本质上都是一种角色
                        - link "#" [ref=f1e271] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E4%BA%BA%E7%9A%84%E6%89%80%E6%9C%89%E7%9A%84%E7%A4%BE%E4%BC%9A%E5%8C%96%E5%B1%9E%E6%80%A7%E6%9C%AC%E8%B4%A8%E4%B8%8A%E9%83%BD%E6%98%AF%E4%B8%80%E7%A7%8D%E8%A7%92%E8%89%B2
                      - generic [ref=f1e272]: 2026-10-08 13:46:52
                      - paragraph [ref=f1e273]: 人的所有的社会化属性，本质上都是一种角色，都有自己的有限性的优劣之分，但是自我是没有角色的
                    - article [ref=f1e274]:
                      - heading [level=3] [ref=f1e275]:
                        - text: 很讽刺
                        - link "#" [ref=f1e276] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%BE%88%E8%AE%BD%E5%88%BA
                      - generic [ref=f1e277]: 2026-10-08 14:41:56
                      - paragraph [ref=f1e278]: 很多父亲母亲，只要考虑自己，就会被说成自私
                      - paragraph [ref=f1e279]: 只要不再牺牲，就会被认为不够爱孩子，这样一来，母亲这个身份就占满了她，而她自己的需求没有同等资格进入考虑
                    - heading [level=2] [ref=f1e280]:
                      - text: AI 与 Agent 系统
                      - link "#" [ref=f1e281] [cursor=pointer]:
                        - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#ai-%E4%B8%8E-agent-%E7%B3%BB%E7%BB%9F
                    - paragraph [ref=f1e282]:
                      - emphasis [ref=f1e283]: 18 条记录
                    - article [ref=f1e284]:
                      - heading [level=3] [ref=f1e285]:
                        - text: 关于 AI 产品测试
                        - link "#" [ref=f1e286] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%85%B3%E4%BA%8E-ai-%E4%BA%A7%E5%93%81%E6%B5%8B%E8%AF%95
                      - generic [ref=f1e287]: 2026-10-01 14:23:26
                      - paragraph [ref=f1e288]: unit test、integration test、e2e test、ui test、agent testing、regression test
                      - paragraph [ref=f1e289]: 回归regression test是测试的目地，过去的一些测试都跑一遍，确保原来的功能没有被破坏
                      - paragraph [ref=f1e290]: agent testing ，测 AI agent 。准备 Eval set，用规则或者另外一个模型 llm as judge 打分
                      - paragraph [ref=f1e291]: 如何证明代码是对的？
                      - paragraph [ref=f1e292]: Eval / test 驱动开发，最重要的是先定义成功标准和约束
                      - paragraph [ref=f1e293]: 一定要有回归测试，不然 agent 修一个 bug 还会出现新的 but
                      - paragraph [ref=f1e294]: 测试 AI 依靠 Eval
                      - paragraph [ref=f1e295]: 改代码的模型和打分的模型分开
                      - paragraph [ref=f1e296]: 测试标准本身是壁垒，标准和数据是自己独有的 …. 最宝贵的
                    - article [ref=f1e297]:
                      - heading [level=3] [ref=f1e298]:
                        - text: codex 构建帮会计处理报税的 agent
                        - link "#" [ref=f1e299] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#codex-%E6%9E%84%E5%BB%BA%E5%B8%AE%E4%BC%9A%E8%AE%A1%E5%A4%84%E7%90%86%E6%8A%A5%E7%A8%8E%E7%9A%84-agent
                      - generic [ref=f1e300]: 2026-10-01 16:53:44
                      - paragraph [ref=f1e301]: 七千多分报税表，准确率高达97%
                      - paragraph [ref=f1e302]: agent 可以根据自己犯过的错误，持续的把自己改好
                      - paragraph [ref=f1e303]: 会计每次修正 agent 填错的字段，都会被记录下来
                      - paragraph [ref=f1e304]: 同类错误反复出现，就归纳成一个具体问题，再写成一组针对性的测试（eval）
                      - paragraph [ref=f1e305]: 让 Codex 去查代码，判断是哪一环出了问题（没抽取到信息、映射错了、选错了源文件，还是打分规则本身有问题），然后动手修
                      - paragraph [ref=f1e306]: 修完再跑一遍针对性测试和回归测试（确认没把原来好的地方改坏），通过后提 PR，由人审核再合并
                      - paragraph [ref=f1e307]: 这个人说的 evaluation harness（评测框架）加 self improvement（自我改进），就是在自己的项目里复刻这个闭环
                      - paragraph [ref=f1e308]: 如果 fixer 能看到 grader 怎么打分，甚至能改 grader，它就可能学会钻空子
                    - article [ref=f1e309]:
                      - heading [level=3] [ref=f1e310]:
                        - text: notion 还是需要一个模板的
                        - link "#" [ref=f1e311] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#notion-%E8%BF%98%E6%98%AF%E9%9C%80%E8%A6%81%E4%B8%80%E4%B8%AA%E6%A8%A1%E6%9D%BF%E7%9A%84
                      - generic [ref=f1e312]: 2026-10-03 16:24:10
                      - paragraph [ref=f1e313]: 定义的规则包括人如何去用，agent 如何去修改和撰写
                      - paragraph [ref=f1e314]: 越是人需要经常去看和维护的信息， AI 越是要小心调整
                    - article [ref=f1e315]:
                      - heading [level=3] [ref=f1e316]:
                        - text: AI 批量任务之前有一个问题：
                        - link "#" [ref=f1e317] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#ai-%E6%89%B9%E9%87%8F%E4%BB%BB%E5%8A%A1%E4%B9%8B%E5%89%8D%E6%9C%89%E4%B8%80%E4%B8%AA%E9%97%AE%E9%A2%98
                      - generic [ref=f1e318]: 2026-10-03 16:37:30
                      - paragraph [ref=f1e319]: 批量生成的真的能打得过别人针对某一个 feature 精心调整的吗？
                    - article [ref=f1e320]:
                      - heading [level=3] [ref=f1e321]:
                        - text: onboarding 这部分的设计
                        - link "#" [ref=f1e322] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#onboarding-%E8%BF%99%E9%83%A8%E5%88%86%E7%9A%84%E8%AE%BE%E8%AE%A1
                      - generic [ref=f1e323]: 2026-10-03 17:28:02
                      - paragraph [ref=f1e324]: 只要日历和邮箱，个人博客或者社媒信息可以额外补充，信息密度最高，门槛最低的数据源
                      - paragraph [ref=f1e325]: 然后交付价值，个人摘要，第一次让我感觉 town 好 tm 懂我啊，我更愿意去继续授权
                      - paragraph [ref=f1e326]: 推荐是基于我的数据的，基于对我的理解，以及他自己有的一个 mcp connection pool data 推荐我一些合适的，转化率很高
                      - paragraph [ref=f1e327]: sset Scheduling ，设置一些日程偏好，推荐给我
                      - paragraph [ref=f1e328]: 然后可以设置一些图像，可以设置我自己的 townie
                      - paragraph [ref=f1e329]: 再最后就是分享，share townie 可以获取积分
                      - separator [ref=f1e330]
                      - paragraph [ref=f1e331]: 额外补充：至于它适合做一些Onboarding流程，到底在哪一端去做，取决于这个平台的一些特性
                      - paragraph [ref=f1e332]: 如果是从官网上直接进来、还没有安装APP的用户，更适合直接在外部页面进行Onboarding
                      - paragraph [ref=f1e333]: 如果是通过桌面端登录的方式，更适合通过桌面端Onboarding，它可以连接本地的一些MCP或者本地环境
                      - paragraph [ref=f1e334]: 另外一点，如果通过iOS上面去链接，实际上会根据自己iPhone上面的特性，去做一些初始化的Onboarding，比如iOS原生的一些 actions button 截图、通知之类
                    - article [ref=f1e335]:
                      - heading [level=3] [ref=f1e336]:
                        - text: 我想专注那些长期可以复利的一些东西去做个人助手
                        - link "#" [ref=f1e337] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%88%91%E6%83%B3%E4%B8%93%E6%B3%A8%E9%82%A3%E4%BA%9B%E9%95%BF%E6%9C%9F%E5%8F%AF%E4%BB%A5%E5%A4%8D%E5%88%A9%E7%9A%84%E4%B8%80%E4%BA%9B%E4%B8%9C%E8%A5%BF%E5%8E%BB%E5%81%9A%E4%B8%AA%E4%BA%BA%E5%8A%A9%E6%89%8B
                      - generic [ref=f1e338]: 2026-10-04 11:51:38
                      - paragraph [ref=f1e339]: 侧重在和 AI 一起的那种成长感
                    - article [ref=f1e340]:
                      - heading [level=3] [ref=f1e341]:
                        - text: 用户故事应该和 evaluation
                        - link "#" [ref=f1e342] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E7%94%A8%E6%88%B7%E6%95%85%E4%BA%8B%E5%BA%94%E8%AF%A5%E5%92%8C-evaluation
                      - generic [ref=f1e343]: 2026-10-04 23:03:52
                      - paragraph [ref=f1e344]: 用户故事应该和 evaluation 一起连接管理起来的
                      - paragraph [ref=f1e345]: 用户故事分两层， 第一层是素材，尽量零摩擦
                      - paragraph [ref=f1e346]: notion 中只是存储会被反复引用的内容，所以真正有价值的maybe 是：
                      - paragraph [ref=f1e347]: 用户故事，真实的发生的，有效的场景，高价值场景，这部分可以反复用到，官网，核心链路，测试，故事
                      - paragraph [ref=f1e348]: 证据层，Eval 、日志
                      - paragraph [ref=f1e349]: 设计，Figma 一般就够了
                      - paragraph [ref=f1e350]: 决策，一般来说会记录出来的选过了什么， 为什么这样选，什么情况下推翻（负责维护 agent 系统）
                    - article [ref=f1e351]:
                      - heading [level=3] [ref=f1e352]:
                        - text: 用户故事的收集方法：
                        - link "#" [ref=f1e353] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E7%94%A8%E6%88%B7%E6%95%85%E4%BA%8B%E7%9A%84%E6%94%B6%E9%9B%86%E6%96%B9%E6%B3%95
                      - generic [ref=f1e354]: 2026-10-04 23:05:06
                      - paragraph [ref=f1e355]: 分两层。第一层是素材，尽量零摩擦：用户访谈、群聊截图、自己用产品时卡住的瞬间、录屏，统统先扔进原始资料区，标上日期和来源就行
                      - paragraph [ref=f1e356]: 第二层是提炼，每周从素材里挑出反复出现的故事，写成库里的一行，类型选「用户故事」。正文用固定的四段：谁、在什么情境下、想完成什么、现在卡在哪。最后一定要附上原始素材的链接
                      - paragraph [ref=f1e357]: 然后就是 evaluation ，实际上是和第二层的用户故事有关系
                      - paragraph [ref=f1e358]: 每个有效的用户故事都对应一组 eval case，故事说的是「用户要什么」，case 验证的是「我们做到了没有」。Notion 里只放 eval 的设计和结论：评什么、通过标准是什么、每次跑完的结果摘要、对应哪个 commit、得出了什么判断。case 本身和跑分数据放在仓库或 eval 平台里，Notion 只贴链接。数据量一大，放在 Notion 里谁都不会去维护
                    - article [ref=f1e359]:
                      - heading [level=3] [ref=f1e360]:
                        - text: 假期都快过了，今天是去咖啡馆，但是感觉每天都很忙
                        - link "#" [ref=f1e361] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%81%87%E6%9C%9F%E9%83%BD%E5%BF%AB%E8%BF%87%E4%BA%86%E4%BB%8A%E5%A4%A9%E6%98%AF%E5%8E%BB%E5%92%96%E5%95%A1%E9%A6%86%E4%BD%86%E6%98%AF%E6%84%9F%E8%A7%89%E6%AF%8F%E5%A4%A9%E9%83%BD%E5%BE%88%E5%BF%99
                      - generic [ref=f1e362]: 2026-10-05 18:22:06
                      - paragraph [ref=f1e363]: 假期都快过了，今天是去咖啡馆，但是感觉每天都很忙。就让我回想起来当天的时间线，我都是可以清晰的知道当天时间线在哪个位置的，以及在做什么。但是回过头来看我自己一天，让我总结出来我今天做了什么，好像有点卡顿
                      - paragraph [ref=f1e364]: 因为看似做了很多，看似学了很多东西，看似解决了很多的问题。但是现在回过头来一想，我今天好像什么都没有做
                      - paragraph [ref=f1e365]: 忙忙碌碌无所成的一天
                      - paragraph [ref=f1e366]: 我突然感悟到了，就是，包括乔布斯，包括马斯克，包括大家耳熟能详的科技领域的创始人，他们日常工作一定是非常非常忙碌的。乔布斯的话，他会去做一些时间管理或者精力管理。网络上也有各种的时间管理、精力管理的方法和工具。但是真正实践下来，我觉得还是很麻烦的，因为管理本身也是一种负担。就一天，如果我还要想，就是今天应该怎么样去列自己的行程，应该怎么样去列自己的安排，这个行为本身就是很消耗自己精力的
                      - paragraph [ref=f1e367]: 然后我突然想到，Eason 他对于自己的日常管理，他用到一个很牛逼的词，有有一个很牛逼的概念，就是瓶颈。就这个词他能够一直想啊，就是你可以去想一下，就是瓶颈是什么？你当前要做的这个事情，它的瓶颈是什么？就他就很明确，就是他就一个非常具体的事情，然后一个非常具体的意愿。然后概念又是思考的基本单位，你每天就可以基于这个概念去发散思考，去围绕这个概念去解决。那么你每天就有一个很清晰的主线，这个主线就很明确，它没有那么庞杂，没有那么零碎，它就一个很清晰的主线，这个主线就是你要解决你的当前这件事情的瓶颈，然后围绕这个瓶颈去思考怎么去解决。在这个过程中用到哪些方法？你把你的所有的注意力、精力、学习，还有时间全部都围绕在这个概念上面
                      - paragraph [ref=f1e368]: 而且瓶颈这个东西，它是可以一直思考的。就是你解决当前瓶颈，你可以继续去思考，就是下一个瓶颈是什么？下一个瓶颈是什么？
                      - paragraph [ref=f1e369]: 我现在突然开悟了，我觉得就是可能在未来 AI 时代，就是面对复杂的任务、复杂事件，尤其是一个对于一个需要做很多工作的个体来说，就是瓶颈它是一个非常好的方法，它比那个什么各种的精力管理、时间管理、任务清单都更有效。你每天都需要很明确的思考、很明确的定义，就是当当前问题是什么？最核心的瓶颈到底是什么？围绕这个瓶颈去不断地去思考解决。你每天也能很清晰地说出来，就是围绕这个瓶颈做了什么
                    - article [ref=f1e370]:
                      - heading [level=3] [ref=f1e371]:
                        - text: 继续上一篇，我觉得瓶颈还解决一个很重要的问题
                        - link "#" [ref=f1e372] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E7%BB%A7%E7%BB%AD%E4%B8%8A%E4%B8%80%E7%AF%87%E6%88%91%E8%A7%89%E5%BE%97%E7%93%B6%E9%A2%88%E8%BF%98%E8%A7%A3%E5%86%B3%E4%B8%80%E4%B8%AA%E5%BE%88%E9%87%8D%E8%A6%81%E7%9A%84%E9%97%AE%E9%A2%98
                      - generic [ref=f1e373]: 2026-10-05 18:28:12
                      - paragraph [ref=f1e374]: 继续上一篇，我觉得瓶颈还解决一个很重要的问题，就是保护好自己的注意力和时间，以及自己的精力。在一件最重要、最重要的事情上面
                      - paragraph [ref=f1e375]: 如果平常事情太多了，真的会很大程度上冲散自己的时间和精力，以至于自己好像被迫的去为了解决一些任务，或者是完成一些任务，来去被迫的分割自己的时间和精力。
                      - paragraph [ref=f1e376]: 然后如果是瓶颈，他会去强行的要求自己把所有的精力和时间握在手里，主动的为这个最大的、最重要的问题去选择性的分配。然后自己也可以把所有精力现行的放在这一件上事情上面，也不会导致自己会出现认知或者精力负载
                      - paragraph [ref=f1e377]: 比如说对我现阶段，我会觉得就是围绕最核心的一件事情，就是当前的 evaluation 或者是 agent 效果是否调得足够好，如果说 Agent 效果不好，那么就核心的分析就是为什么不好。这个瓶颈是什么，到底是架构问题？还是目前的 Workflow 问题？还是说一些 tools没有配好
                    - article [ref=f1e378]:
                      - heading [level=3] [ref=f1e379]:
                        - text: Self-modifying harness 是
                        - link "#" [ref=f1e380] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#self-modifying-harness-%E6%98%AF
                      - generic [ref=f1e381]: 2026-10-06 00:40:14
                      - paragraph [ref=f1e382]: Self-modifying harness 是 harness 下一阶段
                      - paragraph [ref=f1e383]: 本质上就是从 Extensible Harness（可扩展 harness）→ Reflective / Self-editing Harness（可自改 harness）
                      - paragraph [ref=f1e384]: Claude Code 上了 Mods：用几行 TypeScript，或直接让 Claude 写，改行为、改 UI、换功能；Mods 装在 plugin 里，CLI/桌面用 /plugin 安装。叙事是：每人工作方式不同，不该共用同一个 Claude 体验
                      - paragraph [ref=f1e385]: tianyi 表示DeepSeek Harness 从第一天就按 Cordis Everything is a plugin——model、tools、skills、session、sandbox、filesystem、loop、orchestration、UI 全是插件，可替换组合
                      - paragraph [ref=f1e386]: 本质上之前面临的问题就是 harness 太固定了，产品默认的 agent loop / UI / 工具集，用户只能用，不能改
                      - paragraph [ref=f1e387]: 而唯一用户可以自定义的MCP、skills 挂在harness 外；改不了 loop 本身、编排、沙箱、界面骨架
                      - paragraph [ref=f1e388]: 而且分发困难，好的定制没办法一键分享给别人，所以如何把 agent 产品做成可以组合、可以分发的 agent 运行时很重要
                      - paragraph [ref=f1e389]: Claude code mods 解决方案是：改 UI/行为、用 prompt 生成 mod，包括claude dev给出的一系列案例，如何调整 Claude 本身的页面，怎么帮你写 plugin
                      - paragraph [ref=f1e390]: DSH 更直接了，一切皆插件！
                      - paragraph [ref=f1e391]: 我觉得模型吸收 how；「产品长什么样、loop 怎么跑」正在被插件化 同一个模型，可能也会有不同的 harness 预设，围绕不同的类型的用户 Power user 可以直接按工作流改 UI、审批、工具组合，不用等官方排期
                    - article [ref=f1e392]:
                      - heading [level=3] [ref=f1e393]:
                        - text: 的瓶颈：
                        - link "#" [ref=f1e394] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E7%9A%84%E7%93%B6%E9%A2%88
                      - generic [ref=f1e395]: 2026-10-06 11:40:59
                      - paragraph [ref=f1e396]: notion 规范化，优化工作区
                      - paragraph [ref=f1e397]: Figma 完整实现
                      - paragraph [ref=f1e398]: evaluation 完成
                      - paragraph [ref=f1e399]: 新的 note 产品设计
                    - article [ref=f1e400]:
                      - heading [level=3] [ref=f1e401]:
                        - text: forgetting 比 memory 更重要
                        - link "#" [ref=f1e402] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#forgetting-%E6%AF%94-memory-%E6%9B%B4%E9%87%8D%E8%A6%81
                      - generic [ref=f1e403]: 2026-10-07 11:23:14
                      - paragraph [ref=f1e404]: 在真正的 agent 过程中，实际上大家都会发现，问题慢慢开始指向Memory，同样，Memory也是最难建立evaluation的
                      - paragraph [ref=f1e405]: total recall 实际上是一个负担，一方面指的是模型很容易的随着 context 爆炸智能水平降低，另外一方面实际上 context 实际上如果有一些误导的信息可能让 LLM 坚定错误的信念
                      - paragraph [ref=f1e406]: 所以准确少量的信息效果远远高于一堆垃圾信号杂糅的全量信息
                      - paragraph [ref=f1e407]: 对于 memory 网络上有很多成熟的方案了！ 但是对于 forgetting ，有三个评判标准，在业务中：
                      - paragraph [ref=f1e408]: 如果信息来源没那么可靠就不作数不可信的
                      - paragraph [ref=f1e409]: 有些信息是有时效性的，比如说某一个活动的信息，我参加过某一个活动的信息
                      - paragraph [ref=f1e410]: 发现错误后立即撤回，一个无法撤回错误的 agent，其实就是在自己的错误中越陷越深
                      - paragraph [ref=f1e411]: 实际上，上面3点也很有利于建立evaluation，我们再去评价什么事情应该记住，实际上是很难建立标准的，它非常依赖人的主观
                      - paragraph [ref=f1e412]: 但是，如果我们去对某些事情不应该记录，或者应该纠错，或者应该有时效性，我们是有一个很清晰判断的
                      - paragraph [ref=f1e413]: 事实上，这就是这个世界运作规律
                    - article [ref=f1e414]:
                      - heading [level=3] [ref=f1e415]:
                        - text: 我发现，实际上只是记录use case是没有意义的
                        - link "#" [ref=f1e416] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%88%91%E5%8F%91%E7%8E%B0%E5%AE%9E%E9%99%85%E4%B8%8A%E5%8F%AA%E6%98%AF%E8%AE%B0%E5%BD%95use-case%E6%98%AF%E6%B2%A1%E6%9C%89%E6%84%8F%E4%B9%89%E7%9A%84
                      - generic [ref=f1e417]: 2026-10-07 14:03:29
                      - paragraph [ref=f1e418]: 我发现，实际上只是记录use case是没有意义的。把use case列在一条一条note上面，丝毫没有意义，根本不会去看
                      - paragraph [ref=f1e419]: 但如果把它沉淀为evaluation，也就是沉淀为一些case，相对来说自己是有反馈的。因为实际上你要沉淀在自己的evaluation的一个CICD，然后deployment的系统里面去。这时候相对来说你要考虑的就是这个系统后端的维护，它有没有通过这个CICD。如果没有通过的话，你会反过来再推演这个evaluation，然后看有没有写其他的case，再继续补充
                      - paragraph [ref=f1e420]: 所以这还是一个增量，并不是说记了就over了
                    - article [ref=f1e421]:
                      - heading [level=3] [ref=f1e422]:
                        - text: 我自己有一套思维方式，我觉得非常有效，而且百试不厌
                        - link "#" [ref=f1e423] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%88%91%E8%87%AA%E5%B7%B1%E6%9C%89%E4%B8%80%E5%A5%97%E6%80%9D%E7%BB%B4%E6%96%B9%E5%BC%8F%E6%88%91%E8%A7%89%E5%BE%97%E9%9D%9E%E5%B8%B8%E6%9C%89%E6%95%88%E8%80%8C%E4%B8%94%E7%99%BE%E8%AF%95%E4%B8%8D%E5%8E%8C
                      - generic [ref=f1e424]: 2026-10-07 14:58:08
                      - paragraph [ref=f1e425]: 第一，在AI时代，我们应该怎么理解抽象？实际上，AI非常擅长抽象总结，所以我们可以利用AI做很多事情，比如搭建各种系统、各种框架。但是，随之而来的问题是，我们对于抽象的理解其实非常困难
                      - paragraph [ref=f1e426]: 比如，AI可以帮我们搭建一个分布式系统，也可以给我们搭建一个人生指南。但是它太抽象、太宏大了，我们只看到这个很熟悉的概念，却又很陌生。因为我们没有一套过去的成长体系或者经验体系，也没有各种具象化的内容，去给这个概念提供一些场景式、空间式的理解
                      - paragraph [ref=f1e427]: 随之而来的问题是：我们应该怎么样去理解这个抽象的概念
                      - paragraph [ref=f1e428]: 我的方法是：任何一个抽象概念一定要挖到底。我们写的时候，尽量以抽象的方式把它表达出来；但挖的时候，一定要把抽象的东西挖到非常非常具象
                      - paragraph [ref=f1e429]: 比如说一个很抽象的概念，自己不懂这个概念，就要一层一层地剥丝剖茧，不断往下挖：挖到下一层、再下一层、再下一层，一直挖到非常非常具象，自己能够非常非常明确地理解这个场景，并且能够用丰富的过去经验去建模。我觉得，到这个时候就已经是到底了
                    - article [ref=f1e430]:
                      - heading [level=3] [ref=f1e431]:
                        - text: 我突然想到，虽然我们在做 agent
                        - link "#" [ref=f1e432] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%88%91%E7%AA%81%E7%84%B6%E6%83%B3%E5%88%B0%E8%99%BD%E7%84%B6%E6%88%91%E4%BB%AC%E5%9C%A8%E5%81%9A-agent
                      - generic [ref=f1e433]: 2026-10-07 15:42:25
                      - paragraph [ref=f1e434]: 我突然想到，虽然我们在做 agent 系统或Evaluation系统的时候，可能涉及的链路会很长，相对来说，我们不知道会有什么样的链路，也不知道哪个节点需要保存到Evaluation
                      - paragraph [ref=f1e435]: 但我现在觉得，这个问题的答案还是要回归到用户身上：用户最终看到什么，以及为什么会这样看到，然后把这个事件本身抽离回Evaluation。也就是说，在设计Evaluation的时候，考虑的不仅仅是技术者能不能看懂、产品能不能看懂，更多的也是用户能不能看懂，那么它就是回归用户的
                      - paragraph [ref=f1e436]: 用户对其有所感知，所以 eval 的基本单位应该是用户可感知的事件，而不是内部的某一个节点。就比如说Agent提醒我回复A，但是A其实是已经回复过了，这是一个事件。它往回追到的可能是Memory没有更新，Tools读错了，或者是Prompt判断失误。但是这些节点还只作为归属在事件后面的，不单独作为评测的对象
                    - article [ref=f1e437]:
                      - heading [level=3] [ref=f1e438]:
                        - text: 我一直觉得Muse给每一个用户配置一个
                        - link "#" [ref=f1e439] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%88%91%E4%B8%80%E7%9B%B4%E8%A7%89%E5%BE%97muse%E7%BB%99%E6%AF%8F%E4%B8%80%E4%B8%AA%E7%94%A8%E6%88%B7%E9%85%8D%E7%BD%AE%E4%B8%80%E4%B8%AA
                      - generic [ref=f1e440]: 2026-10-08 00:41:56
                      - paragraph [ref=f1e441]: 我一直觉得Muse给每一个用户配置一个 Secure VM ，感觉成本会很高哇？因为免费额度相对来说也蛮多的，很多人都是奔着免费额度去的。如果后面没有一些额外的商业的模式的话（广告或者TOBmaybe乱七八糟的)，这笔账不好算！！
                      - paragraph [ref=f1e442]: 看到摩根士丹利（Morgan Stanley）在 2026 年 10 月初发布的测算数据
                      - paragraph [ref=f1e443]: 单用户服务成本每月在 3 美元到 130 美元 之间
                      - paragraph [ref=f1e444]: 假设用户每周消耗免费 Token 额度的 25%，Meta 维护一个普通免费用户的平均成本约为 37 美元/月
                      - paragraph [ref=f1e445]: 还包括沙箱的成本的， 虚拟机关机开启和运行浏览器的算力的
                      - paragraph [ref=f1e446]: 每一个免费版用户量化的数据（参考）：
                      - paragraph [ref=f1e447]: GPU 模型推理成本（约 65% | ~$24.00/月）
                      - paragraph [ref=f1e448]: CPU 与内存沙箱成本（约 26% | ~$9.50/月）
                      - paragraph [ref=f1e449]: 网络带宽与代理池流量（约 6% | ~$2.50/月）
                      - paragraph [ref=f1e450]: 存储与安全审计机制（约 3% | ~$1.00/月）
                      - paragraph [ref=f1e451]:
                        - link "https://finance.sina.com.cn/stock/usstock/c/2026-10-06/doc-iniuiewx5440212.shtml" [ref=f1e452] [cursor=pointer]:
                          - /url: https://finance.sina.com.cn/stock/usstock/c/2026-10-06/doc-iniuiewx5440212.shtml
                    - article [ref=f1e453]:
                      - heading [level=3] [ref=f1e454]:
                        - text: 我发现很多东西讲的都是常识，比如：随着风险增加
                        - link "#" [ref=f1e455] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%88%91%E5%8F%91%E7%8E%B0%E5%BE%88%E5%A4%9A%E4%B8%9C%E8%A5%BF%E8%AE%B2%E7%9A%84%E9%83%BD%E6%98%AF%E5%B8%B8%E8%AF%86%E6%AF%94%E5%A6%82%E9%9A%8F%E7%9D%80%E9%A3%8E%E9%99%A9%E5%A2%9E%E5%8A%A0
                      - generic [ref=f1e456]: 2026-10-08 13:24:23
                      - paragraph [ref=f1e457]: 我发现很多东西讲的都是常识，比如：随着风险增加，权限应该缩小；包括团队决定要做什么、分配预算、改变客户体验、做出承诺或者接受风险
                      - paragraph [ref=f1e458]: 这部分应该让人工智能作为决策辅助，而不应该主导整个链路，尽可能把决策链路交给人
                      - paragraph [ref=f1e459]: 其实相对来说，有些决策是单向门，有些决策是双向门。对于很多低成本、可撤销的工作任务，或者如果他的决策是一种双向门的话，相对来说带来的危害没有那么多。所以其实对这一类，user更愿意把决策交给AI自己评估
                      - paragraph [ref=f1e460]:
                        - link "https://uxdesign.cc/bounded-delegation-how-much-authority-should-ai-have-823a58fb4192" [ref=f1e461] [cursor=pointer]:
                          - /url: https://uxdesign.cc/bounded-delegation-how-much-authority-should-ai-have-823a58fb4192
                    - heading [level=2] [ref=f1e462]:
                      - text: 产品、工程与开源
                      - link "#" [ref=f1e463] [cursor=pointer]:
                        - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E4%BA%A7%E5%93%81%E5%B7%A5%E7%A8%8B%E4%B8%8E%E5%BC%80%E6%BA%90
                    - paragraph [ref=f1e464]:
                      - emphasis [ref=f1e465]: 11 条记录
                    - article [ref=f1e466]:
                      - heading [level=3] [ref=f1e467]:
                        - text: 设计去统一品味
                        - link "#" [ref=f1e468] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E8%AE%BE%E8%AE%A1%E5%8E%BB%E7%BB%9F%E4%B8%80%E5%93%81%E5%91%B3
                      - generic [ref=f1e469]: 2026-10-01 23:58:44
                      - paragraph [ref=f1e470]: 颜色、字号、间距、圆角、阴影、动效时长都定义成一组变量（design tokens），所有页面只能用这组变量
                      - paragraph [ref=f1e471]: 用一套成熟的体系，React + tailwind
                      - paragraph [ref=f1e472]: 组件基本基于 shadcn/ui 和 Radix 这类无样式的基础组件库。按钮、弹窗、下拉菜单、快捷键、无障碍这些基础功能，底座已经做好了，团队只需要在上面定义自己的风格
                      - paragraph [ref=f1e473]: 定时做一次 UI review ，找出细节的问题
                      - paragraph [ref=f1e474]: 把设计规范写成规则文件（比如 AGENTS.md 或 .cursor/rules），规定“只能用这些组件和 token，不许写死颜色”。AI 生成的初稿再由设计工程师打磨。这样既快，又不会越做越乱
                      - paragraph [ref=f1e475]: 每一次改动的话，相关的组件结合视觉回归测试 chromatic ，避免走样
                      - paragraph [ref=f1e476]: 优雅的产品通常在这几处下功夫：流畅的过渡动效（150 到 250 毫秒，很多用 Framer Motion）、骨架屏和流式输出（AI 产品尤其重要，避免干等）、完整的键盘快捷键和 Cmd+K 命令面板、深色模式、空状态和报错状态都有专门设计
                    - article [ref=f1e477]:
                      - heading [level=3] [ref=f1e478]:
                        - text: 核心的流程给 Playwright 测试
                        - link "#" [ref=f1e479] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%A0%B8%E5%BF%83%E7%9A%84%E6%B5%81%E7%A8%8B%E7%BB%99-playwright-%E6%B5%8B%E8%AF%95
                      - generic [ref=f1e480]: 2026-10-01 23:59:00
                      - paragraph [ref=f1e481]: 核心的流程给 Playwright 测试
                    - article [ref=f1e482]:
                      - heading [level=3] [ref=f1e483]:
                        - text: 人天生关注人和故事的，有冲突，有情绪
                        - link "#" [ref=f1e484] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E4%BA%BA%E5%A4%A9%E7%94%9F%E5%85%B3%E6%B3%A8%E4%BA%BA%E5%92%8C%E6%95%85%E4%BA%8B%E7%9A%84%E6%9C%89%E5%86%B2%E7%AA%81%E6%9C%89%E6%83%85%E7%BB%AA
                      - generic [ref=f1e485]: 2026-10-03 14:48:12
                      - paragraph [ref=f1e486]: 人天生关注人和故事的，有冲突，有情绪，和自己的身份有关系才值得聊，值得转发
                      - paragraph [ref=f1e487]: 产品本身只是工具，除非正好需要，否则很少有人主动关注
                      - paragraph [ref=f1e488]: muse 刷屏，靠的是事件，Meta 下场、冲到 App Store 第一、被亚马逊封杀。功能列表本身几乎没人讨论
                      - paragraph [ref=f1e489]: 中国社媒讨论最多的是和自己息息相关的，即使是宏大叙事也是和自己息息相关的宏大叙事，你不可能讨论另外一个你自己都不知道不认识的国家的某一个明星 ….
                    - article [ref=f1e490]:
                      - heading [level=3] [ref=f1e491]:
                        - text: sandbox 首先是涉及到执行啊
                        - link "#" [ref=f1e492] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#sandbox-%E9%A6%96%E5%85%88%E6%98%AF%E6%B6%89%E5%8F%8A%E5%88%B0%E6%89%A7%E8%A1%8C%E5%95%8A
                      - generic [ref=f1e493]: 2026-10-04 00:04:33
                      - paragraph [ref=f1e494]: sandbox 首先是涉及到执行啊，首先是在电脑的环境中，那么就是本质上是有不可信的执行在电脑上所以才需要
                      - paragraph [ref=f1e495]: 所以一般情况下数据库 CRUD 都不需要 sandbox
                      - paragraph [ref=f1e496]: 读取 S3 的文件也不需要 sandbox，这些都是后端代你执行的结构化 tools， 很明显的特征是参数是可以校验的，权限是可以控制到具体的行和用户的
                      - paragraph [ref=f1e497]: 另外即使是纯粹就是文件读写，其实也不需要sandbox，无非就是给一些read file、write file，这两个tools，后端直接读取用户前缀和 CRUD 没区别，关键是有没有 bash
                      - paragraph [ref=f1e498]: 那么需要 sandbox 的情况，就是跑 shell，比如说，执行模型写的代码，装一些依赖，然后开一个浏览器，再比如说 GREP、sed 这类命令处理一堆文件的时候，这时候是需要的到一个执行环境
                      - paragraph [ref=f1e499]: 如果是一些高频行为，就一定要做成结构化的tools。因为实际上，哪怕sandbox可以做，也完全没有必要；为了速度更快，更精准，也不要让它跨一些权限
                    - article [ref=f1e500]:
                      - heading [level=3] [ref=f1e501]:
                        - text: 我常用的三大 person context
                        - link "#" [ref=f1e502] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%88%91%E5%B8%B8%E7%94%A8%E7%9A%84%E4%B8%89%E5%A4%A7-person-context
                      - generic [ref=f1e503]: 2026-10-04 00:31:12
                      - paragraph [ref=f1e504]: 我常用的三大 person context 管理神器：
                      - paragraph [ref=f1e505]: notion， 最上层，定义框架，PRD，设计文档，use case ，ADR，路线图啥的，然后 spec 嵌入 Figma 链接和预览，底部再列出来 linear issue 或者 project ，notion 一般严格控制 AI 写入，一定要清晰知道 AI 写了什么哪些内容结构要清晰，距离人越近的东西要距离 AI 全自动化远一些
                      - paragraph [ref=f1e506]: Figma：这个写入一般都是 AI 去帮忙设计的，Figma mcp 订阅或者用 figwrite free，会在 怕个 上面标记 notion 的地址，会在各个细节功能模块 back 引用和加入对应的任务放入 linear 链接，AI 写入的 Figma 自己一定要反复人工 review ，以及Comment，AI 反过头修正调整修改
                      - paragraph [ref=f1e507]: linear ，这部分一般是自己给出的 title 内容方向自己清晰，AI 给出修改的描述任务，里面也会贴出来 Figma 的 frame 链接，方便 AI review
                      - paragraph [ref=f1e508]: Linear issue 里一定要带上 Notion spec 和 Figma frame 的链接，清晰上下文
                      - paragraph [ref=f1e509]: AI review 如果发现偏差，重大的偏差的话，需要补充偏差到 notion 中 Comment 方式，然后自己 review Comment 决定调整 notion 和 Figma
                      - paragraph [ref=f1e510]: notion 文档一定要放重复使用的，自己很清晰的内容，一些 AI 的设计啥的乱七八糟的直接丢到仓库的文档中，注释的方式连接到对应代码或者模块
                    - article [ref=f1e511]:
                      - heading [level=3] [ref=f1e512]:
                        - text: 对 superpowers 的判断
                        - link "#" [ref=f1e513] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%AF%B9-superpowers-%E7%9A%84%E5%88%A4%E6%96%AD
                      - generic [ref=f1e514]: 2026-10-05 16:55:21
                      - paragraph [ref=f1e515]: superpowers 可谓工程界最火方法论
                      - paragraph [ref=f1e516]: GitHub 近 30 万 star ，现在 v6.4.2 版本
                      - paragraph [ref=f1e517]: 作者说 v6 在他自己的评测里构建速度快了大约 50%、成本低了大约 60%
                      - paragraph [ref=f1e518]: 我之前一直在用 brainstorming 的部分，会让你开始不断的和你确认澄清需求，避免 LLM long time coding 发生偏离
                      - paragraph [ref=f1e519]: 然后还有就是他们的拆分工作单元、用隔离的 worktree 并行开发，这在长任务和多 agent 并行时尤其重要
                      - paragraph [ref=f1e520]: 以及我也用它把自己的一些标准沉淀为一些可以复用的工作流，比如说 TDD、代码 review 规则
                      - paragraph [ref=f1e521]: 还有就比如说systematic-debugging 和 writing-skills怎么样系统化的排查问题，以及如何写自己的 skills
                      - paragraph [ref=f1e522]: 其实随着模型的能力提升brainstorming可以降低，brainstorming 比原生的 plan mode 我觉得是好用的，但是如果简单的任务都走 brainstorming 挺消耗token 和时间的
                      - paragraph [ref=f1e523]: 我一般小任务不会用 brainstorming ，，然后同时使用精简版 writing-plans、systematic-debugging
                      - paragraph [ref=f1e524]: 只在大任务时开：subagent-driven-development、TDD、代码审查这一串
                      - paragraph [ref=f1e525]: 因为平常是多电脑开发， 我一般是 linear 做任务队列的
                      - paragraph [ref=f1e526]: 主电脑和 AI 对齐，跑 brainstorming 和 writing-plans，子电脑负责"做"，只跑执行、TDD 和验证
                      - paragraph [ref=f1e527]: 用 brainstorming 把需求问清楚，再用 writing-plans 拆成独立的工作单元。每个单元要能单独完成、单独验证，不互相依赖；有依赖的就在 Linear 里标 blocked by。
                      - paragraph [ref=f1e528]: 每个单元写成一张 Linear issue，描述用固定模板：
                      - paragraph [ref=f1e529]: 目标：一句话。
                      - paragraph [ref=f1e530]: 范围：允许改哪些文件或目录，禁止碰哪些。
                      - paragraph [ref=f1e531]: 验收标准：可执行的检查，比如哪些测试要通过、命令输出什么。
                      - paragraph [ref=f1e532]: 上下文：相关文件路径、计划文档链接。
                      - paragraph [ref=f1e533]: 执行模式：tdd 或 quick。
                      - paragraph [ref=f1e534]: 打上 agent-ready 标签，表示可以领取。
                      - paragraph [ref=f1e535]: 子电脑（执行者）
                      - paragraph [ref=f1e536]: 只装执行相关的 skill：executing-plans、test-driven-development、systematic-debugging、verification-before-completion。brainstorming 要关掉，不然它会反过来问问题，没法"无脑执行"。
                      - paragraph [ref=f1e537]: 每张 issue 用独立的 git worktree 和分支，分支名对应 issue 号，比如 xw-123，这样多台机器并行也不会冲突。
                      - paragraph [ref=f1e538]: 执行流程：领取 issue，状态改成 In Progress，按验收标准做，自检通过后提 PR，PR 链接回填到 Linear，状态改成 In Review。
                      - paragraph [ref=f1e539]: 遇到卡住或需要决策的情况，不要猜：在 issue 里留评论说明卡在哪，打上 needs-human 标签，然后去领下一张
                      - paragraph [ref=f1e540]: 主电脑用 code-review skill 审 PR，对照 issue 里的验收标准检查。通过就合并，issue 关闭；不通过就在 issue 里写清楚要改什么，重新打回 agent-ready
                    - article [ref=f1e541]:
                      - heading [level=3] [ref=f1e542]:
                        - text: 看了一下 Manus 的 cue， 还有 grok
                        - link "#" [ref=f1e543] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E7%9C%8B%E4%BA%86%E4%B8%80%E4%B8%8B-manus-%E7%9A%84-cue-%E8%BF%98%E6%9C%89-grok
                      - generic [ref=f1e544]: 2026-10-05 21:24:30
                      - paragraph [ref=f1e545]: 看了一下 Manus 的 cue， 还有 grok App、muse、dot
                      - paragraph [ref=f1e546]: 现在的 person agent 很流行 cloud Computer
                      - paragraph [ref=f1e547]: 我说个暴论，未来几年内还是个人电脑为主
                      - paragraph [ref=f1e548]: 现在的 sandbox 的成本已经很低了，E2B 按秒计算微，一次任务几分钱到几毛钱
                      - paragraph [ref=f1e549]: 一直挂着的小 VM ，大概每月几十刀起，Browser加Computer又更贵
                      - paragraph [ref=f1e550]: 每人一台 7×24 云电脑：用户一多，毛利很容易被基础设施吃掉
                      - paragraph [ref=f1e551]: Person agent 主要面对的还有用户对于数据以及代码信任问题，以及一些需要频繁验证的账户设备，之类的，有时候直接 UU 远程更方便，有时候还不如自己长期维护一个 Mac mini，提供给多个 person agent 远程操作，日常的代码，自动化的Browser use、Computer use，以及一些账户的管理和维护，都在这台电脑上会方便很多
                    - article [ref=f1e552]:
                      - heading [level=3] [ref=f1e553]:
                        - text: HeyGen 团队推出的 HyperFrames
                        - link "#" [ref=f1e554] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#heygen-%E5%9B%A2%E9%98%9F%E6%8E%A8%E5%87%BA%E7%9A%84-hyperframes
                      - generic [ref=f1e555]: 2026-10-06 16:05:04
                      - paragraph [ref=f1e556]: HeyGen 团队推出的 HyperFrames Studio
                      - paragraph [ref=f1e557]:
                        - link "https://github.com/heygen-com/hyperframes" [ref=f1e558] [cursor=pointer]:
                          - /url: https://github.com/heygen-com/hyperframes
                      - paragraph [ref=f1e559]: 把网页、代码或者改动脚本，做成可以持续编辑的视频项目
                      - paragraph [ref=f1e560]: 核心就是把 AI、编辑器、播放器和渲染程序共用同一份 html
                      - paragraph [ref=f1e561]: 可以用来把 PR 做成讲解视频，输入 GitHub 代码改动，输出带动态代码差异、旁白和字幕的视频
                      - paragraph [ref=f1e562]: 也可以作为产品发布短片： AI 从脚本到配乐选择，制作产品发布视频
                      - paragraph [ref=f1e563]: Typeframe：制作动态字幕视频，将语音配上逐词打字字幕和样式化布局，再导出
                      - paragraph [ref=f1e564]: 工作流套路：
                      - paragraph [ref=f1e565]: 先去收集网页素材和品牌信息，再写脚本、分镜和视觉规范，制作各个场景，加入配音，字母和专场，最后检查、预览和导出
                      - paragraph [ref=f1e566]: 从技术的本质上，对于一个 project，先去理解一件事情，把某个时刻出现什么样的画面写成代码
                    - article [ref=f1e567]:
                      - heading [level=3] [ref=f1e568]:
                        - text: 我现在 figma 设计方案是比较取巧的
                        - link "#" [ref=f1e569] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%88%91%E7%8E%B0%E5%9C%A8-figma-%E8%AE%BE%E8%AE%A1%E6%96%B9%E6%A1%88%E6%98%AF%E6%AF%94%E8%BE%83%E5%8F%96%E5%B7%A7%E7%9A%84
                      - generic [ref=f1e570]: 2026-10-06 16:32:12
                      - paragraph [ref=f1e571]: 我现在 figma 设计方案是比较取巧的，因为我是全栈的，所以相对来说有一套我自己的方法论。不过大家如果有更好的方法，也可以提出来
                      - paragraph [ref=f1e572]: 一般来说，主要的链路和重点的功能，用户只要花费 80% 以上的时间接触到的位置，我基本都会在 Figma 上详细的设计
                      - paragraph [ref=f1e573]: 基于一些边缘性的功能，或者是就是比较有深度的子功能，那么的话我相对来说会取巧，如果用户花费时间没有那么强的话，相对来说这部分我是直接在业务中去调整的，也就是说在后面直接让 AI 基于页面，去做微调。因为这时候如果去改 Figma 的话，一个是它的建立的连接会很混乱，就会干扰我的 Figma 设计。另外一个就是设计本身也是有一定复杂性的，从设计再到调整 UI，再到自己去 review，再到整个链路跑通是需要花费很长时间的，所以这部分我是愿意就是在主链路没有问题的情况下，适当的即兴发挥，去参考一些网络上比较好的设计，直接让他去改就好了
                      - paragraph [ref=f1e574]: 如果有一些非核心链路之外的，如果还有一些比较独立化的模块，他们如果需要设计的话，这种我也有两种方法。一种的话就是用 figma，在主链路之外再开一个 flow，去独立的设计这个模块，这个模块也是采用 80% 的原则，这时候其实还有一种方法，就是直接用 Claude Design 或者是 Open Design，去帮我去做这部分的模块能力，因为它相对来说很多时候它是独立的，所以直接就是建立一个 Web Demo，去基于 Web Demo 去微调，调到一个比较好的效果，直接去把这个 Web Demo 去克隆进去，把这个 Web Demo 最后是以一种外链的方式链接在 Figma 里面
                      - paragraph [ref=f1e575]: 实际上我对 AI 时代的 Figma 理解，实际上它当然也有自己独特的优势。因为它现在因为它有自己的 Agent 和 MCP，相对来说设计的能力，我觉得它是不弱于 Open Design，而且其实出样品的成功率还是非常非常高的，它本身也有很多的模板，这是我很愿意用 Figma 很重要的一个原因。另外一个原因是就是我觉得就是 AI 时代可能很多核心链路还是需要后面人不断去维护的。所以我就会有 80% 的原则去，再去发挥很多时间去维护这个主要链路。然后这个过程中需要人不断去调整、微调，精细化。但是实际上回归 Figma 设计的本质，设计的本质还是解决就是 coding 的过程中，coding 的成本过高，修改很成本也过高的一种先决条件。也就是说，当现在，因为以前没有 AI 的时候，实际上修改代码它是很难的，它需要产品经理和工程师相互去联动，包括后端的测试以及真实，还需要用户很多的反馈，整个链路跑通它的成本是很高的。但因为现在实际上 Vibe Coding 实际上一个人也可以做很多事情，相对来说，从设计，再到产品开发以及到功能实现，再包括后面的测试监控，它整个链路实际上是可以让一个人独立的完成整个的 feature 的。那么这时候实际上因为这个代码修改成本是很低的，所以相对来说，剩余的一些非核心电路的设计，相对来说我觉得可以不用非常满意，也就是说没有必要去设计的非常的精细化。那部分是可以在后面 coding 的过程中，然后一边 coding，然后一边去调整，就可以去真正的在工程实现中去边实现，然后边微调
                    - article [ref=f1e576]:
                      - heading [level=3] [ref=f1e577]:
                        - text: 如果Notion还交给AI去维护
                        - link "#" [ref=f1e578] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%A6%82%E6%9E%9Cnotion%E8%BF%98%E4%BA%A4%E7%BB%99ai%E5%8E%BB%E7%BB%B4%E6%8A%A4
                      - generic [ref=f1e579]: 2026-10-07 13:23:35
                      - paragraph [ref=f1e580]: 我觉得，如果Notion还交给AI去维护，它的管理成本实际上是非常非常高的。这个成本主要还是人的管理成本，因为AI输出可以很快，比如可以多版本输出、输出很多种方案。但是人管理起来就很麻烦了，所以Notion目前为止，我还是交给自己个人去管理
                      - paragraph [ref=f1e581]: 我会自己去定义每一个模板怎么敲定，结构怎么设计，架构是什么样子，以及分为多少个模块。具体比如系统架构模块里面，我甚至会详细地把几个关键的架构给定下来。后面AI去填充和修改的时候，直接基于原本的内容去给出适当的填充和修改
                      - paragraph [ref=f1e582]: 这样相对来说，人的理解成本还是比较低的
                    - article [ref=f1e583]:
                      - heading [level=3] [ref=f1e584]:
                        - text: 很多人都会说，flomo 都已经存在了
                        - link "#" [ref=f1e585] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%BE%88%E5%A4%9A%E4%BA%BA%E9%83%BD%E4%BC%9A%E8%AF%B4flomo-%E9%83%BD%E5%B7%B2%E7%BB%8F%E5%AD%98%E5%9C%A8%E4%BA%86
                      - generic [ref=f1e586]: 2026-10-08 15:09:14
                      - paragraph [ref=f1e587]: 很多人都会说，flomo 都已经存在了，还做记录app有什么意义
                      - paragraph [ref=f1e588]: but 我觉得，flomo 也许做的我足够喜欢我就不会有这样的想法了
                      - paragraph [ref=f1e589]: 我还是希望一个更具有灵魂的产品，触发人思考，让人不断想探索自己，扩展自己的产品！
                    - heading [level=2] [ref=f1e590]:
                      - text: 自我认知与心理
                      - link "#" [ref=f1e591] [cursor=pointer]:
                        - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E8%87%AA%E6%88%91%E8%AE%A4%E7%9F%A5%E4%B8%8E%E5%BF%83%E7%90%86
                    - paragraph [ref=f1e592]:
                      - emphasis [ref=f1e593]: 10 条记录
                    - article [ref=f1e594]:
                      - heading [level=3] [ref=f1e595]:
                        - text: 有一个很喜欢打听别人消息的朋友
                        - link "#" [ref=f1e596] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%9C%89%E4%B8%80%E4%B8%AA%E5%BE%88%E5%96%9C%E6%AC%A2%E6%89%93%E5%90%AC%E5%88%AB%E4%BA%BA%E6%B6%88%E6%81%AF%E7%9A%84%E6%9C%8B%E5%8F%8B
                      - generic [ref=f1e597]: 2026-10-03 01:19:14
                      - paragraph [ref=f1e598]: 有一个很喜欢打听别人消息的朋友，经常问我另外的一个朋友现状，相比较而言，好像有些人也是如此，很喜欢打听别人的消息，why?
                      - paragraph [ref=f1e599]: 打探别人消息本质回归到获取信息的本质
                      - paragraph [ref=f1e600]: 获取信息的本质是为了降低不确定性
                      - paragraph [ref=f1e601]: 所以打探消息，是为了通过了解别人，降低自己的不确定性，判断自己的处境，获取对关系的掌控
                      - paragraph [ref=f1e602]: 一个行为服务于自己的需要，不等于它就是恶意。 人关心朋友，可能也希望确认关系还亲近
                      - paragraph [ref=f1e603]: 每一次想了解的背后观察自己的动机，到底是好的出发点还是？
                      - paragraph [ref=f1e604]: 有人想靠近你，有人想和你比较，有人想判断你是否可靠，有人想获得谈资，也有人想抓住你的弱点
                      - paragraph [ref=f1e605]: 其实无论怎么样，对方不想说，就及时停下
                      - paragraph [ref=f1e606]: 判断对方知道之后如何使用这样的信息
                      - paragraph [ref=f1e607]: 以及他获取的信息是否是诚实的
                    - article [ref=f1e608]:
                      - heading [level=3] [ref=f1e609]:
                        - text: 之前去过清迈，看过他们放过天灯节和放过水灯节
                        - link "#" [ref=f1e610] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E4%B9%8B%E5%89%8D%E5%8E%BB%E8%BF%87%E6%B8%85%E8%BF%88%E7%9C%8B%E8%BF%87%E4%BB%96%E4%BB%AC%E6%94%BE%E8%BF%87%E5%A4%A9%E7%81%AF%E8%8A%82%E5%92%8C%E6%94%BE%E8%BF%87%E6%B0%B4%E7%81%AF%E8%8A%82
                      - generic [ref=f1e611]:
                        - text: 2026-10-04 14:28:40 ·
                        - code [ref=f1e612]: "#阿嬷的情书"
                      - paragraph [ref=f1e613]: 之前去过清迈，看过他们放过天灯节和放过水灯节，看过他们本地人的幸福，夫妻家人一起欢乐的放天灯，也有孤零零的一个人，满怀的期待，满怀的祝愿，放着天灯
                      - paragraph [ref=f1e614]: 我好像真的明白了天灯和水灯真的含义了，24 年那一场天灯节，那一场水灯节。在阿嬷的故事里面，他们有大量无家可归的人，相思的人
                      - paragraph [ref=f1e615]: 然后看到谢兰枝在放水的那一瞬间，真的很不可思议，好像从此开始坚守，我才发现原来是那么的有人味。当时天灯和水灯的时候还没有触动到我，总觉得观察下来，我觉得他们很幸福，很温馨。但是如果可以的话，我也希望放一个。原来相思、厮守、离别、思愁，都在一个天灯和一个水灯中，寄托着人与人之间的思念。原来经历过这种感觉。才会深深的触动到
                      - paragraph [ref=f1e616]: 水灯和天灯把人们的思念带向远方，带向对方。可能心理距离很远，可能现实上物理距离很远，异国他乡，有可能与世隔绝，生死相隔…他们留下来的都是一点点的人与人之间的感情，一点点的感动
                      - paragraph [ref=f1e617]: 总是在一点点地触动到自己的内心
                    - article [ref=f1e618]:
                      - heading [level=3] [ref=f1e619]:
                        - text: 泰国和马来西亚真的有很多的华人
                        - link "#" [ref=f1e620] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%B3%B0%E5%9B%BD%E5%92%8C%E9%A9%AC%E6%9D%A5%E8%A5%BF%E4%BA%9A%E7%9C%9F%E7%9A%84%E6%9C%89%E5%BE%88%E5%A4%9A%E7%9A%84%E5%8D%8E%E4%BA%BA
                      - generic [ref=f1e621]:
                        - text: 2026-10-04 15:12:58 ·
                        - code [ref=f1e622]: "#阿嬷的情书"
                      - paragraph [ref=f1e623]: 木生是在1948年为了躲避抓壮丁而下南洋。那时抗日战争已经结束，中国正在经历国共内战
                      - paragraph [ref=f1e624]: 潮汕此前已经遭受日军轰炸、占领和粮荒。汕头1939年沦陷后，粮食运输受到破坏，海外汇款也更难送到家。档案馆保存的真实侨批里，有人一边寄生活费，一边问家乡是否遭到轰炸、父母还能不能买到米
                      - paragraph [ref=f1e625]: 到了1948年，又叠加内战、征兵和严重通货膨胀。钱在迅速贬值，攒下来的积蓄未必保得住一家人的生活
                      - paragraph [ref=f1e626]: …
                    - article [ref=f1e627]:
                      - heading [level=3] [ref=f1e628]:
                        - text: 在潮汕，他们之间有一种很坚韧的关系，就是情谊
                        - link "#" [ref=f1e629] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%9C%A8%E6%BD%AE%E6%B1%95%E4%BB%96%E4%BB%AC%E4%B9%8B%E9%97%B4%E6%9C%89%E4%B8%80%E7%A7%8D%E5%BE%88%E5%9D%9A%E9%9F%A7%E7%9A%84%E5%85%B3%E7%B3%BB%E5%B0%B1%E6%98%AF%E6%83%85%E8%B0%8A
                      - generic [ref=f1e630]:
                        - text: 2026-10-04 15:38:15 ·
                        - code [ref=f1e631]: "#阿嬷的情书"
                      - paragraph [ref=f1e632]: 情谊不是友情，也不是爱情。它往往来自跨越山海的一种理解。情是感情的情，义是义气的义。因为对对方有这份理解，才能相互共鸣、相互共情。在危机的时候，就会抱紧在一起，共同面对
                      - paragraph [ref=f1e633]: 其实人与人之间的关系也是这样，不一定非要走向拥抱。我觉得，能在一个不确定的世界、一段危险的旅程里，两个人相互鼓励、相互坚守，给对方一些理解，给对方一些善意，就已经很圆满了。至于爱情，好像太奢侈了
                    - article [ref=f1e634]:
                      - heading [level=3] [ref=f1e635]:
                        - text: 黑泽明-梦 我觉得他才象征着三个阶段
                        - link "#" [ref=f1e636] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E9%BB%91%E6%B3%BD%E6%98%8E-%E6%A2%A6-%E6%88%91%E8%A7%89%E5%BE%97%E4%BB%96%E6%89%8D%E8%B1%A1%E5%BE%81%E7%9D%80%E4%B8%89%E4%B8%AA%E9%98%B6%E6%AE%B5
                      - generic [ref=f1e637]: 2026-10-04 19:41:25
                      - paragraph [ref=f1e638]: "#黑泽明-梦 我觉得他才象征着三个阶段。小时候好像自己很不受控，所以经常梦见那些很奇怪的梦。好像我小时候也是这样，梦到一些蛇，梦到一些蚂蚁，好像真的就来抓我了。所以小时候很害怕那些恐怖故事，他们真的有用。"
                      - paragraph [ref=f1e639]: 长大了之后，好像更多的是一些关于生活上的，工作上的一些痛苦。对工作失意。事业还没有成就，然后经常在职场中很痛苦、很纠结、很内耗。
                      - paragraph [ref=f1e640]: 在年长之后，好像更多是关于人生和意义的一些思考哲理，关于人类的意义、存在的意义、人与自然之间关系、人与世界之间关系、人和生命之间关系、生命的本源
                    - article [ref=f1e641]:
                      - heading [level=3] [ref=f1e642]:
                        - text: 焦虑也是一样啊
                        - link "#" [ref=f1e643] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E7%84%A6%E8%99%91%E4%B9%9F%E6%98%AF%E4%B8%80%E6%A0%B7%E5%95%8A
                      - generic [ref=f1e644]: 2026-10-05 13:55:47
                      - paragraph [ref=f1e645]: 很久之前，晚上睡不着，脑子里冒出一句：我好焦虑
                      - paragraph [ref=f1e646]: 然后事情就变了。我开始担心自己为什么焦虑，焦虑会不会影响明天，是不是最近状态很差……一个词，把一个晚上都拖进去了
                      - paragraph [ref=f1e647]: 如果不去说焦虑，我会怎么样？ 只是把当前的描述出来？
                      - paragraph [ref=f1e648]: 胸口有点紧。呼吸偏浅。脑子里反复出现一个关于明天会议的念头，反复出现的是自己出丑会怎么样
                      - paragraph [ref=f1e649]: 就这三样。说出来之后，它们反而小了。胸口紧，就深呼吸几次。那个念头，写下来留到明早再处理，这个过程是看见而不是定义，很多时候，很多情绪，只需要看见，然后清清楚楚写下来就好了，过段时间看就解决了
                      - paragraph [ref=f1e650]: 心理学里有个发现叫 affect labeling：准确描述情绪，能让情绪降温
                      - paragraph [ref=f1e651]: 庄子说得鱼而忘筌，名字是捕鱼的工具，不是鱼本身。佛学里也讲，所谓的我很焦虑，拆开来看不过是一些感受、一些念头，在这一刻聚在一起，下一刻又会散开
                      - paragraph [ref=f1e652]: 我的方法就是，察觉到有情绪，无论是好的情绪还是负面的情绪，自己第一反应是期望的，因为情绪帮我理解自己，我的每一次感动，每一次失望，每一次焦虑，如果看见了，好像就成长了
                      - paragraph [ref=f1e653]: 然后把情绪还原，这个时刻到底是发生了什么
                    - article [ref=f1e654]:
                      - heading [level=3] [ref=f1e655]:
                        - text: 观察自己，好像极简主义给予我很大的帮助
                        - link "#" [ref=f1e656] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E8%A7%82%E5%AF%9F%E8%87%AA%E5%B7%B1%E5%A5%BD%E5%83%8F%E6%9E%81%E7%AE%80%E4%B8%BB%E4%B9%89%E7%BB%99%E4%BA%88%E6%88%91%E5%BE%88%E5%A4%A7%E7%9A%84%E5%B8%AE%E5%8A%A9
                      - generic [ref=f1e657]: 2026-10-05 18:44:10
                      - paragraph [ref=f1e658]: 其实从小到大也是在城镇化的过程中，不断的迁移自己的家，从小学的时候在镇上的小学，初中的时候在另外一个镇上的初中，高中的时候在市区里面的一个高中，大学的时候在省会的一个大学
                      - paragraph [ref=f1e659]: 所以其实这个过程中，我慢慢的已经有了一种说走就走的习惯。对我来说，无论搬家、换工作，还是换生活、出国旅居、旅游，我都可以说走就走。它给我带来一个很大的好处，就是我不会去囤东西，不会去有消费的欲望，不会去买过多的珍藏品。在选购物品的时候尽量保持精简，避免过于复杂，尝试用最简单极简的生活，去创造丰富的人生
                      - paragraph [ref=f1e660]: 其实包括在我自己的日常中，好像也是这样。它会影响我自己的思维习惯，在做决策的时候，不会因为外界对物质因素去影响干预的决策，反而尽可能地想找到一些决策中最根本的一些变量，不会因为太过于顾虑一些没有发生的事情，或者是担心自己有所不适应，或者是担心这个现实世界有多么复杂，而去阻碍了自己向前决策的勇气，所以其实极简主义后我的选择是更多了的
                    - article [ref=f1e661]:
                      - heading [level=3] [ref=f1e662]:
                        - text: 那我觉得核心一点就是要不要分类问题
                        - link "#" [ref=f1e663] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E9%82%A3%E6%88%91%E8%A7%89%E5%BE%97%E6%A0%B8%E5%BF%83%E4%B8%80%E7%82%B9%E5%B0%B1%E6%98%AF%E8%A6%81%E4%B8%8D%E8%A6%81%E5%88%86%E7%B1%BB%E9%97%AE%E9%A2%98
                      - generic [ref=f1e664]: 2026-10-07 13:52:35
                      - paragraph [ref=f1e665]: 那我觉得核心一点就是要不要分类问题，因为很多零散想法就是，有没有必要分为几个类别。因为其实分类有一个很重要目的是为了去隔离它的context，以及或者是可能对于用户来说可能会有多种渠道嘛，就一个是怎么样去输入的渠道，以及输入的渠道可能不一样，它可能需要不同的一种类别，然后去定义这个，去，还有一个就是输出通道嘛，就是我们真实的去输入之后，然后后面在使用的时候，以及对于不同类别可能有一些不同的使用方式。但是呢，我在想，因为实际上分类还是一个非常的增加用户负担的事情，以及非常影响，就是潜意识会给用户心智增加很多的不确定性
                    - article [ref=f1e666]:
                      - heading [level=3] [ref=f1e667]:
                        - text: 萨特： 相信是知道自己相信，而知道自己相信
                        - link "#" [ref=f1e668] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E8%90%A8%E7%89%B9-%E7%9B%B8%E4%BF%A1%E6%98%AF%E7%9F%A5%E9%81%93%E8%87%AA%E5%B7%B1%E7%9B%B8%E4%BF%A1%E8%80%8C%E7%9F%A5%E9%81%93%E8%87%AA%E5%B7%B1%E7%9B%B8%E4%BF%A1
                      - generic [ref=f1e669]: 2026-10-08 14:17:39
                      - paragraph [ref=f1e670]: 萨特： 相信是知道自己相信，而知道自己相信，便不再是相信”
                      - paragraph [ref=f1e671]: To believe is to know you believe, and to know you believe is not to believe.
                      - paragraph [ref=f1e672]: 本质上讨论的是信念、自我意识与存在主义之间的关系
                      - paragraph [ref=f1e673]: 相信本身是一种悖论：相信一旦被意识化，便是因为自我反思而失去绝对性，真正的信念只能是那种我不自觉地、全身心地投向世界的态度，而非一个被标示、被审查的命题
                      - paragraph [ref=f1e674]: 但是如果是自己意识到了或者知道了，那么就失去了确定感了，我们怎么办 ？？？
                      - paragraph [ref=f1e675]: 看山是山，看山不是山，看山还是山
                      - paragraph [ref=f1e676]: 我们看清楚了本质，观察到自己，自己就没有那么投入了，就像是我们观察到自己整个恋爱的过程，观察者视角和体验者视角本身是不可能同时在一个时间碎片存在的，but 即使知道了自己问相信，看清楚了恋爱的本质，并没有的在逻辑上推翻没有恋爱的事实
                      - paragraph [ref=f1e677]: 想起来之前朋友有些是被宗教选择的，有些是看见宗教以及自己感受后离开的，还有些对宗教沉浸其中的
                      - paragraph [ref=f1e678]: 对于第三者来说，可能就是看山还是山的境界，他是把宗教信仰放在客观不确定与内在投入的张力里面，风险没有被知识完全消除，信仰任然可能成立，所以他对待爱情和友情也是这样
                      - paragraph [ref=f1e679]: 他知道友谊、婚姻或工作没有结果保证，仍然可以承担一次选择
                      - paragraph [ref=f1e680]: 相信和选择是两码事
                      - paragraph [ref=f1e681]: 母爱也是一个典型的例子，站在我00 后的角度上来看，实际上母亲那一代对我也是无私贡献的，对于这样的贡献会让我终生都会有一种愧疚心，实际上母亲是为了母亲这个身份牺牲掉自己自我的
                    - article [ref=f1e682]:
                      - heading [level=3] [ref=f1e683]:
                        - text: 想起来之前有一个朋友，她背景她也是一个亚洲的女生
                        - link "#" [ref=f1e684] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%83%B3%E8%B5%B7%E6%9D%A5%E4%B9%8B%E5%89%8D%E6%9C%89%E4%B8%80%E4%B8%AA%E6%9C%8B%E5%8F%8B%E5%A5%B9%E8%83%8C%E6%99%AF%E5%A5%B9%E4%B9%9F%E6%98%AF%E4%B8%80%E4%B8%AA%E4%BA%9A%E6%B4%B2%E7%9A%84%E5%A5%B3%E7%94%9F
                      - generic [ref=f1e685]: 2026-10-08 14:37:44
                      - paragraph [ref=f1e686]: 想起来之前有一个朋友，她背景她也是一个亚洲的女生，所以她相对来说就是也会有一些受到亚洲文化影响，她也会就蛮内向的，相对来说也是偏向于传统的一个女生。
                      - paragraph [ref=f1e687]: 她那个环境里面，我觉得她很神奇，就是她会主动表达出自己喜欢什么样男生，以及喜欢多少男生。就在东亚这个环境里面，可能大家都会对这样女生就会保留一定的自己的偏见吧。或者是叫成见更好一些。其不关是女生，包括在东亚男生。如果一个男生说，就是他喜欢什么类型的女生，喜欢多少女生，见过多少个女生，自己都很喜欢。那么东亚文化里面都会觉得他这就是一个渣男啊，就是是吧？还有各种名词，比如说水性杨花、渣女、海王、海女
                      - paragraph [ref=f1e688]: 因为这个女生她曾经也喜欢过我，就相对来说可能我身上有一些品质比较吸引到她。然后的话，就是我能理解到一些喜欢吧，就喜欢无非是自己内心的一种投射，所以我可以理解的和看见这种喜欢。但是，但是呢，我很明确的拒绝了，因为我觉得对她是没有太多的喜欢的。因为相对来说，我觉得她是一个蛮不错的朋友的，我愿意帮助她，但是这是基于朋友的友谊，而不是喜欢。
                      - paragraph [ref=f1e689]: 然后最近我又想到了这一点，就是我觉得就是可以大大方方承认自己喜欢的，这样的人其实是很厉害的，就是他们主体性都是蛮强的。他没有欺骗，没有隐瞒，就是没有受到自己的身份，或者是这种社会化文化过多的约束。当然也可能是因为他这样行为，就是大家都是受到社会化属性、社会化文化的一种约束，就大家都可能会产生一种文化偏好上的审美，就未必会对这样的人保持一种比较好的。文化上的吸引力
                      - paragraph [ref=f1e690]: 但是我又想到，其实这世界上无非就是大家都是在一个无限游戏里面，大家都在玩这个游戏。但无非是有些人他在人生经历中，对于某些有限游戏过于看重，比如说自己步入到某些身份，对这个身份过度的看重，而失去了自我。比如说我们在学生时代，对于学生这个身份过度看重，以至于我们成为了就是从小到大就是别人眼中的乖孩子，非常规规矩矩，就是走完学生生涯的这样一部些人，他们可能在这个社会上得到的风评比较好，但他们可能没有那么多自我了，因为相对来说就是人的本性，他们更多是被压抑过去的，更多是为了迎合这个文化之间的一些共同的标准，或者是一些比较好的审美，去为了迎合这个标准而去牺牲掉一部分自我。所以就是，其实我是蛮欣赏这样的，就是在每一个有限游戏中，也去带入到自己的主体性的人，并且有一些比较好强烈的主体性的人，他们真的很棒
                      - paragraph [ref=f1e691]: 她大致是一个真实在我生命中路过的真实的人
                    - heading [level=2] [ref=f1e692]:
                      - text: 阅读、思想与历史
                      - link "#" [ref=f1e693] [cursor=pointer]:
                        - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E9%98%85%E8%AF%BB%E6%80%9D%E6%83%B3%E4%B8%8E%E5%8E%86%E5%8F%B2
                    - paragraph [ref=f1e694]:
                      - emphasis [ref=f1e695]: 3 条记录
                    - article [ref=f1e696]:
                      - heading [level=3] [ref=f1e697]:
                        - text: 看完《阿嬷的情书》全程哭
                        - link "#" [ref=f1e698] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E7%9C%8B%E5%AE%8C%E9%98%BF%E5%AC%B7%E7%9A%84%E6%83%85%E4%B9%A6%E5%85%A8%E7%A8%8B%E5%93%AD
                      - generic [ref=f1e699]:
                        - text: 2026-10-04 15:08:01 ·
                        - code [ref=f1e700]: "#阿嬷的情书"
                      - paragraph [ref=f1e701]: 亲情真的好触动人
                      - paragraph [ref=f1e702]: 友情也真的好触动人
                      - paragraph [ref=f1e703]: 没想到，时间的坚守，真的真的很打动每一个人
                    - article [ref=f1e704]:
                      - heading [level=3] [ref=f1e705]:
                        - text: 很多人认为信命是一件很消极的事情
                        - link "#" [ref=f1e706] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%BE%88%E5%A4%9A%E4%BA%BA%E8%AE%A4%E4%B8%BA%E4%BF%A1%E5%91%BD%E6%98%AF%E4%B8%80%E4%BB%B6%E5%BE%88%E6%B6%88%E6%9E%81%E7%9A%84%E4%BA%8B%E6%83%85
                      - generic [ref=f1e707]: 2026-10-04 16:59:26
                      - paragraph [ref=f1e708]: 很多人认为信命是一件很消极的事情，好像作为新时代接班人，就应该坚信我命由我不由天，坚信物质是不依赖于人的意识而存在的客观实在，世界的本原是物质
                      - paragraph [ref=f1e709]: 我们命有两部分嘛，一个是不由我的部分，不由我的部分只有我去信了，就是我们一出生就注定好的，我的家庭、我的阶级以及我的社会地位，还有就是我出生之后的基因，我的一些性格，它可能从一开始就是已经注定了，因为它实际上是已在自我形成之前，它就不是我可以控制的
                      - paragraph [ref=f1e710]: 我觉得未必是一件很消极的事情。但确实随着年龄增长，发现很多事情确实是不由我所控的部分。那么从斯多葛达主义角度来说，我能做的仅仅是我可以控制的一部分，我不能控制的部分，坦然接受，顺其自然就好了
                      - paragraph [ref=f1e711]: 而且信命不代表自己就要依附于这个世界。我觉得并不是的。他相信的只是你自己进入这个世界，进入这个世界游戏，地球 online 的时候，自己的一些初始化数据就已经决定好了。但是在这个世界有了自我意识之后，你的玩法是可以自己去调整，可以自己去改变的。
                      - paragraph [ref=f1e712]: 并不仅仅是一个依附者，并不仅仅是依靠于这个世界给出自己的任务，然后自己去答题。不仅仅是依靠这个世界上自己的一些父母，或者是遇到的一些人生老师，或者是自己的公司领导，然后依靠他们去获取这个世界上自己的资源、自己的追求
                      - paragraph [ref=f1e713]: 也就是说，游戏的剧本还是需要自己去撰写的。在有自我意识之后，自己是可以去选择，可以自己去看见，可以自己去真实的实践，选择自己的道路
                      - paragraph [ref=f1e714]: 所以对比信命和不信命，我觉得就是一个硬币的一币两面。就信也好，不信也好，实际上就像是随缘不变，不变随缘，水是随着风揉成各种的形状，随风而漂泊，形状一直在变，但它始终是水，这是命中注定的部分。但是又是因为它是水，就是因为它命中注定是水，所以它可以被揉成各种的形状，可以是一种波浪，可以是一种圆圈，可以是波涛汹涌的海浪
                      - paragraph [ref=f1e715]: 所以，像水一样活着，看见水，接受水，成为水！
                    - article [ref=f1e716]:
                      - heading [level=3] [ref=f1e717]:
                        - text: 今年的诺贝尔物理学奖就颁了一位弗朗西斯·哈尔岑
                        - link "#" [ref=f1e718] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E4%BB%8A%E5%B9%B4%E7%9A%84%E8%AF%BA%E8%B4%9D%E5%B0%94%E7%89%A9%E7%90%86%E5%AD%A6%E5%A5%96%E5%B0%B1%E9%A2%81%E4%BA%86%E4%B8%80%E4%BD%8D%E5%BC%97%E6%9C%97%E8%A5%BF%E6%96%AF%E5%93%88%E5%B0%94%E5%B2%91
                      - generic [ref=f1e719]: 2026-10-07 21:19:27
                      - paragraph [ref=f1e720]: 我看了他呀，他的故事我觉得很触动到我，我想分享出来，或许会影响到很多人
                      - paragraph [ref=f1e721]: 徐东莲提过，哈尔岑是理论物理出身，却能把一个天马行空的想法一步步变成现实
                      - paragraph [ref=f1e722]: 他甚至能从柏林街头直接招募一位弹吉他的编程高手进团队，让这个人搭起了整个IceCube数据分析的软件框架
                      - paragraph [ref=f1e723]: 他的学生和合作者说，只要他在办公室（威斯康星大学麦迪逊分校），门总是敞开的，任何人随时可以进来找他聊天、讨论想法。只有开会的时候才会关上
                      - paragraph [ref=f1e724]: 一位IceCube的年轻研究者（他的“学术孙儿辈”）回忆：自己第一次在合作组会议上报告完结果，走下讲台时，哈尔岑默默走过来，什么话也没说，只是轻轻拍了自己几下肩膀
                      - paragraph [ref=f1e725]: 2024年，一位中国学生第一次去麦迪逊访问，午饭时问他：“是什么样的热情让你坚持到这把年纪？”
                      - paragraph [ref=f1e726]: 哈尔岑笑着回答：“我们花了30年时间建造冰立方探测器，现在是享受物理的时候了”
                      - paragraph [ref=f1e727]: 2026年诺奖公布时，他正在意大利出差，住在酒店房间写提案。听到消息后，他对媒体说自己打算继续待在房间里，因为“出去可能会给别人带来不便”
                      - paragraph [ref=f1e728]: 项目刚起步时，有几个研究生偷偷混进Caltech的钻探队，想把光电倍增管塞进南极冰洞里做实验。结果被发现后，NSF的人打电话给哈尔岑，以为是他指使的
                      - paragraph [ref=f1e729]: 他后来笑着讲这个故事，觉得那些学生很有意思
                      - paragraph [ref=f1e730]: 时间是宝贵的，人们不愿意浪费自己大量的人生和时间，甚至在一个不确定性的事情上，尤其是对于东亚人来说
                      - paragraph [ref=f1e731]: 但是弗朗西斯·哈尔岑可以持续地、几乎偏执地满足自己对某个问题的好奇心，并且把“行动”放在“思考为什么不可能”之前
                      - paragraph [ref=f1e732]: "他最有名的建议之一就是：“I always advise my students: don’t read too many books, do things!”"
                      - paragraph [ref=f1e733]: 他自己也承认，如果当年把关于冰光学的标准教科书读透了，很可能根本不会启动这个项目——因为书会告诉你“这几乎不可能”
                      - paragraph [ref=f1e734]: 他当时已经50岁左右，却像新人一样“无知而天真”，结果反而做成了
                    - heading [level=2] [ref=f1e735]:
                      - text: 旅行、地理与城市
                      - link "#" [ref=f1e736] [cursor=pointer]:
                        - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%97%85%E8%A1%8C%E5%9C%B0%E7%90%86%E4%B8%8E%E5%9F%8E%E5%B8%82
                    - paragraph [ref=f1e737]:
                      - emphasis [ref=f1e738]: 3 条记录
                    - article [ref=f1e739]:
                      - heading [level=3] [ref=f1e740]:
                        - text: 之前在福建，还有潮汕，尤其是潮汕那边
                        - link "#" [ref=f1e741] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E4%B9%8B%E5%89%8D%E5%9C%A8%E7%A6%8F%E5%BB%BA%E8%BF%98%E6%9C%89%E6%BD%AE%E6%B1%95%E5%B0%A4%E5%85%B6%E6%98%AF%E6%BD%AE%E6%B1%95%E9%82%A3%E8%BE%B9
                      - generic [ref=f1e742]:
                        - text: 2026-10-04 15:45:54 ·
                        - code [ref=f1e743]: "#阿嬷的情书"
                      - paragraph [ref=f1e744]: 其实之前在福建，还有潮汕，尤其是潮汕那边，汕头有一些博物馆，里面有很多关于出海的介绍和讲解，我觉得挺有启发的
                      - paragraph [ref=f1e745]: 包括好像在上海宝山海边，也有一个艺术馆，也是讲出海的，关于上海、老上海以及那些出海的人。但我觉得相对来说，我调研了一下，还是挺有启发的
                      - paragraph [ref=f1e746]: 最开始还是回到1840年到1875年。那时候因为贫困、战争以及人口压力，大量青年劳动力没有很好的工作
                      - paragraph [ref=f1e747]: 但是那时候欧美废除殖民地奴隶之后，都会有一些劳动力欠缺，所以那时候就会有很多人口买卖，主要还是去一些古巴、秘鲁这些地方
                      - paragraph [ref=f1e748]: 第一代的话，他们都会去干甘蔗、棉花、鸟粪矿、铁路之类的工作，这些人都会被称为猪仔，因为实际上他们相对来说没有那么自由。后面可能活下来的人会成为自由劳工，然后和小工贩
                      - paragraph [ref=f1e749]: 再到后面，就是加州淘金热时期。因为那时候美国正在建设铁路，所以相对来说，也会有很多移民去金矿、铁路、农场那边
                      - paragraph [ref=f1e750]: 再包括后面南洋经济繁荣的时候，那时候很流行去泰国、新加坡、马来西亚，包括一些菲律宾国家。他们大部分人的路径可能都是从劳工开始，再慢慢成为店主或者商人，然后开始永久定居
                      - paragraph [ref=f1e751]: 再到后面，可能到国内战争的时候，也就是中日战争和内战的时候，那时候东南亚的山口经济，还有它的港口城市爆发。包括曼谷、新加坡、槟城、吉隆坡、泗水这些地方，第一代移民都会去做一些工人、小商人之类的，所以他们就促进了当地一些华人城市社区的成熟，包括有些报纸、汇报、银行大量出现
                      - paragraph [ref=f1e752]: 再到后面，就是战争时代了。大战争时代，基本都会去全球的华人社会，很多家族基本上都是重置的状态，甚至家破人亡
                      - paragraph [ref=f1e753]: 再到后面，基本上就是移民的空缺。基本上1950年之后，到1970年都很少，相对来说一直到改革开放之后，可能那时候就更多了。然后全球留学的学生很多，从1980年到2000年。2000年到现在的话，基本留学生、工程师、创业者之类的越来越多
                    - article [ref=f1e754]:
                      - heading [level=3] [ref=f1e755]:
                        - text: 梦里关注的东西都很奇怪。梦里可能会梦见自己在下雪的场
                        - link "#" [ref=f1e756] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%A2%A6%E9%87%8C%E5%85%B3%E6%B3%A8%E7%9A%84%E4%B8%9C%E8%A5%BF%E9%83%BD%E5%BE%88%E5%A5%87%E6%80%AA%E6%A2%A6%E9%87%8C%E5%8F%AF%E8%83%BD%E4%BC%9A%E6%A2%A6%E8%A7%81%E8%87%AA%E5%B7%B1%E5%9C%A8%E4%B8%8B%E9%9B%AA%E7%9A%84%E5%9C%BA
                      - generic [ref=f1e757]: 2026-10-05 12:03:30
                      - paragraph [ref=f1e758]: 感觉梦里关注的东西都很奇怪。梦里可能会梦见自己在下雪的场景下，然后很开心。但实际上就是，在我平常可能都不会这么想，我觉得雪这东西都好像看过很多遍了，老家也是。然后包括自己户外徒步旅居的时候，也看到过很多雪。
                      - paragraph [ref=f1e759]: 所以我在想就是，因为做梦也是我做梦的嘛，所以日常也是我去接触这个世界，去感受、去思考。就这两个都是两个状态，临时组成的部分
                      - paragraph [ref=f1e760]: 就佛学它提倡无我，那么无我的话，就是由五欲或者是在时刻变化着，也就是说做梦的时候，它是另外一个聚集的一个状态。它可能有一些自己的轻重点，那么平常的时候我也会有我自己的轻重点
                    - article [ref=f1e761]:
                      - heading [level=3] [ref=f1e762]:
                        - text: 有时候学习了很多名词或者概念
                        - link "#" [ref=f1e763] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%9C%89%E6%97%B6%E5%80%99%E5%AD%A6%E4%B9%A0%E4%BA%86%E5%BE%88%E5%A4%9A%E5%90%8D%E8%AF%8D%E6%88%96%E8%80%85%E6%A6%82%E5%BF%B5
                      - generic [ref=f1e764]: 2026-10-05 13:52:16
                      - paragraph [ref=f1e765]: 其实有时候学习了很多名词或者概念，适当的时候我们应该放下他们 …
                      - paragraph [ref=f1e766]: 昨晚做了一个梦，梦到自己看到雪，在雪地中自由奔跑的画面，但是实际上现实中并不是非常喜欢雪，因为家乡也会下雪从小常见，后面户外也经常看到雪山, haking ,,,
                      - paragraph [ref=f1e767]: 我觉得可能是因为自己给雪这个动词或者形容词命名了，标记为名词! ， 所以想到雪回到过去的经历就是自己无数次看到过了，自己没那么喜欢
                      - paragraph [ref=f1e768]: 实际上，并不是！！ 我想起来小时候每一次看到雪也还是很兴奋的，所以想起来只是因为雪看腻了，而不是雪本身变得无聊，这个想的过程中就是名词的定义，但是如果我们不去定义这个雪会怎么样？ 我们去感受，感受那个画面，今天的光、空气的味道、雪落下来的声音。它们每一次都不一样
                      - paragraph [ref=f1e769]: 庄子有句话：荃者所以在鱼，得鱼而忘荃，名字是捕鱼的工具，用完了不必一直抓着，抓着不放就失去了，空杯可以装水，满杯什么都装不了～
                    - heading [level=2] [ref=f1e770]:
                      - text: 内容、创作与记录
                      - link "#" [ref=f1e771] [cursor=pointer]:
                        - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%86%85%E5%AE%B9%E5%88%9B%E4%BD%9C%E4%B8%8E%E8%AE%B0%E5%BD%95
                    - paragraph [ref=f1e772]:
                      - emphasis [ref=f1e773]: 2 条记录
                    - article [ref=f1e774]:
                      - heading [level=3] [ref=f1e775]:
                        - text: 去一个地方，不如深度地去观察这个地方、分析这个地方
                        - link "#" [ref=f1e776] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%8E%BB%E4%B8%80%E4%B8%AA%E5%9C%B0%E6%96%B9%E4%B8%8D%E5%A6%82%E6%B7%B1%E5%BA%A6%E5%9C%B0%E5%8E%BB%E8%A7%82%E5%AF%9F%E8%BF%99%E4%B8%AA%E5%9C%B0%E6%96%B9%E5%88%86%E6%9E%90%E8%BF%99%E4%B8%AA%E5%9C%B0%E6%96%B9
                      - generic [ref=f1e777]: 2026-10-04 20:29:52
                      - paragraph [ref=f1e778]: 我觉得去一个地方，不如深度地去观察这个地方、分析这个地方、接触这个地方不一样的体验。最终把它拍一个很独特的视频，这可能就是我们相对而言能够特立独行的风格吧。就不管是找本地人花钱，出一个渔村。总之就是各种体验。体验是宝贵的
                      - paragraph [ref=f1e779]: 但是具体是待多久呢？ 我觉得可能一个国家的城市待个一个月，是最好的时间
                    - article [ref=f1e780]:
                      - heading [level=3] [ref=f1e781]:
                        - text: 最近发生了一个很大的转变
                        - link "#" [ref=f1e782] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E6%9C%80%E8%BF%91%E5%8F%91%E7%94%9F%E4%BA%86%E4%B8%80%E4%B8%AA%E5%BE%88%E5%A4%A7%E7%9A%84%E8%BD%AC%E5%8F%98
                      - generic [ref=f1e783]: 2026-10-06 21:36:15
                      - paragraph [ref=f1e784]: 自己定义了notion 新的工作区
                      - paragraph [ref=f1e785]: 其中最重要的一个转变是把以前的 todo 哈 reminder 全部取消，换成 “Bottleneck”
                      - paragraph [ref=f1e786]: 因为我发现其实时间是最有限的资源大家都知道，但是管理好时间，就不管是时间管理还是精力管理，还是状态管理，我觉得最最最最最重要的并不是说管理我们去做什么，而是说管理我们不去做什么
                      - paragraph [ref=f1e787]: 得有一个不做清单，不然时间就会被耗掉了，在这个过程中，我自己定义的是：我当前最重要的，或者为了实现自己的愿景、实现当前这一阶段，当前的瓶颈到底是什么
                      - paragraph [ref=f1e788]: 然后围绕这个瓶颈，其他跟这个瓶颈没有那么重要的内容全部砍掉，全部都是无效的，包括各种无效的沟通，会议，文档，社交
                    - heading [level=2] [ref=f1e789]:
                      - text: 身体、健康与日常
                      - link "#" [ref=f1e790] [cursor=pointer]:
                        - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E8%BA%AB%E4%BD%93%E5%81%A5%E5%BA%B7%E4%B8%8E%E6%97%A5%E5%B8%B8
                    - paragraph [ref=f1e791]:
                      - emphasis [ref=f1e792]: 1 条记录
                    - article [ref=f1e793]:
                      - heading [level=3] [ref=f1e794]:
                        - text: 工业后的现象，真的是对的吗？它只是说是自然的
                        - link "#" [ref=f1e795] [cursor=pointer]:
                          - /url: http://127.0.0.1:1313/zh/growth/posts/2026-10-thought-notes/#%E5%B7%A5%E4%B8%9A%E5%90%8E%E7%9A%84%E7%8E%B0%E8%B1%A1%E7%9C%9F%E7%9A%84%E6%98%AF%E5%AF%B9%E7%9A%84%E5%90%97%E5%AE%83%E5%8F%AA%E6%98%AF%E8%AF%B4%E6%98%AF%E8%87%AA%E7%84%B6%E7%9A%84
                      - generic [ref=f1e796]: 2026-10-04 19:29:32
                      - paragraph [ref=f1e797]: 工业后的现象，真的是对的吗？它只是说是自然的，只是说是世界运作到现在而言，阶段化的产物
                      - paragraph [ref=f1e798]: 但是我们反过头来，我们思考的所有东西，不方便，这些东西服务的对象到底是什么？就比如说，你觉得电这东西需要吗？真的需要吗？电这东西它得到了电，但是我们失去了什么？我们看上去每天晚上灯火透亮的，好像灯光把整个城市给照亮了。但是黑夜就是黑夜，为什么一定要搞得像白天呢？为什么人就不能就正常的时候，晚上黑夜就正常睡觉，看看星星，白天起来生活工作，这样不是很好吗？
              - region "Your notes" [ref=f1e802]:
                - generic [ref=f1e803]:
                  - generic [ref=f1e804]:
                    - button "Close window" [ref=f1e805] [cursor=pointer]: ×
                    - button "Minimize window" [ref=f1e806] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=f1e807] [cursor=pointer]: +
                  - strong: Your notes
                  - button "Arrange windows" [ref=f1e808] [cursor=pointer]: ◫
                - generic [ref=f1e810]:
                  - generic [ref=f1e811]:
                    - generic [ref=f1e812]: A note of your own
                    - generic [ref=f1e813]:
                      - button "Save to sandbox" [ref=f1e814] [cursor=pointer]
                      - button "Export .md ↗" [ref=f1e815] [cursor=pointer]
                  - textbox "Your note" [ref=f1e816]:
                    - /placeholder: "What did this place make you think of?\n\nWrite it down. Come back and pick it up later."
                    - text: Private note stays here.
                  - generic [ref=f1e817]:
                    - generic [ref=f1e818]: Saved in this browser, never published
                    - generic [ref=f1e819]: 24 / 40000
              - region "Contact" [ref=f1e823]:
                - generic [ref=f1e824]:
                  - generic [ref=f1e825]:
                    - button "Close window" [ref=f1e826] [cursor=pointer]: ×
                    - button "Minimize window" [ref=f1e827] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=f1e828] [cursor=pointer]: +
                  - strong: Contact
                  - button "Arrange windows" [ref=f1e829] [cursor=pointer]: ◫
                - generic [ref=f1e831]:
                  - heading "Have a thought? Say hello." [level=2] [ref=f1e832]
                  - paragraph [ref=f1e833]: Product feedback, a conversation about writing, or a story from the road.
                  - generic [ref=f1e834]:
                    - link "GitHub ↗" [ref=f1e835] [cursor=pointer]:
                      - /url: https://github.com/cubxxw
                    - link "X ↗" [ref=f1e836] [cursor=pointer]:
                      - /url: https://x.com/cubxxw
                    - link "知乎 ↗" [ref=f1e837] [cursor=pointer]:
                      - /url: https://www.zhihu.com/people/3293172751
                    - link "LinkedIn ↗" [ref=f1e838] [cursor=pointer]:
                      - /url: https://www.linkedin.com/in/cubxxw
                    - link "Bilibili ↗" [ref=f1e839] [cursor=pointer]:
                      - /url: https://space.bilibili.com/1233089591
                    - link "YouTube ↗" [ref=f1e840] [cursor=pointer]:
                      - /url: https://www.youtube.com/channel/UC6l7tlUTrJFdDTMlR-X2MZQ
                    - link "Instagram ↗" [ref=f1e841] [cursor=pointer]:
                      - /url: https://www.instagram.com/cubxxw/
                    - link "Polarsteps ↗" [ref=f1e842] [cursor=pointer]:
                      - /url: https://www.polarsteps.com/cubxxw
                  - heading "Write a little note" [level=3] [ref=f1e843]
                  - textbox "Message draft" [ref=f1e844]:
                    - /placeholder: What would you like to tell me?
                    - text: A draft, not sent.
                  - generic [ref=f1e845]:
                    - link "Send by email ↗" [ref=f1e846] [cursor=pointer]:
                      - /url: mailto:3293172751nss@gmail.com?subject=Hello%20from%20BEAR%20Space&body=A%20draft%2C%20not%20sent.
                    - link "Leave a public GitHub message ↗" [ref=f1e847] [cursor=pointer]:
                      - /url: https://github.com/cubxxw/blog/issues/new?title=Hello%20from%20BEAR%20Space&body=A%20draft%2C%20not%20sent.
                    - link "WhatsApp ↗" [ref=f1e848] [cursor=pointer]:
                      - /url: https://wa.me/8618672749565
                  - paragraph [ref=f1e849]: The draft stays in your browser. Choose a channel and confirm sending there.
                  - button "Meet me through the AI guide" [ref=f1e850] [cursor=pointer]
              - region "Settings" [ref=f1e854]:
                - generic [ref=f1e855]:
                  - generic [ref=f1e856]:
                    - button "Close window" [ref=f1e857] [cursor=pointer]: ×
                    - button "Minimize window" [ref=f1e858] [cursor=pointer]: −
                    - button "Maximize or restore window" [ref=f1e859] [cursor=pointer]: +
                  - strong: Settings
                  - button "Arrange windows" [ref=f1e860] [cursor=pointer]: ◫
                - generic [ref=f1e862]:
                  - heading "Make this workspace yours." [level=2] [ref=f1e863]
                  - heading "Language" [level=3] [ref=f1e864]
                  - group "Interface language" [ref=f1e865]:
                    - button "中文" [ref=f1e866] [cursor=pointer]
                    - button "English" [pressed] [ref=f1e867] [cursor=pointer]:
                      - text: English
                      - generic [aria-hidden] [ref=f1e868]: ✓
                  - paragraph [ref=f1e869]: Change the language. Keep your notes and windows.
                  - heading "Café" [level=3] [ref=f1e870]
                  - group "Café" [ref=f1e871]:
                    - button "Change the scene" [ref=f1e872] [cursor=pointer]
                    - button "Back to the café" [ref=f1e873] [cursor=pointer]
                  - heading "Appearance" [level=3] [ref=f1e874]
                  - group "Appearance" [ref=f1e875]:
                    - button "Classic light" [pressed] [ref=f1e876] [cursor=pointer]
                    - button "Dark" [ref=f1e877] [cursor=pointer]
                  - heading "Desktop color" [level=3] [ref=f1e878]
                  - group "Desktop color" [ref=f1e879]:
                    - button "Classic teal" [pressed] [ref=f1e880] [cursor=pointer]
                    - button "Evening blue" [ref=f1e881] [cursor=pointer]
                    - button "Sage" [ref=f1e882] [cursor=pointer]
                  - heading "Available here" [level=3] [ref=f1e883]
                  - generic [ref=f1e884]:
                    - generic [ref=f1e885]: Windows, notes, bookmarks
                    - generic [ref=f1e886]: Saved in this browser
                  - generic [ref=f1e887]:
                    - generic [ref=f1e888]: Sign-in and cross-device sync
                    - generic [ref=f1e889]: Not connected
                  - generic [ref=f1e890]:
                    - generic [ref=f1e891]: Immich
                    - generic [ref=f1e892]: Load public content in Photos
                  - generic [ref=f1e893]:
                    - generic [ref=f1e894]: Linux sandbox
                    - generic [ref=f1e895]: Disconnected (local development only)
                  - paragraph [ref=f1e896]: The workspace remembers your layout and notes. Clearing site data removes them; export a copy first. The AI guide reads public material and does not publish or operate personal accounts.
                  - generic [ref=f1e897]:
                    - button "Export workspace" [ref=f1e898] [cursor=pointer]
                    - button "Arrange windows" [ref=f1e899] [cursor=pointer]
            - navigation "Application Dock" [ref=f1e903]:
              - button "CUBXXW OS Space menu" [ref=f1e904] [cursor=pointer]:
                - generic: CUBXXW OS
              - button "Welcome" [ref=f1e909] [cursor=pointer]
              - button "Writing" [ref=f1e917] [cursor=pointer]
              - button "Products" [ref=f1e923] [cursor=pointer]
              - button "Photos" [ref=f1e930] [cursor=pointer]
              - button "Your notes" [ref=f1e937] [cursor=pointer]
              - button "Space companion" [ref=f1e943] [cursor=pointer]
              - button "Settings" [ref=f1e949] [cursor=pointer]
        - navigation "Café navigation":
          - generic:
            - button "Back to the café" [ref=f1e955] [cursor=pointer]: ← Back to the café
            - generic: CUBXXW OS
            - button "Change the view" [ref=f1e956] [cursor=pointer]: Change the view ↗
```

# Test source

```ts
  112 |         await expect(page.locator('[data-contact-email]')).toHaveAttribute('href',/A%20private%20contact%20draft/);
  113 |       }
  114 |     }
  115 |     await settings.locator('[data-window-action="close"]').click();
  116 |     await expect(settings).toHaveCount(0);
  117 |     await expect(workspace.locator('[data-space-window][data-active="true"]')).toBeVisible();
  118 |     expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(page.viewportSize()!.width);
  119 |     expect(errors).toEqual([]);
  120 |   });
  121 | 
  122 |   test('space defaults to CUBXXW OS and switches to Product Lab and back', async ({ page }) => {
  123 |     await page.goto('/zh/projects/');
  124 |     await enterWorkspace(page);
  125 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  126 | 
  127 |     const space = page.locator('[data-product-space]');
  128 |     const bearButton = page.locator('.product-view-switch [data-product-view-button="bear"]');
  129 |     const labButton = page.locator('.space-menu [data-product-view-button="lab"]');
  130 |     const bearPanel = page.locator('[data-product-panel="bear"]');
  131 | 
  132 |     await expect(space).toHaveAttribute('data-product-view', 'bear');
  133 |     await expect(bearButton).toHaveAttribute('aria-pressed', 'true');
  134 |     await expect(bearPanel).toBeVisible();
  135 |     await expect(page.locator('[data-product-panel="lab"]')).toHaveCount(0);
  136 | 
  137 |     await page.locator('[data-space-menu-trigger]').click();
  138 |     await labButton.click();
  139 |     const labPanel = page.locator('[data-product-panel="lab"]');
  140 |     await expect(space).toHaveAttribute('data-product-view', 'lab');
  141 |     await expect(labButton).toHaveAttribute('aria-pressed', 'true');
  142 |     await expect(bearPanel).toBeHidden();
  143 |     await expect(labPanel).toBeVisible();
  144 |     await expect(page.locator('.product-view-switch [data-product-view-button="lab"]')).toBeFocused();
  145 |     await expect(page).toHaveURL(/#product-lab$/);
  146 | 
  147 |     await bearButton.click();
  148 |     await expect(space).toHaveAttribute('data-product-view', 'bear');
  149 |     await expect(bearButton).toHaveAttribute('aria-pressed', 'true');
  150 |     await expect(bearPanel).toBeVisible();
  151 |     await expect(labPanel).toBeHidden();
  152 |     await expect(page).not.toHaveURL(/#product-lab$/);
  153 |     await expect(page.locator('[data-space-menu-trigger]')).toBeFocused();
  154 |   });
  155 | 
  156 |   test('BEAR OS product search uses workspace search and restores the selected product', async ({ page }) => {
  157 |     await page.goto('/zh/projects/');
  158 |     await enterWorkspace(page);
  159 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  160 |     const workspace = page.locator('[data-bear-workspace]');
  161 |     await expect(workspace).toHaveAttribute('data-ready', 'true');
  162 |     const searchTrigger = workspace.locator('[data-space-menu-trigger]');
  163 |     await expect(searchTrigger).toBeVisible();
  164 |     await searchTrigger.focus();
  165 |     await page.keyboard.press(process.platform === 'darwin' ? 'Meta+k' : 'Control+k');
  166 |     const dialog = page.getByRole('dialog', { name: '搜索工作区' });
  167 |     await expect(dialog).toBeVisible();
  168 |     await expect(dialog.locator('[data-space-search-input]')).toBeFocused();
  169 |     await page.keyboard.press('Escape');
  170 |     await expect(dialog).toBeHidden();
  171 |     await expect(searchTrigger).toBeFocused();
  172 |     await expect(workspace.locator('[data-space-window="welcome"]')).toBeVisible();
  173 | 
  174 |     await searchTrigger.click();
  175 |     await workspace.locator('.space-menu [data-space-search-trigger]').click();
  176 |     await expect(dialog).toBeVisible();
  177 |     await dialog.locator('[data-space-search-input]').fill('solo');
  178 |     const result = dialog.locator('[data-search-kind="product"][data-search-payload="solo-compass"]');
  179 |     await expect(result).toHaveCount(1);
  180 |     await expect(result).toContainText('Solo Compass');
  181 |     await page.keyboard.press('ArrowDown');
  182 |     await expect(result).toBeFocused();
  183 |     await page.keyboard.press('Enter');
  184 |     await expect(dialog).toBeHidden();
  185 |     const product = workspace.locator('[data-space-window="products"]');
  186 |     await expect(product).toBeVisible();
  187 |     await expect(product.locator('.space-product h2')).toHaveText('Solo Compass');
  188 |     await expect(product.locator('[data-select-product="solo-compass"]')).toHaveAttribute('aria-pressed', 'true');
  189 |     const productState = () => page.evaluate(() => {
  190 |       const state = (window as unknown as {
  191 |         BearSpace: { snapshot: () => { windows: Array<{ app: string; payload: string; minimized: boolean }> } };
  192 |       }).BearSpace.snapshot().windows.find((win) => win.app === 'products');
  193 |       return { payload: state?.payload, minimized: state?.minimized };
  194 |     });
  195 |     await expect.poll(productState).toEqual({ payload: 'solo-compass', minimized: false });
  196 |     await product.locator('[data-window-action="minimize"]').click();
  197 |     await expect(product).toBeHidden();
  198 |     await expect.poll(productState).toEqual({ payload: 'solo-compass', minimized: true });
  199 |     await workspace.locator('[data-space-dock] [data-open="products"]').click();
  200 |     await expect(product).toBeVisible();
  201 |     await expect(product.locator('.space-product h2')).toHaveText('Solo Compass');
  202 |     await expect.poll(productState).toEqual({ payload: 'solo-compass', minimized: false });
  203 |   });
  204 | 
  205 |   test('Space language changes preserve private work and the open article', async ({ page }) => {
  206 |     await page.goto('/zh/projects/?profile=about#identity');
  207 |     const workspace = page.locator('[data-bear-workspace]');
  208 |     await expect(workspace).toHaveAttribute('data-ready', 'true');
  209 |     await enterWorkspace(page);
  210 |     const openApp = async (app: string) => {
  211 |       const dock = workspace.locator(`[data-space-dock] [data-open="${app}"]`);
> 212 |       if (await dock.isVisible()) await dock.click();
      |                      ^ Error: locator.isVisible: Test timeout of 30000ms exceeded.
  213 |       else {
  214 |         await workspace.locator('[data-space-menu-trigger]').click();
  215 |         await workspace.locator('.space-menu [data-space-launchpad-trigger]').click();
  216 |         await workspace.locator(`[data-launchpad-app="${app}"]`).click();
  217 |       }
  218 |     };
  219 |     await openApp('reader');
  220 |     await page.locator('[data-library-list] [data-open="reader"]').first().click();
  221 |     const article = page.locator('[data-reader-body] .post-content');
  222 |     await expect(article).toBeVisible();
  223 |     const original = await article.innerText();
  224 |     await openApp('notes');
  225 |     await page.locator('[data-note-editor]').fill('Private note stays here.');
  226 |     await openApp('contact');
  227 |     await page.locator('[data-message-draft]').fill('A draft, not sent.');
  228 |     await openApp('settings');
  229 |     const snapshot = () => page.evaluate(() => (window as unknown as { BearSpace: { snapshot: () => unknown } }).BearSpace.snapshot());
  230 |     const before = await snapshot();
  231 |     await page.locator('[data-set-language="en"]').click();
  232 |     await expect(page).toHaveURL(/\/projects\/\?profile=about#identity$/);
  233 |     await expect(workspace).toHaveAttribute('data-ready', 'true');
  234 |     await enterWorkspace(page);
  235 |     await expect(page.locator('[data-set-language="en"]')).toHaveAttribute('aria-pressed', 'true');
  236 |     expect(await snapshot()).toEqual(before);
  237 |     await openApp('reader');
  238 |     await expect.poll(() => article.innerText()).toBe(original);
  239 |     await openApp('notes');
  240 |     await expect(page.locator('[data-note-editor]')).toHaveValue('Private note stays here.');
  241 |     await openApp('contact');
  242 |     await expect(page.locator('[data-message-draft]')).toHaveValue('A draft, not sent.');
  243 |   });
  244 | 
  245 |   for (const blocked of ['local', 'session'] as const) {
  246 |     test(`Space preserves work when ${blocked} storage fails during a language change`, async ({ page }) => {
  247 |       await page.addInitScript((blocked) => {
  248 |         const original = Storage.prototype.setItem;
  249 |         Storage.prototype.setItem = function (key, value) {
  250 |           if ((blocked === 'local' && this === localStorage && key === 'bear-space:v1') || (blocked === 'session' && this === sessionStorage)) {
  251 |             throw new DOMException('Storage is unavailable', 'QuotaExceededError');
  252 |           }
  253 |           return original.call(this, key, value);
  254 |         };
  255 |       }, blocked);
  256 |       await page.goto('/zh/projects/?profile=about#identity');
  257 |       const workspace = page.locator('[data-bear-workspace]');
  258 |       await expect(workspace).toHaveAttribute('data-ready', 'true');
  259 |       await enterWorkspace(page);
  260 |       await page.evaluate(() => (window as unknown as { BearSpace: { execute: (name: string, args: object) => unknown } }).BearSpace.execute('note', { text: 'Keep this private note.' }));
  261 |       await workspace.locator('[data-space-dock] [data-open="settings"]').click();
  262 |       const snapshot = () => page.evaluate(() => (window as unknown as { BearSpace: { snapshot: () => unknown } }).BearSpace.snapshot());
  263 |       const before = await snapshot();
  264 |       await page.locator('[data-set-language="en"]').click();
  265 |       if (blocked === 'local') {
  266 |         await expect(page).toHaveURL(/\/zh\/projects\/\?profile=about#identity$/);
  267 |         await expect(workspace.locator('[data-space-toast]')).toContainText('导出');
  268 |       } else {
  269 |         await expect(page).toHaveURL(/\/projects\/\?profile=about#identity$/);
  270 |         await enterWorkspace(page);
  271 |         await expect(page.locator('[data-set-language="en"]')).toHaveAttribute('aria-pressed', 'true');
  272 |       }
  273 |       expect(await snapshot()).toEqual(before);
  274 |       await expect(workspace.locator('[data-space-window="settings"]')).toBeVisible();
  275 |     });
  276 |   }
  277 | 
  278 |   test('Product Lab can enter BEAR knowledge space and return without leaving lab', async ({ page }) => {
  279 |     await page.goto('/zh/projects/');
  280 |     await enterWorkspace(page);
  281 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  282 | 
  283 |     await page.locator('[data-space-menu-trigger]').click();
  284 |     await page.locator('.space-menu [data-product-view-button="lab"]').click();
  285 |     await page.getByRole('button', { name: '进入知识空间' }).click();
  286 | 
  287 |     const host = page.locator('[data-bks-host]');
  288 |     await expect(page).toHaveURL(/#knowledge$/);
  289 |     await expect(host).toBeVisible();
  290 |     await expect(host.locator('.bks__chip').first()).toBeVisible();
  291 |     await expect(host.locator('.bks__title')).toHaveText('产品与写作如何连成一条线');
  292 |     await expect(host.getByText('BEAR 知识空间', { exact: true })).toBeVisible();
  293 |     // Ordinary page scroll stays available (no overflow lock).
  294 |     await expect(page.locator('body')).not.toHaveClass(/overflow-hidden|scroll-locked/);
  295 | 
  296 |     await page.keyboard.press('Escape');
  297 |     await expect(page).toHaveURL(/#product-lab$/);
  298 |     await expect(host).toBeHidden();
  299 |     await expect(page.locator('[data-product-panel="lab"]')).toBeVisible();
  300 |     await expect(page.getByRole('button', { name: '进入知识空间' })).toBeVisible();
  301 |   });
  302 | 
  303 |   test('an already open global search owns shortcuts above the BEAR workspace', async ({ page }) => {
  304 |     await page.goto('/zh/projects/');
  305 |     await enterWorkspace(page);
  306 |     await expect(page.locator('[data-bear-workspace]')).toHaveAttribute('data-cafe-mode', 'desktop');
  307 |     const globalSearch=page.locator('#search-command-palette');
  308 |     const workspaceSearch=page.locator('[data-space-search]');
  309 |     for(const key of [process.platform==='darwin'?'Meta+k':'Control+k','Escape']) {
  310 |       if (await page.locator('[data-bear-workspace]').isVisible()) { await page.locator('[data-space-menu-trigger]').click(); await page.locator('.space-menu [data-product-view-button="lab"]').click(); }
  311 |       await page.locator('[data-search-trigger="nav"]').click();
  312 |       await expect(globalSearch).toBeVisible();
```