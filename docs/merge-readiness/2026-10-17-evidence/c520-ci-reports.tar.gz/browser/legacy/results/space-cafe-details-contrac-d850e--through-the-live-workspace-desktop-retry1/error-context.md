# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: space-cafe-details-contracts.spec.ts >> six scene changes and both detail views preserve the original Notes node, draft and selection through the live workspace
- Location: tests/e2e/space-cafe-details-contracts.spec.ts:62:5

# Error details

```
Error: locator.click: Error: strict mode violation: locator('[data-cafe-theme="zen"]') resolved to 2 elements:
    1) <section class="space" data-ready="true" data-theme="light" data-boot-stage="3" data-wallpaper="dawn" data-cafe-mode="cafe" data-cafe-theme="zen" data-cat-state="look" data-bear-workspace="" data-world-theme="zen" data-world-mode="roam" data-world-frames="76" data-world-draws="128" data-cat-loaded="true" data-world-ready="true" data-cat-active="false" data-world-objects="115" data-world-pbr-maps="21" data-product-panel="bear" data-world-travel="false" data-boot-state="complete" data-world-maple-trees="…>…</section> aka getByRole('region', { name: 'CUBXXW OS 个人工作区' })
    2) <button type="button" aria-pressed="true" data-cafe-theme="zen">…</button> aka getByRole('button', { name: '禅庭 雨后枫树，苔石与一池静水。' })

Call log:
  - waiting for locator('[data-cafe-theme="zen"]')

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=e2]:
    - generic [ref=e3]:
      - heading "空间 · CUBXXW OS" [level=1] [ref=e4]
      - paragraph [ref=e5]: CUBXXW OS 工作区
      - region "CUBXXW OS 个人工作区" [ref=e6]:
        - generic "三维咖啡馆。WASD 或方向键行走，拖动看四周。" [ref=e8]
        - generic:
          - generic:
            - link "返回博客" [ref=e9] [cursor=pointer]:
              - /url: /zh/
              - text: SPACE
              - generic [ref=e10]: CAFÉ
            - generic:
              - button "切换到英文" [ref=e11] [cursor=pointer]: EN
              - button "安静模式" [ref=e12] [cursor=pointer]
              - button "换个地方" [ref=e13] [cursor=pointer]
          - generic:
            - generic:
              - paragraph: A PLACE TO STAY A LITTLE
              - button "禅庭" [ref=e20] [cursor=pointer]:
                - generic [aria-hidden] [ref=e22]: ⌄
              - paragraph: 雨后枫树，苔石与一池静水。
            - paragraph: 不赶时间。坐一会儿。
        - navigation "咖啡馆导览":
          - generic:
            - button "看看咖啡" [ref=e23] [cursor=pointer]
            - button "逛逛书架" [ref=e24] [cursor=pointer]
            - button "看看小猫" [ref=e25] [cursor=pointer]
          - generic:
            - paragraph: 拖动看看四周，或用方向键散步。
            - button "坐下，读一篇" [ref=e26] [cursor=pointer]:
              - text: 坐下，读一篇
              - generic [aria-hidden] [ref=e27]: ↗
            - button "打开工作区" [ref=e28] [cursor=pointer]:
              - text: 打开工作区
              - generic [aria-hidden] [ref=e29]: ↗
        - dialog [ref=e30]:
          - generic [ref=e31]:
            - generic [ref=e32]:
              - paragraph [ref=e33]: SPACE / SOMEWHERE BEAUTIFUL
              - heading "今天，想坐在哪里？" [level=2] [ref=e34]
              - paragraph [ref=e35]: 换一处风景，桌上的事情还在。
            - button "关闭场景选择" [ref=e36] [cursor=pointer]: ×
          - generic [ref=e37]:
            - button "禅庭 雨后枫树，苔石与一池静水。" [active] [pressed] [ref=e38] [cursor=pointer]:
              - strong [ref=e40]: 禅庭
              - generic [ref=e41]: 雨后枫树，苔石与一池静水。
            - button "园林 借一窗竹影，留半日清闲。" [ref=e42] [cursor=pointer]:
              - strong [ref=e44]: 园林
              - generic [ref=e45]: 借一窗竹影，留半日清闲。
            - button "海岸 海风进来，思绪慢慢展开。" [ref=e46] [cursor=pointer]:
              - strong [ref=e48]: 海岸
              - generic [ref=e49]: 海风进来，思绪慢慢展开。
            - button "山居 云停在山腰，咖啡刚刚好。" [ref=e50] [cursor=pointer]:
              - strong [ref=e52]: 山居
              - generic [ref=e53]: 云停在山腰，咖啡刚刚好。
            - button "湖畔 在水面与远山之间坐一会儿。" [ref=e54] [cursor=pointer]:
              - strong [ref=e56]: 湖畔
              - generic [ref=e57]: 在水面与远山之间坐一会儿。
            - button "雨夜书屋 窗外下雨，窗内有书和暖光。" [ref=e58] [cursor=pointer]:
              - strong [ref=e60]: 雨夜书屋
              - generic [ref=e61]: 窗外下雨，窗内有书和暖光。
          - status [ref=e62]
          - generic [ref=e63]:
            - button "回到座位" [ref=e64] [cursor=pointer]
            - button "去露台看看 ↗" [ref=e65] [cursor=pointer]
            - button "重播入场" [ref=e66] [cursor=pointer]
          - generic [ref=e67]:
            - paragraph [ref=e68]: 这是我想象中的咖啡馆，也是一间未来想开的小店。
            - paragraph [ref=e69]:
              - text: Cat by
              - link "J-Toastie" [ref=e70] [cursor=pointer]:
                - /url: https://poly.pizza/m/DJ9rpAhrh3
              - text: ·
              - link "CC BY 3.0" [ref=e71] [cursor=pointer]:
                - /url: https://creativecommons.org/licenses/by/3.0/
              - text: · 新增步态与场景适配
```

# Test source

```ts
  1  | import {test,expect,type Page,type Locator} from '../helpers/frozen-site';
  2  | import {enterWorkspace,reserveWorldJourney} from '../helpers/space-entry';
  3  | import {readFileSync} from 'node:fs';
  4  | import {parse} from 'yaml';
  5  | 
  6  | test.use({channel:'chromium',reducedMotion:'reduce',launchOptions:{args:process.platform==='darwin'?['--enable-gpu','--use-angle=metal']:['--enable-unsafe-swiftshader']}});
  7  | const root=(page:Page)=>page.locator('[data-bear-workspace]');
  8  | const detail=(page:Page,kind:string)=>page.locator(`[data-cafe-inspect="${kind}"]`);
  9  | const exit=(page:Page)=>page.locator('[data-cafe-inspect-exit]');
  10 | const frames=(page:Page,count=2)=>page.evaluate(count=>new Promise<void>(done=>{const next=()=>--count?requestAnimationFrame(next):done();requestAnimationFrame(next);}),count);
  11 | async function settled(page:Page,mode:string){await expect(root(page)).toHaveAttribute('data-world-mode',mode);await expect(root(page)).toHaveAttribute('data-world-rendered-mode',mode);await expect(root(page)).toHaveAttribute('data-world-travel','false');}
  12 | async function ready(page:Page,lang='zh'){
  13 |   reserveWorldJourney(page);
  14 |   await page.goto(`${lang==='zh'?'/zh':''}/projects/`);await page.waitForFunction(()=>{const d=document.querySelector<HTMLElement>('[data-bear-workspace]')?.dataset;return d?.worldReady==='true'&&d.bootState==='complete'&&!d.worldLoading;},undefined,{timeout:30_000});await settled(page,'roam');
  15 | }
  16 | async function hit(button:Locator){
  17 |   await expect(button).toBeVisible();const b=(await button.boundingBox())!;expect(b.width).toBeGreaterThanOrEqual(44);expect(b.height).toBeGreaterThanOrEqual(44);expect(await button.evaluate(el=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2));})).toBe(true);
  18 | }
  19 | async function pose(page:Page){return JSON.parse((await root(page).getAttribute('data-world-pose'))!);}
  20 | async function inspect(page:Page,kind:string){await hit(detail(page,kind));await detail(page,kind).click();await settled(page,'inspect');await expect(root(page)).toHaveAttribute('data-world-inspect',kind);await hit(exit(page));}
  21 | async function samePose(page:Page,value:unknown){await settled(page,'roam');expect(await pose(page)).toEqual(value);await expect(root(page)).not.toHaveAttribute('data-world-inspect');}
  22 | async function point(page:Page,position:number[]){
  23 |   return page.evaluate(async position=>{
  24 |     const imports=JSON.parse(document.querySelector('script[type="importmap"]')!.textContent!).imports;
  25 |     const THREE=await import(imports.three),el=document.querySelector<HTMLElement>('[data-bear-workspace]')!,p=JSON.parse(el.dataset.worldPose!),r=el.getBoundingClientRect();
  26 |     const camera=new THREE.PerspectiveCamera(p.fov,r.width/r.height,.08,220);camera.position.set(p.x,p.y,p.z);camera.rotation.set(p.pitch,p.yaw,0,'YXZ');camera.updateMatrixWorld();const v=new THREE.Vector3(...position).project(camera);return {x:r.x+(v.x+1)*r.width/2,y:r.y+(1-v.y)*r.height/2};
  27 |   },position);
  28 | }
  29 | 
  30 | for(const view of [{width:1440,height:900,lang:'zh'},{width:390,height:844,lang:'en'},{width:320,height:740,lang:'zh'}])test.describe(`${view.width}px true café detail entry`,()=>{
  31 |   test.use({viewport:{width:view.width,height:view.height},isMobile:view.width<640,hasTouch:view.width<640});
  32 |   test('the ten real source books and coffee views have reachable exits and restore their exact roam pose and native trigger',async({page})=>{
  33 |     await ready(page,view.lang);
  34 |     const raster=await page.locator('.space-world__canvas').evaluate((canvas:HTMLCanvasElement)=>{
  35 |       // An initialized canvas returns its existing context; a different context
  36 |       // type returns null. Do not create a probe canvas or a second renderer.
  37 |       const gl=(canvas.getContext('webgl2')||canvas.getContext('webgl')) as WebGL2RenderingContext|WebGLRenderingContext|null;
  38 |       let renderer='';try{const debug=gl?.getExtension('WEBGL_debug_renderer_info');if(debug)renderer=String(gl!.getParameter(debug.UNMASKED_RENDERER_WEBGL)||'');}catch{}
  39 |       const root=canvas.closest<HTMLElement>('[data-bear-workspace]')!;
  40 |       return {renderer,software:/SwiftShader|llvmpipe|softpipe|swrast|software rasterizer/i.test(renderer),width:canvas.width,height:canvas.height,cssWidth:canvas.clientWidth,cssHeight:canvas.clientHeight,rootWidth:root.clientWidth,rootHeight:root.clientHeight,dpr:devicePixelRatio};
  41 |     });
  42 |     expect(raster.cssWidth).toBe(raster.rootWidth);expect(raster.cssHeight).toBe(raster.rootHeight);
  43 |     if(raster.software)expect(raster.width*raster.height,raster.renderer).toBeLessThanOrEqual(384000);
  44 |     else{expect(raster.width).toBe(Math.floor(raster.cssWidth*Math.min(raster.dpr,1.5)));expect(raster.height).toBe(Math.floor(raster.cssHeight*Math.min(raster.dpr,1.5)));}
  45 |     const source=parse(readFileSync('data/travel.yml','utf8')).books,books=await page.locator('[data-cafe-catalog]').evaluate(el=>JSON.parse(el.textContent!).books);
  46 |     expect(books).toEqual(source.map((b:any)=>({title:b[`title_${view.lang}`],author:b[`author_${view.lang}`],own:b.own===true,url:b.url||''})));expect(books).toHaveLength(10);
  47 |     const osBooks=await page.locator('[data-space-catalog]').evaluate(el=>JSON.parse(el.textContent!).books);expect(osBooks).toHaveLength(4);expect(osBooks.map((b:any)=>b.title)).toEqual(books.filter((b:any)=>b.own).map((b:any)=>b.title));
  48 |     await expect(root(page)).toHaveAttribute('data-world-reflection','room');const before=await pose(page);expect(before.y).toBe(1.52);expect(before.pitch).toBeGreaterThan(-.35);await inspect(page,'coffee');await expect(exit(page)).toBeFocused();await expect(page.locator('[data-cafe-inspect-coffee]')).toBeVisible();await page.keyboard.press('Escape');await samePose(page,before);await expect(detail(page,'coffee')).toBeFocused();
  49 |     await inspect(page,'books');const zoom=page.locator('[data-cafe-bookzoom]');await hit(zoom);await zoom.click();await settled(page,'inspect');await expect(root(page)).toHaveAttribute('data-world-inspect','spines');await expect(zoom).toBeFocused();await expect(zoom).toHaveAttribute('aria-pressed','true');await expect(detail(page,'books')).toHaveAttribute('aria-pressed','true');await page.keyboard.press('Escape');await samePose(page,before);await expect(detail(page,'books')).toBeFocused();await inspect(page,'books');await zoom.click();await settled(page,'inspect');await zoom.click();await settled(page,'inspect');await expect(root(page)).toHaveAttribute('data-world-inspect','books');await expect(zoom).toBeFocused();await expect(zoom).toHaveAttribute('aria-pressed','false');const list=page.locator('[data-cafe-inspect-books] ul'),toggle=page.locator('[data-cafe-booklist-toggle]');await expect(list).toBeHidden();await expect(toggle).toHaveAttribute('aria-expanded','false');await expect(toggle).toHaveAttribute('aria-controls','space-cafe-booklist');await hit(toggle);await toggle.click();await expect(toggle).toHaveAttribute('aria-expanded','true');await expect(list.locator('li strong')).toHaveText(books.map((b:any)=>b.title));await expect(list.locator('li span')).toHaveText(books.map((b:any)=>b.author));await expect(list.locator('a')).toHaveCount(0);
  50 |     for(const title of books.filter((b:any)=>b.own).map((b:any)=>b.title)){const label=list.locator('strong').filter({hasText:title}).first();await label.scrollIntoViewIfNeeded();await expect(label).toBeVisible();}
  51 |     await list.locator('li').last().scrollIntoViewIfNeeded();await expect(list.locator('li').last()).toBeVisible();await hit(exit(page));await exit(page).click();await samePose(page,before);await expect(detail(page,'books')).toBeFocused();await inspect(page,'books');await expect(list).toBeHidden();await expect(toggle).toHaveAttribute('aria-expanded','false');await exit(page).click();await samePose(page,before);expect(await root(page).evaluate(el=>el.scrollWidth<=el.clientWidth+1)).toBe(true);
  52 |   });
  53 | });
  54 | 
  55 | test('the actual cup and book raycasts enter the same detail views; a drag retains the computer hit instead of creating a click',async({page})=>{
  56 |   await page.setViewportSize({width:1440,height:900});await ready(page);const before=await pose(page),coffee=await point(page,[-.05,.865,1.3]);await page.mouse.click(coffee.x,coffee.y);await settled(page,'inspect');await expect(root(page)).toHaveAttribute('data-world-inspect','coffee');await page.keyboard.press('Escape');await samePose(page,before);await expect(page.locator('.space-world__canvas')).toBeFocused();
  57 |   const book=await point(page,[-.37,.809,1.5]);await page.mouse.click(book.x,book.y);await settled(page,'inspect');await expect(root(page)).toHaveAttribute('data-world-inspect','books');await exit(page).click();await samePose(page,before);
  58 |   const p=await pose(page),yaw=Math.atan2(-(3.65-p.x),-(-2.63-p.z)),pitch=Math.atan2(1.86-p.y,Math.hypot(3.65-p.x,-2.63-p.z)),b=(await root(page).boundingBox())!,x=b.x+b.width*.55,y=b.y+b.height*.55;
  59 |   await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x-(yaw-p.yaw)/.0035,y-(pitch-p.pitch)/.003,{steps:6});await page.mouse.up();await settled(page,'roam');const monitor=await point(page,[3.65,1.86,-2.63]);await page.mouse.click(monitor.x,monitor.y);await settled(page,'workspace');await expect(root(page)).toHaveAttribute('data-cafe-mode','desktop');
  60 | });
  61 | 
  62 | test('six scene changes and both detail views preserve the original Notes node, draft and selection through the live workspace',async({page})=>{
  63 |   reserveWorldJourney(page,120_000);
  64 |   await page.setViewportSize({width:1440,height:900});await ready(page);await enterWorkspace(page);await page.locator('[data-space-dock] [data-open="notes"]').click();const editor=page.locator('[data-note-editor]'),original=await editor.elementHandle(),draft='Coffee on the table.\nContinue this same notebook.';await editor.fill(draft);await editor.evaluate((el:HTMLTextAreaElement)=>el.setSelectionRange(3,18,'backward'));const selection=await editor.evaluate((el:HTMLTextAreaElement)=>[el.selectionStart,el.selectionEnd,el.selectionDirection]);
  65 |   await page.locator('.space-world-hud [data-cafe-visit]').click();await settled(page,'roam');const before=await pose(page);await inspect(page,'coffee');await exit(page).click();await samePose(page,before);await inspect(page,'books');await page.keyboard.press('Escape');await samePose(page,before);
> 66 |   for(const id of ['zen','garden','coast','mountain','lake','rain']){await page.locator('.space-cafe__utilities [data-cafe-picker]').click();await page.locator(`[data-cafe-theme="${id}"]`).click();await expect(root(page)).toHaveAttribute('data-world-theme',id);await expect(page.locator('[data-cafe-dialog]')).not.toHaveAttribute('open');}
     |                                                                                                                                                                                              ^ Error: locator.click: Error: strict mode violation: locator('[data-cafe-theme="zen"]') resolved to 2 elements:
  67 |   await page.locator('[data-cafe-enter]').click();await settled(page,'workspace');expect(await editor.evaluate((el,old)=>el===old,original)).toBe(true);await expect(editor).toHaveValue(draft);expect(await editor.evaluate((el:HTMLTextAreaElement)=>[el.selectionStart,el.selectionEnd,el.selectionDirection])).toEqual(selection);
  68 | });
  69 | 
  70 | test('runtime quiet/reduce and resize settle inspection without a late focus grab or an idle render loop',async({page})=>{
  71 |   await page.setViewportSize({width:1440,height:900});await page.emulateMedia({reducedMotion:'no-preference'});await ready(page,'en');const before=await pose(page);await detail(page,'coffee').click();await expect(exit(page)).toBeFocused();const quiet=page.locator('[data-cafe-quiet]');await quiet.click();await expect(quiet).toHaveAttribute('aria-pressed','true');await settled(page,'inspect');await expect(quiet).toBeFocused();await page.setViewportSize({width:390,height:844});await frames(page);await expect(root(page)).toHaveAttribute('data-world-inspect','coffee');await expect(quiet).toBeFocused();
  72 |   await expect.poll(async()=>{const value=await root(page).getAttribute('data-world-frames');await frames(page,6);return await root(page).getAttribute('data-world-frames')===value;}).toBe(true);await page.keyboard.press('Escape');await samePose(page,before);await expect(quiet).toBeFocused();
  73 |   await quiet.click();await detail(page,'books').click();await expect(exit(page)).toBeFocused();await page.keyboard.press('Tab');const zoom=page.locator('[data-cafe-bookzoom]');await expect(zoom).toBeFocused();await zoom.press('Enter');await expect(root(page)).toHaveAttribute('data-world-inspect','spines');await expect(zoom).toBeFocused();await zoom.press('Enter');await expect(root(page)).toHaveAttribute('data-world-inspect','books');await page.keyboard.press('Tab');const toggle=page.locator('[data-cafe-booklist-toggle]');await expect(toggle).toBeFocused();await toggle.press('Enter');await expect(toggle).toHaveAttribute('aria-expanded','true');await page.keyboard.press('Tab');const list=page.locator('[data-cafe-inspect-books] ul');await expect(list).toBeFocused();await page.emulateMedia({reducedMotion:'reduce'});await settled(page,'inspect');await expect(list).toBeFocused();await page.setViewportSize({width:320,height:740});await frames(page);await expect(list).toBeFocused();await page.keyboard.press('Escape');await samePose(page,before);await expect(detail(page,'books')).toBeFocused();
  74 | });
  75 | 
  76 | test('a held then failed latte image never blocks the first room; simulated context loss restores the same Notes document',async({page})=>{
  77 |   await page.setViewportSize({width:1440,height:900});let release=()=>{},requests=0;const gate=new Promise<void>(done=>{release=done;});await page.route('**/images/space/cafe/latte-rosetta-v1.jpg',async route=>{requests++;await gate;await route.abort('failed');});
  78 |   try{await ready(page);expect(requests).toBe(1);await inspect(page,'coffee');await expect(root(page)).not.toHaveAttribute('data-world-failed');expect(Number(await root(page).getAttribute('data-world-triangles'))).toBeGreaterThan(10000);release();await frames(page);await exit(page).click();await enterWorkspace(page);await page.locator('[data-space-dock] [data-open="notes"]').click();const editor=page.locator('[data-note-editor]'),old=await editor.elementHandle();await editor.fill('This document survives a renderer failure.');await page.locator('.space-world-hud [data-cafe-visit]').click();await settled(page,'roam');await inspect(page,'books');await page.locator('.space-world__canvas').evaluate(el=>el.dispatchEvent(new Event('webglcontextlost',{cancelable:true})));await expect(root(page)).toHaveAttribute('data-world-failed','true');await expect(root(page)).toHaveAttribute('data-cafe-mode','desktop');await expect(page.locator('[data-cafe-inspect-panel]')).toBeHidden();expect(await page.locator('[data-space-window="notes"]').evaluate(el=>el.contains(document.activeElement))).toBe(true);expect(await editor.evaluate((el,old)=>el===old,old)).toBe(true);await expect(editor).toHaveValue('This document survives a renderer failure.');}
  79 |   finally{release();await page.unrouteAll({behavior:'wait'});}
  80 | });
  81 | 
```