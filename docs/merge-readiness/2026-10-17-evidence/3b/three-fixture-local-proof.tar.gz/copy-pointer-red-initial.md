# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: control-contracts.spec.ts >> refused clipboard copy leaves code selected with a truthful recovery
- Location: tests/e2e/control-contracts.spec.ts:55:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.code-copy-status').first()
Expected substring: "代码已选中"
Received string:    "自动复制不可用。请长按代码，选择“复制”。"
Timeout: 5000ms

Call log:
  - Expect "toContainText" locator('.code-copy-status').first() with timeout 5000ms
  - waiting for locator('.code-copy-status').first()
    14 × locator resolved to <span role="status" id="code-copy-status-0" class="code-copy-status">自动复制不可用。请长按代码，选择“复制”。</span>
       - unexpected value "自动复制不可用。请长按代码，选择“复制”。"

```

```yaml
- status: 自动复制不可用。请长按代码，选择“复制”。
```

# Test source

```ts
  1  | import {test, expect} from '../helpers/frozen-site';
  2  | 
  3  | const article = '/zh/engineering/posts/use-go-tools-dlv/';
  4  | test.use({reducedMotion: 'reduce'});
  5  | 
  6  | test('article tabs expose one stop and support Arrow, Home and End', async ({page}) => {
  7  |   await page.setViewportSize({width: 1440, height: 900});
  8  |   await page.goto(article);
  9  |   const tabs = page.locator('.reading-companion [role="tab"]');
  10 |   await expect(tabs.first()).toHaveAttribute('tabindex', '0');
  11 |   await tabs.first().focus();
  12 |   await page.keyboard.press('End');
  13 |   await expect(tabs.last()).toBeFocused();
  14 |   await expect(tabs.last()).toHaveAttribute('aria-selected', 'true');
  15 |   await expect(page.locator('.reading-companion [role="tab"][tabindex="0"]')).toHaveCount(1);
  16 |   await page.keyboard.press('ArrowRight');
  17 |   await expect(tabs.first()).toBeFocused();
  18 |   await page.keyboard.press('End');
  19 |   await page.keyboard.press('Home');
  20 |   await expect(tabs.first()).toBeFocused();
  21 | });
  22 | 
  23 | test('compact tools retain focus around the selected tab and name each panel', async ({page}) => {
  24 |   await page.setViewportSize({width: 390, height: 844});
  25 |   await page.goto(article);
  26 |   await page.evaluate(() => window.scrollTo(0, 300));
  27 |   await page.locator('#article-fab').click();
  28 |   const sheet = page.locator('#article-bottom-sheet');
  29 |   const tabs = sheet.locator('[role="tab"]');
  30 |   await expect(tabs.first()).toBeFocused();
  31 |   await page.keyboard.press('End');
  32 |   await expect(tabs.last()).toBeFocused();
  33 |   const selectedID = await tabs.last().getAttribute('id');
  34 |   await expect(sheet.locator('[role="tabpanel"]:visible')).toHaveAttribute('aria-labelledby', selectedID!);
  35 |   await page.keyboard.press('Shift+Tab');
  36 |   await expect(sheet.locator(':focus')).toBeVisible();
  37 |   await page.keyboard.press('Escape');
  38 |   await expect(page.locator('#article-fab')).toBeFocused();
  39 | });
  40 | 
  41 | test('mobile navigation is a dismissible named disclosure', async ({page}) => {
  42 |   await page.setViewportSize({width: 390, height: 844});
  43 |   await page.goto('/zh/articles/');
  44 |   const trigger = page.locator('.hamburger-menu');
  45 |   await expect(trigger).toHaveAttribute('aria-controls', 'menu');
  46 |   await trigger.click();
  47 |   await expect(trigger).toHaveAttribute('aria-expanded', 'true');
  48 |   await expect(page.locator('#menu a').first()).toBeFocused();
  49 |   await page.keyboard.press('Escape');
  50 |   await expect(trigger).toBeFocused();
  51 |   await expect(trigger).toHaveAttribute('aria-expanded', 'false');
  52 |   await expect(page.locator('#menu')).toBeHidden();
  53 | });
  54 | 
  55 | test('refused clipboard copy leaves code selected with a truthful recovery', async ({page}) => {
  56 |   await page.addInitScript(() => {
  57 |     Object.defineProperty(navigator, 'clipboard', {value: {writeText: () => Promise.reject(new Error('denied'))}});
  58 |     document.execCommand = () => false;
  59 |   });
  60 |   await page.goto(article);
  61 |   const copy = page.locator('.post-content .copy-code').first();
  62 |   await copy.click();
  63 |   await expect(copy).not.toHaveClass(/is-copied/);
  64 |   await expect(copy).toBeEnabled();
> 65 |   await expect(page.locator('.code-copy-status').first()).toContainText('代码已选中');
     |                                                           ^ Error: expect(locator).toContainText(expected) failed
  66 |   expect(await page.evaluate(() => window.getSelection()?.toString().length || 0)).toBeGreaterThan(0);
  67 | });
  68 | 
  69 | test('closed compact tools cannot receive focus before opening or after dismissal',async({page})=>{
  70 |   await page.setViewportSize({width:390,height:844});await page.goto(article);
  71 |   const sheet=page.locator('#article-bottom-sheet'),tab=page.locator('#abs-tab-toc');
  72 |   await expect(sheet).toHaveAttribute('inert','');await expect(sheet).toHaveAttribute('aria-hidden','true');
  73 |   await tab.evaluate((node:HTMLElement)=>node.focus());await expect(tab).not.toBeFocused();
  74 |   await page.evaluate(()=>window.scrollTo(0,300));await page.locator('#article-fab').click();
  75 |   await expect(tab).toBeFocused();await expect(sheet).toHaveAttribute('aria-hidden','false');
  76 |   await page.keyboard.press('Escape');await expect(sheet).toHaveAttribute('inert','');
  77 |   await tab.evaluate((node:HTMLElement)=>node.focus());await expect(tab).not.toBeFocused();
  78 | });
  79 | 
  80 | test('fullscreen code uses a native modal and restores its expand trigger',async({page})=>{
  81 |   await page.setViewportSize({width:390,height:844});await page.goto(article);
  82 |   const trigger=page.locator('.code-tool-expand:visible').first();await trigger.click();
  83 |   const dialog=page.getByRole('dialog',{name:'全屏阅读'});await expect(dialog).toBeVisible();
  84 |   for(let i=0;i<6;i++){await page.keyboard.press('Tab');await expect(dialog.locator(':focus')).toBeVisible();}
  85 |   await page.keyboard.press('Escape');await expect(dialog).toBeHidden();await expect(trigger).toBeFocused();
  86 | });
  87 | 
  88 | test('book AI uses a native modal with keyboard containment and a 44px exit',async({page})=>{
  89 |   await page.setViewportSize({width:390,height:844});await page.goto('/zh/travel/');
  90 |   const trigger=page.locator('.tw-tome__ask').first();await trigger.click();
  91 |   const dialog=page.getByRole('dialog',{name:'问 AI 关于这本书'});await expect(dialog).toBeVisible();
  92 |   for(let i=0;i<8;i++){await page.keyboard.press('Tab');await expect(dialog.locator(':focus')).toBeVisible();}
  93 |   const close=dialog.locator('.tw-book-ai__x'),box=await close.boundingBox();
  94 |   expect(box!.width).toBeGreaterThanOrEqual(44);expect(box!.height).toBeGreaterThanOrEqual(44);
  95 |   await page.keyboard.press('Escape');await expect(dialog).toBeHidden();await expect(trigger).toBeFocused();
  96 | });
  97 | 
```