import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import vm from 'node:vm';
import test from 'node:test';
const wt=resolve(process.argv[2]);
const oldRetry=readFileSync(new URL('./retry-canonical-before.spec.ts',import.meta.url),'utf8'),newRetry=readFileSync(resolve(wt,'tests/e2e/article-selection.spec.ts'),'utf8');
const oldCopy=readFileSync(new URL('./copy-pointer-before.spec.ts',import.meta.url),'utf8'),newCopy=readFileSync(resolve(wt,'tests/e2e/control-contracts.spec.ts'),'utf8');
function retryBlock(source){const start=source.indexOf('test(\'failed AI retry avoids duplicate question and poisoned history\'');const at=source.indexOf('  const prefix =',start),end=source.indexOf('\n});',at);assert.ok(at>start&&end>at);return source.slice(at,end);}
function copyBlock(source,old){const at=source.indexOf(old?"  await expect(page.locator('.code-copy-status').first()).toContainText('代码已选中');":"  const coarse=await page.evaluate");const end=source.indexOf('  expect(await page.evaluate(() => window.getSelection()',at);assert.ok(at>=0&&end>at);return source.slice(at,end);}
const run=async(code,env)=>vm.runInNewContext('(async()=>{'+code+'})()',env);
function retryFixture(width){
 const calls=[],requests=[{question:'same',context:[]},{question:'same',context:[]}],panel={kind:'panel'},answer={kind:'answer'},user={kind:'user'};
 const retry={click:async()=>{calls.push('retry-click');}};
 panel.getByRole=(role,options)=>{assert.equal(role,'button');assert.deepEqual(JSON.parse(JSON.stringify(options)),{name:'重试',exact:true});return retry;};
 panel.locator=selector=>{calls.push(selector);if(selector==='.rc-ai-answer-body')return answer;if(selector==='.rc-ai-msg--user')return user;throw new Error('stale prefix: '+selector);};
 const page={evaluate:async fn=>fn(),locator:selector=>{calls.push(selector);if(selector==='[data-article-chat]'||selector==='.rc-ai-panel')return panel;return {getByRole:()=>({click:async()=>{throw new Error('No matching canonical chat: '+selector);}})};}};
 const expect=actual=>({toHaveCount:async n=>{assert.ok(actual===panel||actual===user);assert.equal(n,1);calls.push(actual.kind+'-count1');},toBeVisible:async()=>{assert.equal(actual,panel);calls.push('panel-visible');},toHaveText:async text=>{assert.equal(actual,answer);assert.equal(text,'回复完整。');calls.push('complete-answer');},toEqual:expected=>{assert.deepEqual(JSON.parse(JSON.stringify(actual)),JSON.parse(JSON.stringify(expected)));calls.push('empty-context');}});
 return {env:{page,expect,requests,innerWidth:width},calls};
}
function copyFixture(coarse){
 const touch='自动复制不可用。请长按代码，选择“复制”。',fine='自动复制不可用，代码已选中。请按 Ctrl / ⌘ + C 复制。',actual=coarse?touch:fine,calls=[];
 const page={evaluate:async fn=>fn(),locator:selector=>{assert.equal(selector,'.code-copy-status');return {first:()=>actual};}};
 const expect=value=>({toContainText:async expected=>assert.ok(value.includes(expected),'Old copy expectation misses truthful coarse recovery'),toHaveText:async expected=>{assert.equal(value,expected);calls.push(expected);}});
 return {env:{page,expect,matchMedia:query=>{assert.equal(query,'(pointer: coarse)');return {matches:coarse};}},calls,actual};
}
test('exact old retry block fails with the obsolete abs prefix on compact layout',async()=>{const f=retryFixture(390);await assert.rejects(run(retryBlock(oldRetry),f.env),/No matching canonical chat: .abs-ai-panel/);});
for(const width of [390,1280])test('actual canonical retry block uses unique visible root and rc selectors at '+width,async()=>{
 const f=retryFixture(width);await run(retryBlock(newRetry),f.env);
 assert.deepEqual(f.calls,['[data-article-chat]','panel-count1','panel-visible','retry-click','.rc-ai-answer-body','complete-answer','.rc-ai-msg--user','user-count1','empty-context']);
});
test('exact old copy assertion rejects the actual coarse recovery label',async()=>{const f=copyFixture(true);await assert.rejects(run(copyBlock(oldCopy,true),f.env),/Old copy expectation misses/);});
for(const coarse of [true,false])test('actual copy expectation selects exact '+(coarse?'coarse':'fine')+' Chinese recovery text',async()=>{const f=copyFixture(coarse);await run(copyBlock(newCopy,false),f.env);assert.deepEqual(f.calls,[f.actual]);});
