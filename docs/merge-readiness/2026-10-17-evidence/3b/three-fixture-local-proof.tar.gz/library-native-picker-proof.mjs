import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import test from 'node:test';
const wt=resolve(process.argv[2]),source=readFileSync(resolve(wt,'tests/e2e/control-recovery.spec.ts'),'utf8');
const before=readFileSync(new URL('./library-native-picker-before.spec.ts',import.meta.url),'utf8');
const start=source.indexOf("  const categoryPicker=reader.locator('[data-library-select]')"),end=source.indexOf("  await expect(reader.locator('.space-library-empty')).toContainText('还没有收藏文章');",start);
assert.ok(start>=0&&end>start);
const branch=source.slice(start,end),allValueLine="  if(nativePicker)await expect(categoryPicker).toHaveValue('all');";
assert.equal(source.split(allValueLine).length,2);
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const run=new AsyncFunction('reader','expect','recover',branch+'\nawait recover();\n'+allValueLine);
function fixture(mobile){
 const calls=[],state={value:'all'};
 const picker={isVisible:async()=>mobile,selectOption:async value=>{assert.equal(mobile,true);calls.push('native:'+value);state.value=value;}};
 const favorites={click:async()=>{if(mobile)throw new Error('element is not visible');calls.push('desktop:favorites');state.value='favorites';}};
 const reader={locator:selector=>{if(selector==='[data-library-select]')return picker;if(selector==='[data-library-filter="favorites"]')return favorites;throw new Error('Unexpected locator: '+selector);}};
 const expect=control=>({toBeVisible:async()=>{assert.equal(control,picker);assert.equal(mobile,true);calls.push('visible');},toHaveValue:async value=>{assert.equal(control,picker);assert.equal(state.value,value);calls.push('value:'+value);}});
 const recover=async()=>{assert.equal(state.value,'favorites');calls.push('recover:all');state.value='all';};
 return {reader,expect,recover,calls,state};
}
test('old exact desktop-button action reproduces hidden-control failure in the mobile mock',async()=>{
 const old=before.match(/^  await reader\.locator\('\[data-library-filter="favorites"\]'\)\.click\(\);$/m)?.[0];assert.ok(old);
 const f=fixture(true);await assert.rejects(new AsyncFunction('reader',old)(f.reader),/element is not visible/);assert.equal(f.state.value,'all');
});
test('actual visible-native branch selects favorites and verifies recovery to all',async()=>{
 const f=fixture(true);await run(f.reader,f.expect,f.recover);
 assert.deepEqual(f.calls,['visible','native:favorites','value:favorites','recover:all','value:all']);assert.equal(f.state.value,'all');
});
test('actual desktop branch retains the original favorites button click',async()=>{
 const f=fixture(false);await run(f.reader,f.expect,f.recover);
 assert.deepEqual(f.calls,['desktop:favorites','recover:all']);assert.equal(f.state.value,'all');
});
