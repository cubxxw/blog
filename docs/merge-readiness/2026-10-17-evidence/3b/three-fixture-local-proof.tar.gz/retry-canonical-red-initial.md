# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: article-selection.spec.ts >> failed AI retry avoids duplicate question and poisoned history
- Location: tests/e2e/article-selection.spec.ts:197:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('.abs-ai-panel').getByRole('button', { name: '重试', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - banner [ref=e3]:
    - navigation [ref=e4]:
      - link "cubxxw" [ref=e6] [cursor=pointer]:
        - /url: https://cubxxw.com/zh/
      - generic [ref=e7]:
        - button "搜索 (Cmd/Ctrl + K)" [ref=e8] [cursor=pointer]
        - button "Toggle theme" [ref=e13] [cursor=pointer]
        - list "Language" [ref=e14]:
          - listitem [ref=e15]:
            - link "English" [ref=e16] [cursor=pointer]:
              - /url: /growth/posts/2026-07-14-what-remains-when-taken-apart/
              - text: EN
          - listitem [ref=e17]:
            - text: /
            - generic "简体中文" [ref=e18]: 中
      - button "打开导航菜单" [ref=e19] [cursor=pointer]
  - main [ref=e21]:
    - article [ref=e23]:
      - generic [ref=e24]:
        - generic [ref=e25]:
          - generic [ref=e26]: Xinwei Xiong
          - generic [ref=e27]: ·
          - generic [ref=e28]: 2026 年 7 月 14 日
        - generic [ref=e29]:
          - generic [ref=e30]: 13 分钟 · 6313 字
          - generic [ref=e31]: ·
          - generic [ref=e32]:
            - text: 中 |
            - link "EN" [ref=e33] [cursor=pointer]:
              - /url: https://cubxxw.com/growth/posts/2026-07-14-what-remains-when-taken-apart/
      - generic [ref=e34]:
        - generic [ref=e35]:
          - link "主页" [ref=e36] [cursor=pointer]:
            - /url: https://cubxxw.com/zh/
          - text: »
          - link "Growth & Life" [ref=e37] [cursor=pointer]:
            - /url: https://cubxxw.com/zh/growth/
        - heading "拆到最后，剩下的才是你：一场关于无我、痛苦与\"怎么说都可以\"的追问" [level=1] [ref=e38]
        - paragraph [ref=e39]: 从一束阳光穿过白内障眼球的意象出发，一路拆解自我——无我、五蕴、缘起，直到概念的相对性让人眩晕："怎么说都可以，那还追求什么？"这篇文章不给现成答案，只主张一点：相对性是站在生命外面看的性质，不是走在路上的性质。拆到最后，那个你怎么用"空""无常""执著"都消解不掉、依然压手的残余，才是你的地面。痛，正是它压手的证据。
      - complementary "核心要点" [ref=e41]:
        - heading "提要" [level=2] [ref=e42]
        - list [ref=e44]:
          - listitem [ref=e45]: 一只看不清的眼睛，抹掉了光和影的分界——分界从来不在世界里，是眼睛（和心）加上去的。
          - listitem [ref=e46]: 拆自我像拆马车：轮子不是车，车轴不是车，全拆开摆一地，“我”无处藏身。这是无我，不是“我不存在”。
          - listitem [ref=e47]: “怎么说都可以”的眩晕，是站在地图前太久的错觉。地图上每条路都能随便标注，可你一旦走进去，脚下只有一条。
          - listitem [ref=e48]: 拆到最后，有些东西你怎么用“空”“无常”去消解它，它还是压手——那个残余就是你的地面，而且它对你是唯一的。
          - listitem [ref=e49]: 成长不是找到一个不再痛的答案，是学会站在“拆”与“认”之间：有些东西拆不掉，也不该拆，痛是它压手的证据。
      - figure [ref=e50]:
        - generic [ref=e51]:
          - img "拆到最后，剩下的才是你：一场关于无我、痛苦与\"怎么说都可以\"的追问"
      - generic [ref=e52]:
        - blockquote [ref=e53]:
          - paragraph [ref=e54]: 这篇文章的种子，是一场持续了几轮的对话——从"广东热不热"的闲聊，一路滑进"生命是由什么构成的"。 它不打算给你一个答案，因为真正值钱的东西，恰恰在没有答案的地方长出来。
        - paragraph [ref=e55]:
          - button "一束光穿过浑浊的晶体，光与影的分界在散射中软化、消融 — open full size" [ref=e56]
        - separator [ref=e57]
        - heading "引：一个看起来很温柔、其实很危险的问题" [level=2] [ref=e58]:
          - text: 引：一个看起来很温柔、其实很危险的问题
          - link [aria-hidden] [ref=e59] [cursor=pointer]:
            - /url: "#引一个看起来很温柔其实很危险的问题"
            - text: "#"
        - paragraph [ref=e60]: 先讲一个朋友抛出的问题。
        - paragraph [ref=e61]: 她说，她一直在想：从身上拿掉多少东西，她就不再是她自己了？
        - paragraph [ref=e62]: 这个问句听起来很温柔，像在数一个人身上的行李。但你只要认真往下走两步，就会发现它有牙。因为它逼你一样一样地拿：拿掉工作，你还是你吗？还是。拿掉记忆呢？拿掉身体呢？拿掉那些让你之所以是你的经历、口音、爱过的人？一直拿下去，到某个地方，“你"会不会突然就不在了？如果会，那个临界点在哪？如果不会——那"你"到底是被哪一样东西撑着的？
        - paragraph [ref=e63]:
          - text: 我们那场对话的真正源头，其实是
          - strong [ref=e64]: 痛苦
          - text: 。是"人为什么会痛苦"这个更古老的问题。顺着它往回追，会追到一个几乎所有传统都指向的嫌疑犯：
          - strong [ref=e65]: 自我
          - text: 。痛苦源于"我执”，源于有一个"我"在那里，怕失去、求不得、放不下。于是问题就翻转成了：这个"我"，到底是什么做的？它经得起拆吗？
        - paragraph [ref=e66]: 这篇文章，就是沿着"拆"这条路一直走到底，看看走到尽头，手里还剩下什么。
        - paragraph [ref=e67]: 我想提前说清楚：这不是一篇让你"看开"的文章。恰恰相反，它想在你以为已经看开了的地方，再往回拉你一把。
        - separator [ref=e68]
        - heading "第一层：一束光，和一只看不清的眼睛" [level=2] [ref=e69]:
          - text: 第一层：一束光，和一只看不清的眼睛
          - link [aria-hidden] [ref=e70] [cursor=pointer]:
            - /url: "#第一层一束光和一只看不清的眼睛"
            - text: "#"
        - paragraph [ref=e71]: 先从一个意象讲起，它是这场讨论里最美的一块。
        - paragraph [ref=e72]:
          - strong [ref=e73]: 一束阳光，加上一个白内障患者的眼球，能看到穿过窗户的阴影。
        - paragraph [ref=e74]: 如果只从光学上看，这句话是成立的，而且动人。白内障让晶状体变浑浊，光穿过时不再干净地折射，转而被散射开。所以对这样一只眼睛来说，一束阳光不会是锐利的光柱——它会晕开、发白、带着光晕，边缘化成雾。而窗棂投下的阴影，本该是清晰的几何线条，在散射之下会变软、发灰、互相渗透。
        - paragraph [ref=e75]: 这里有个东西值得停下来看。
        - paragraph [ref=e76]:
          - text: 一只
          - strong [ref=e77]: 清晰
          - text: 的眼睛，看到的是"光和影的分界"——仿佛"光"是一个东西，“影"是另一个东西，中间有一条真实的、客观的界线。而那只
          - strong [ref=e78]: 浑浊
          - text: 的眼睛，把这条线抹掉了。它看到的几乎是"光和影的和解”：界限消失了，一切浸在同一层柔光里。
        - paragraph [ref=e79]:
          - text: 我们太容易觉得那只看不清的眼睛是"有缺陷的"。但换个角度：那条被抹掉的分界线，本来就不在世界里。世界里只有连续变化的光强，从最亮到最暗是一条平滑的斜坡。是
          - strong [ref=e80]: 清晰的眼睛
          - text: （和它背后的大脑）在那条斜坡上，硬切了一刀，说"这边是光、那边是影"。分界不是世界给的，是
          - strong [ref=e81]: 看的人加上去的
          - text: 。
        - paragraph [ref=e82]:
          - text: 那只浑浊的眼睛，某种意义上，反而看到了更接近实相的东西——
          - strong [ref=e83]: 分别消融的地方
          - text: 。
        - paragraph [ref=e84]:
          - text: 记住这个动作：
          - strong [ref=e85]: 我们习惯把自己切出来的线，当成世界本来就有的线。
          - text: 接下来拆"自我"，用的是同一把刀，只不过这次，切的是我们自己。
        - separator [ref=e86]
        - heading "第二层：开始拆——一辆马车，和一个找不到的\"我\"" [level=2] [ref=e87]:
          - text: 第二层：开始拆——一辆马车，和一个找不到的"我"
          - link [aria-hidden] [ref=e88] [cursor=pointer]:
            - /url: "#第二层开始拆一辆马车和一个找不到的我"
            - text: "#"
        - paragraph [ref=e89]: 现在把这把刀转向"我"。
        - paragraph [ref=e90]: 有一部很老的佛经叫《弥兰陀王问经》，里面记了一场对话。一位僧人那先，问国王弥兰陀：你是坐马车来的，那我问你，什么是"马车"？
        - paragraph [ref=e91]: 车轮是马车吗？不是，车轮只是车轮。 车轴是马车吗？不是。 车厢、辕木、缰绳，是马车吗？都不是。 那把它们全拆开，一件一件摆在地上——“马车"在哪里？
        - paragraph [ref=e92]: 找不到。地上只有一堆零件。可是你又不能说马车不存在——你分明是坐着它来的。
        - paragraph [ref=e93]:
          - text: 结论是：
          - strong [ref=e94]: “马车"不是任何一个零件，也不是零件的简单堆叠；它是这些零件按某种关系装配起来、正在运作时，我们给这个整体起的一个名字。
          - text: 抽掉关系，只剩零件；抽掉零件，关系也无处附着。马车是"缘起"的——依条件而暂时成立，不是本来就搁在那里的现成物。
        - paragraph [ref=e95]: “我"也一样。
        - paragraph [ref=e96]: 顺着这条路拆下去：没有了元素、器官，就没有肉体上的我；没有了经历、意识、思考，就没有灵魂上的我。两边都拆完，中间那个"我”，没有一个单独的藏身之处。
        - paragraph [ref=e97]:
          - text: 佛学把这套拆法系统化成了
          - strong [ref=e98]: 五蕴
          - text: ——色、受、想、行、识。色是物质与身体；受是感受（苦、乐、不苦不乐）；想是辨认与概念化；行是意志、习性、造作的冲动；识是了别、觉知。所谓"我”，就是这五股不断流动的过程暂时聚在一起，被我们命名为一个人。你在每一蕴里翻找，都找不到一个叫"我"的核心。这就是
          - strong [ref=e99]: 无我
          - text: 。
        - paragraph [ref=e100]: 这里有一个极其容易滑过去、但千万不能滑过去的地方：
        - paragraph [ref=e101]:
          - strong [ref=e102]: 无我，不是"我不存在”。
        - paragraph [ref=e103]:
          - text: 说"什么都不存在"，佛学有个专门的词骂它，叫"断灭见"，是明确反对的。窗上那道阴影确实"在"——你看得见它、它随太阳移动——但你找不到一个叫"阴影"的实体。它只是"光被遮挡"这个条件关系的显现。“我"也是。我不是不存在，我是
          - strong [ref=e104]: 以一种和直觉不同的方式存在
          - text: ：不是一个东西，是一个正在发生的过程。
        - paragraph [ref=e105]:
          - text: 一个更好的比方是
          - strong [ref=e106]: 烛火
          - text: 。火焰一直在那儿，你叫得出它的名字，它会照亮、会灼手。但组成火焰的气体分子，每一刻都是新的、烧完就走的。你找不到火焰的"本体”，你只找到一场持续进行的燃烧。生命更像
          - strong [ref=e107]: 一条河，而不是河里的水
          - text: ——它从来不是"由零件组成的一个东西"。
        - paragraph [ref=e108]:
          - text: 有意思的是，科学拆到最后，给的是同一个答案。构成你的原子，和构成一块石头、一口空气的原子，是同一批；而且它们还在不断流进流出——你今天身上的大部分原子，几年前不在你身上，几年后也会离开。从物质上看，你也只是一种
          - strong [ref=e109]: 维持了一段时间的模式
          - text: ，而非"一堆特殊材料"。
        - paragraph [ref=e110]: 无论从哪条路进去——佛学的五蕴，还是科学的原子——拆到最后，都没有拆出一个叫"我本身"或"生命本身"的东西。
        - paragraph [ref=e111]: 到这一步，很多人会觉得通透、轻盈，甚至有点欣快。“原来我是假的”，“原来一切都是缘起”，“原来没什么好抓的”。
        - paragraph [ref=e112]: 请先别急着轻盈。因为紧接着，是这场追问里最危险的一个悬崖。
        - separator [ref=e113]
        - heading "第三层：拆穿了概念，然后眩晕了" [level=2] [ref=e114]:
          - text: 第三层：拆穿了概念，然后眩晕了
          - link [aria-hidden] [ref=e115] [cursor=pointer]:
            - /url: "#第三层拆穿了概念然后眩晕了"
            - text: "#"
        - paragraph [ref=e116]:
          - text: 当你把"我"拆成缘起、拆成五蕴、拆成一场燃烧之后，会发生一件事：
          - strong [ref=e117]: 词，开始失灵。
        - paragraph [ref=e118]: 你会发现，同一件事，怎么说都可以。
        - paragraph [ref=e119]: 一个母亲为孩子揪心——你可以叫它"执著"，也可以叫它"爱"。 一个人为所爱之人的离去哀恸——你可以叫它"我执带来的苦"，也可以叫它"一个生命对另一个生命的分量"。 失去——你可以叫它"无常的正常运作"，也可以叫它"伤害"。
        - paragraph [ref=e120]: 每一个词，都能两头说。褒可以翻成贬，深情可以翻成愚痴，坚持可以翻成放不下。而且你找不到一个客观的裁判，来判定哪种说法"对"。
        - paragraph [ref=e121]: 于是就有了那句真正的痛点：
        - blockquote [ref=e122]:
          - paragraph [ref=e123]: “怎么说好像都可以。这样真的好吗？很多名词可以有意义也可以没意义。不知道要追求什么了。”
        - paragraph [ref=e124]: 这是一种非常具体的眩晕。它不是抽象的哲学难题，它会让人在半夜里真的空掉——如果正确和错误只是相对于某个情况才出现的词，如果万事万物本就没有对错之分，那我到底还要奔向什么？我凭什么早起、凭什么努力、凭什么为任何一件事心疼？既然都可以，那就都不必。
        - paragraph [ref=e125]: 这个悬崖是真的。很多聪明人拆自我拆到这里，就掉下去了——他们没有变得自由，反倒变得虚无。看穿了一切之后，什么都托不住他们了。
        - paragraph [ref=e126]: 如果这篇文章到这里就结束，那它是有害的。所以真正的重点，从下一段开始。
        - separator [ref=e127]
        - heading "转折：那个\"怎么说都可以\"，是地图上的性质，不是路上的性质" [level=2] [ref=e128]:
          - text: 转折：那个"怎么说都可以"，是地图上的性质，不是路上的性质
          - link [aria-hidden] [ref=e129] [cursor=pointer]:
            - /url: "#转折那个怎么说都可以是地图上的性质不是路上的性质"
            - text: "#"
        - paragraph [ref=e130]:
          - text: 我想跟你顶一句：
          - strong [ref=e131]: “怎么说都可以”，可能不是世界的性质，只是站在世界外面看时，才会有的性质。
        - paragraph [ref=e132]: 分清两个位置。
        - paragraph [ref=e133]:
          - text: 当你在讨论里、在聊天框里、在脑子里反复掂量的时候，你是
          - strong [ref=e134]: 站在生命外面
          - text: ，指着它。从那个位置看，一切都可翻转：揪心可以叫执著也可以叫爱，失去可以叫无常也可以叫伤害。词在这里是工具，不是镜子——它们天生就能两头说。这不是缺陷，这就是词的用法本身。语言是一张
          - strong [ref=e135]: 地图
          - text: ，而地图上的每一条路，你都可以随便标注、随便重命名。
        - paragraph [ref=e136]: 但请注意那位母亲。
        - paragraph [ref=e137]:
          - text: 在她揪心的
          - strong [ref=e138]: 当下
          - text: ，她并不觉得"怎么说都行"。她没有在心里权衡"这或许是执著、或许是爱，两种读法都成立"。她就是疼。哀恸的人也一样——他不是在几个解释之间挑选，他是被按在那里，动弹不得。
        - paragraph [ref=e139]:
          - strong [ref=e140]: “都可以"是地图上的性质，不是走在路上的性质。
        - paragraph [ref=e141]: 你半夜里那种眩晕，是因为你在地图前站得太久了，久到忘记：地图上每条路都能随便标注，可你一旦真的走进去，脚下就只有一条。你没法同时既向左又向右。你没法一边真的爱一个人、一边同时"也可以不爱”。到了真实的一步里，那些在纸面上并列的可能性，会坍缩成唯一的一个当下。
        - paragraph [ref=e142]: 相对性是真的——但它只在你抽身出来、把生命摊在纸上看的时候才成立。你没法一直站在纸前面。你终究要走回路里。而路里没有"怎么说都可以"，路里只有你正在走的这一步。
        - separator [ref=e143]
        - heading "第四层：拆到最后，什么东西还压手" [level=2] [ref=e144]:
          - text: 第四层：拆到最后，什么东西还压手
          - link [aria-hidden] [ref=e145] [cursor=pointer]:
            - /url: "#第四层拆到最后什么东西还压手"
            - text: "#"
        - paragraph [ref=e146]: 那么，方向从哪里来？
        - paragraph [ref=e147]:
          - text: 我的答案是：
          - strong [ref=e148]: 不从"把概念想通"里来。
          - text: 概念永远想不通，它天生就滑，你再想十年，它还是两头都能说。你没法靠把词想清楚来获得方向，因为词本身就是设计来两头说的。
        - paragraph [ref=e149]: 方向从另一个地方来。
        - paragraph [ref=e150]:
          - text: 把能拆的都拆掉、能翻转的都翻转完之后——
          - strong [ref=e151]: 看还剩下什么，没有变轻。
        - paragraph [ref=e152]:
          - text: 你和你的朋友已经拆了很多：拆掉了器官的我、意识的我，一路拆到无我，拆到缘起，拆到"怎么说都可以"。那就接着往下问一句：拆到这一步，
          - strong [ref=e153]: 有没有哪样东西，你怎么用"无常"“空"“执著"去消解它，它还是压手？
        - paragraph [ref=e154]: 如果有——那个东西，就是你的地面。
        - paragraph [ref=e155]:
          - text: 它不是被论证出来的，它是
          - strong [ref=e156]: 拆剩下的
          - text: 。所有能被"其实这也是缘起"“其实这也是空"轻飘飘化解掉的东西，都被这套拆法筛掉了、变轻了、飘走了。唯独有些东西，你明明已经承认它无自性、承认它是耦合、承认它终将消散，可它
          - strong [ref=e157]: 依然压手
          - text: ——你一想到失去它就疼，这个疼不因为你"想通了"而减一分。
        - paragraph [ref=e158]:
          - text: 那个筛不掉的残余，就是你真正在乎的东西。而且——这一点很重要——
          - strong [ref=e159]: 它对你是唯一的
          - text: 。别人拆剩下的，未必和你一样。这不是一条能被普遍推导出来的真理，这是
          - strong [ref=e160]: 你的
          - text: 地面。它拆不掉，不是因为你还不够聪明、拆得还不够彻底，是因为它本来就不属于"可拆解"的那一类。
        - paragraph [ref=e161]: 这就是为什么，我不同意把所有痛苦都归给"我执”。
        - paragraph [ref=e162]: “痛苦源于ego"是一种讲法，很有力，但不是唯一的真相。有些痛苦确实来自我执——求不得、怕失去、放不下一个注定要移动的影子。这类苦，看破它是缘起，确实能松手。
        - paragraph [ref=e163]:
          - text: 但也有一些痛苦，恰恰是因为
          - strong [ref=e164]: 有我、有爱、有牵挂
          - text: 才成立的。一个母亲为孩子揪心，一个人为所爱之人的离去哀恸——你当然可以说这是执著，然后着手把它拆掉。但你也可以说：
          - strong [ref=e165]: 这正是"这一个生命"之所以是它自己的东西。
          - text: 把所有痛苦都当成要被消解的错觉，可能会不小心，把生命里最重的那部分，也一起拆掉。
        - paragraph [ref=e166]:
          - text: 回到最开头那个温柔又危险的问题：
          - strong [ref=e167]: 拿掉多少东西，她还是她？
        - paragraph [ref=e168]:
          - text: 也许答案不在"拿到无我为止”。也许答案是：
          - strong [ref=e169]: 有些东西，一拿掉，那个"她"就不在了。
          - text: 而"会牵挂、会痛的能力”，很可能正是那种拿不掉的东西。痛，不是需要被清除的故障。在这里，
          - strong [ref=e170]: 痛是它压手的证据
          - text: ——是那样东西还在、还重、还属于你的证据。
        - separator [ref=e171]
        - heading "第五层：关于\"想要一个答案\"这件事" [level=2] [ref=e172]:
          - text: 第五层：关于"想要一个答案"这件事
          - link [aria-hidden] [ref=e173] [cursor=pointer]:
            - /url: "#第五层关于想要一个答案这件事"
            - text: "#"
        - paragraph [ref=e174]: 还有最后一块，得诚实地处理。
        - paragraph [ref=e175]: 你渴望一个明确的答案。人本来就渴望。面对"怎么说都可以"的空，人会本能地想要一个地方站稳，想要有谁——宇宙、佛经、一个更聪明的人、或者一个AI——递给你一句"就是这样”，然后你照着做。
        - paragraph [ref=e176]: 我不想像某些讲法那样，反手告诉你"这渴望也是执著，放下吧"。这渴望很正当，它是人在深渊边上想找根绳子，没什么可羞愧的。
        - paragraph [ref=e177]: 但有件事值得提醒你，而且它可能是这整篇文章里，最反直觉的一句：
        - paragraph [ref=e178]:
          - strong [ref=e179]: 假如真有一个明确答案，由宇宙或佛经或谁递到你手里，那你接下来，就只是在执行一份说明书。
        - paragraph [ref=e180]:
          - text: 一个被给定的、明确的、放之四海皆准的答案，会取消掉一件事：你自己。因为凡是能被别人替你想清楚、替你说满的东西，长出来的都不是"你的"。
          - strong [ref=e181]: 那个没有答案的空，恰恰是"你的东西"唯一能生长的地方。
        - paragraph [ref=e182]: 你怕的那个"不知道要追求什么"的空白，和你要的那个"自由"，是同一个东西。自由从来不是"有人告诉我该往哪走"，自由是"没人告诉我，而我仍然得走"。它当然不舒服。空白总是不舒服的。但你没法既要"完全的自由"，又要"有人替我把方向定死"——这两个是同一枚硬币的两面，你不能只留正面。
        - paragraph [ref=e183]: 所以，那个空白不是要被填上的坑，是要被认领的地。
        - separator [ref=e184]
        - heading "收束：站在\"拆\"与\"认\"之间" [level=2] [ref=e185]:
          - text: 收束：站在"拆"与"认"之间
          - link [aria-hidden] [ref=e186] [cursor=pointer]:
            - /url: "#收束站在拆与认之间"
            - text: "#"
        - paragraph [ref=e187]:
          - text: 这场追问的源头是痛苦。走到这里，我想说的是：
          - strong [ref=e188]: 转折不在"找到答案就不痛了"。
        - paragraph [ref=e189]: 真正的转折，是学会同时握住两只手。
        - paragraph [ref=e190]:
          - text: 一只手是
          - strong [ref=e191]: 拆
          - text: ：拆到无我，拆到缘起，拆到松手离苦。这一手让你不被那些本可以放下的东西，绑在原地反复受苦——不为一个注定要移动的影子，在它移动时痛不欲生。这是佛学给的，是真东西。
        - paragraph [ref=e192]:
          - text: 另一只手是
          - strong [ref=e193]: 认
          - text: ：承认有些耦合一旦成形，就成了不可还原的"这一个"。承认有些东西拆不掉，也不该拆。承认痛，是它压手的证据，而不是需要被修好的故障。这一手让你不至于在拆穿一切之后，掉进那个"怎么说都可以、所以什么都不必"的虚无里。
        - paragraph [ref=e194]: 绝大多数人只学会一只手。要么一路拆到虚无，聪明而空洞，什么都托不住；要么死死攥住，一样都不敢放，被自己在乎的东西反复碾过。
        - paragraph [ref=e195]:
          - text: 而成长——真正"幅度非常高"的那种成长——大概就发生在你学会
          - strong [ref=e196]: 让两只手同时张开又同时用力
          - text: 的那一刻：清醒地知道一切都是缘起、都会流散、都可以两头说；同时又清醒地认领那几样拆不掉的、只属于你的、会让你疼的东西，并且
          - strong [ref=e197]: 不因为它们"经不起哲学推敲"就把它们扔掉
          - text: 。
        - paragraph [ref=e198]: 看破，是为了不再无谓地受苦。 认领，是为了还配得上去爱。
        - paragraph [ref=e199]:
          - text: 一只看不清的眼睛，抹掉了光和影那条本不存在的分界，让人看见它们本是一体。而一颗成熟的心，做的是相反又相通的事：它看穿了所有分界都是自己划的，却依然选择，在那片连续的柔光里，为某几样东西，重新划下一道
          - strong [ref=e200]: 它明知是自己划的、却甘愿为之负责
          - text: 的线。
        - paragraph [ref=e201]: 那道线，就是你。
        - blockquote [ref=e202]:
          - paragraph [ref=e203]: 拆到最后，剩下的不是一个答案。 剩下的是一小片，你怎么拆都拆不掉、也不愿拆掉的东西。 那不是你的局限，那是你的地面。
      - generic [ref=e204]:
        - list [ref=e205]:
          - listitem [ref=e206]:
            - link "Philosophy" [ref=e207] [cursor=pointer]:
              - /url: https://cubxxw.com/zh/tags/philosophy/
          - listitem [ref=e208]:
            - link "Buddhism" [ref=e209] [cursor=pointer]:
              - /url: https://cubxxw.com/zh/tags/buddhism/
          - listitem [ref=e210]:
            - link "Self-Discovery" [ref=e211] [cursor=pointer]:
              - /url: https://cubxxw.com/zh/tags/self-discovery/
          - listitem [ref=e212]:
            - link "Inner Work" [ref=e213] [cursor=pointer]:
              - /url: https://cubxxw.com/zh/tags/inner-work/
          - listitem [ref=e214]:
            - link "Personal Growth" [ref=e215] [cursor=pointer]:
              - /url: https://cubxxw.com/zh/tags/personal-growth/
        - navigation "文章导航" [ref=e216]:
          - link "上一篇 你以为你是玩家，可「玩家」也是一个角色：重读游戏三昧" [ref=e217] [cursor=pointer]:
            - /url: https://cubxxw.com/zh/growth/posts/2026-07-20-the-player-is-also-a-role/
            - generic [ref=e218]: 上一篇
            - generic [ref=e221]: 你以为你是玩家，可「玩家」也是一个角色：重读游戏三昧
          - link "下一篇 摩擦即成长：当 AI 替你消除一切阻力，请主动留下一些" [ref=e222] [cursor=pointer]:
            - /url: https://cubxxw.com/zh/growth/posts/friction-is-growth/
            - generic [ref=e223]: 下一篇
            - generic [ref=e226]: 摩擦即成长：当 AI 替你消除一切阻力，请主动留下一些
        - generic [ref=e227]:
          - generic [ref=e228]: 分享这篇文章
          - generic [ref=e230]:
            - button "生成文章分享卡" [ref=e231] [cursor=pointer]:
              - generic [ref=e232]: 分享卡片
            - button "复制链接" [ref=e233] [cursor=pointer]
            - button "分享到微信" [ref=e237] [cursor=pointer]
            - link "分享到 X / Twitter" [ref=e240] [cursor=pointer]:
              - /url: https://x.com/intent/tweet/?text=%E6%8B%86%E5%88%B0%E6%9C%80%E5%90%8E%EF%BC%8C%E5%89%A9%E4%B8%8B%E7%9A%84%E6%89%8D%E6%98%AF%E4%BD%A0%EF%BC%9A%E4%B8%80%E5%9C%BA%E5%85%B3%E4%BA%8E%E6%97%A0%E6%88%91%E3%80%81%E7%97%9B%E8%8B%A6%E4%B8%8E%22%E6%80%8E%E4%B9%88%E8%AF%B4%E9%83%BD%E5%8F%AF%E4%BB%A5%22%E7%9A%84%E8%BF%BD%E9%97%AE+%E2%80%94+%E4%BB%8E%E4%B8%80%E6%9D%9F%E9%98%B3%E5%85%89%E7%A9%BF%E8%BF%87%E7%99%BD%E5%86%85%E9%9A%9C%E7%9C%BC%E7%90%83%E7%9A%84%E6%84%8F%E8%B1%A1%E5%87%BA%E5%8F%91%EF%BC%8C%E4%B8%80%E8%B7%AF%E6%8B%86%E8%A7%A3%E8%87%AA%E6%88%91%E2%80%94%E2%80%94%E6%97%A0%E6%88%91%E3%80%81%E4%BA%94%E8%95%B4%E3%80%81%E7%BC%98%E8%B5%B7%EF%BC%8C%E7%9B%B4%E5%88%B0%E6%A6%82%E5%BF%B5%E7%9A%84%E7%9B%B8%E5%AF%B9%E6%80%A7%E8%AE%A9%E4%BA%BA%E7%9C%A9%E6%99%95%EF%BC%9A%26%2334%3B%E6%80%8E%E4%B9%88%E8%AF%B4%E9%83%BD%E5%8F%AF%E4%BB%A5%EF%BC%8C%E9%82%A3%E8%BF%98%E8%BF%BD%E6%B1%82%E4%BB%80%E4%B9%88%EF%BC%9F%26%2334%3B%E8%BF%99%E7%AF%87%E6%96%87%E7%AB%A0%E4%B8%8D%E7%BB%99%E7%8E%B0%E6%88%90%E7%AD%94%E6%A1%88%EF%BC%8C%E5%8F%AA%E4%B8%BB%E5%BC%A0%E4%B8%80%E7%82%B9%EF%BC%9A%E7%9B%B8%E5%AF%B9%E6%80%A7%E6%98%AF%E7%AB%99%E5%9C%A8%E7%94%9F%E5%91%BD%E5%A4%96%E9%9D%A2%E7%9C%8B%E7%9A%84%E6%80%A7%E8%B4%A8%EF%BC%8C%E4%B8%8D%E6%98%AF%E8%B5%B0%E5%9C%A8%E8%B7%AF%E4%B8%8A%E7%9A%84%E6%80%A7%E8%B4%A8%E3%80%82%E6%8B%86%E5%88%B0%E6%9C%80%E5%90%8E%EF%BC%8C%E9%82%A3%E4%B8%AA%E4%BD%A0%E6%80%8E%E4%B9%88%E7%94%A8%26%2334%3B%E2%80%A6&url=https%3a%2f%2fcubxxw.com%2fzh%2fgrowth%2fposts%2f2026-07-14-what-remains-when-taken-apart%2f&hashtags=Philosophy%2cBuddhism%2cSelf-Discovery%2cInnerWork%2cPersonalGrowth
            - link "通过邮件分享" [ref=e243] [cursor=pointer]:
              - /url: mailto:?subject=%E6%8B%86%E5%88%B0%E6%9C%80%E5%90%8E%EF%BC%8C%E5%89%A9%E4%B8%8B%E7%9A%84%E6%89%8D%E6%98%AF%E4%BD%A0%EF%BC%9A%E4%B8%80%E5%9C%BA%E5%85%B3%E4%BA%8E%E6%97%A0%E6%88%91%E3%80%81%E7%97%9B%E8%8B%A6%E4%B8%8E%22%E6%80%8E%E4%B9%88%E8%AF%B4%E9%83%BD%E5%8F%AF%E4%BB%A5%22%E7%9A%84%E8%BF%BD%E9%97%AE&body=%E6%8B%86%E5%88%B0%E6%9C%80%E5%90%8E%EF%BC%8C%E5%89%A9%E4%B8%8B%E7%9A%84%E6%89%8D%E6%98%AF%E4%BD%A0%EF%BC%9A%E4%B8%80%E5%9C%BA%E5%85%B3%E4%BA%8E%E6%97%A0%E6%88%91%E3%80%81%E7%97%9B%E8%8B%A6%E4%B8%8E%22%E6%80%8E%E4%B9%88%E8%AF%B4%E9%83%BD%E5%8F%AF%E4%BB%A5%22%E7%9A%84%E8%BF%BD%E9%97%AE%0A%0A%E4%BB%8E%E4%B8%80%E6%9D%9F%E9%98%B3%E5%85%89%E7%A9%BF%E8%BF%87%E7%99%BD%E5%86%85%E9%9A%9C%E7%9C%BC%E7%90%83%E7%9A%84%E6%84%8F%E8%B1%A1%E5%87%BA%E5%8F%91%EF%BC%8C%E4%B8%80%E8%B7%AF%E6%8B%86%E8%A7%A3%E8%87%AA%E6%88%91%E2%80%94%E2%80%94%E6%97%A0%E6%88%91%E3%80%81%E4%BA%94%E8%95%B4%E3%80%81%E7%BC%98%E8%B5%B7%EF%BC%8C%E7%9B%B4%E5%88%B0%E6%A6%82%E5%BF%B5%E7%9A%84%E7%9B%B8%E5%AF%B9%E6%80%A7%E8%AE%A9%E4%BA%BA%E7%9C%A9%E6%99%95%EF%BC%9A%26%2334%3B%E6%80%8E%E4%B9%88%E8%AF%B4%E9%83%BD%E5%8F%AF%E4%BB%A5%EF%BC%8C%E9%82%A3%E8%BF%98%E8%BF%BD%E6%B1%82%E4%BB%80%E4%B9%88%EF%BC%9F%26%2334%3B%E8%BF%99%E7%AF%87%E6%96%87%E7%AB%A0%E4%B8%8D%E7%BB%99%E7%8E%B0%E6%88%90%E7%AD%94%E6%A1%88%EF%BC%8C%E5%8F%AA%E4%B8%BB%E5%BC%A0%E4%B8%80%E7%82%B9%EF%BC%9A%E7%9B%B8%E5%AF%B9%E6%80%A7%E6%98%AF%E7%AB%99%E5%9C%A8%E7%94%9F%E5%91%BD%E5%A4%96%E9%9D%A2%E7%9C%8B%E7%9A%84%E6%80%A7%E8%B4%A8%EF%BC%8C%E4%B8%8D%E6%98%AF%E8%B5%B0%E5%9C%A8%E8%B7%AF%E4%B8%8A%E7%9A%84%E6%80%A7%E8%B4%A8%E3%80%82%E6%8B%86%E5%88%B0%E6%9C%80%E5%90%8E%EF%BC%8C%E9%82%A3%E4%B8%AA%E4%BD%A0%E6%80%8E%E4%B9%88%E7%94%A8%26%2334%3B%E2%80%A6%0A%0Ahttps%3A%2F%2Fcubxxw.com%2Fzh%2Fgrowth%2Fposts%2F2026-07-14-what-remains-when-taken-apart%2F%0A%0ATopics%3A+Growth+%26+Life%0ATags%3A+Philosophy%2C+Buddhism%2C+Self-Discovery%2C+Inner+Work%2C+Personal+Growth
            - link "分享到 LinkedIn" [ref=e247] [cursor=pointer]:
              - /url: https://www.linkedin.com/shareArticle?mini=true&url=https%3a%2f%2fcubxxw.com%2fzh%2fgrowth%2fposts%2f2026-07-14-what-remains-when-taken-apart%2f&title=%E6%8B%86%E5%88%B0%E6%9C%80%E5%90%8E%EF%BC%8C%E5%89%A9%E4%B8%8B%E7%9A%84%E6%89%8D%E6%98%AF%E4%BD%A0%EF%BC%9A%E4%B8%80%E5%9C%BA%E5%85%B3%E4%BA%8E%E6%97%A0%E6%88%91%E3%80%81%E7%97%9B%E8%8B%A6%E4%B8%8E%22%E6%80%8E%E4%B9%88%E8%AF%B4%E9%83%BD%E5%8F%AF%E4%BB%A5%22%E7%9A%84%E8%BF%BD%E9%97%AE&summary=%E4%BB%8E%E4%B8%80%E6%9D%9F%E9%98%B3%E5%85%89%E7%A9%BF%E8%BF%87%E7%99%BD%E5%86%85%E9%9A%9C%E7%9C%BC%E7%90%83%E7%9A%84%E6%84%8F%E8%B1%A1%E5%87%BA%E5%8F%91%EF%BC%8C%E4%B8%80%E8%B7%AF%E6%8B%86%E8%A7%A3%E8%87%AA%E6%88%91%E2%80%94%E2%80%94%E6%97%A0%E6%88%91%E3%80%81%E4%BA%94%E8%95%B4%E3%80%81%E7%BC%98%E8%B5%B7%EF%BC%8C%E7%9B%B4%E5%88%B0%E6%A6%82%E5%BF%B5%E7%9A%84%E7%9B%B8%E5%AF%B9%E6%80%A7%E8%AE%A9%E4%BA%BA%E7%9C%A9%E6%99%95%EF%BC%9A%26%2334%3B%E6%80%8E%E4%B9%88%E8%AF%B4%E9%83%BD%E5%8F%AF%E4%BB%A5%EF%BC%8C%E9%82%A3%E8%BF%98%E8%BF%BD%E6%B1%82%E4%BB%80%E4%B9%88%EF%BC%9F%26%2334%3B%E8%BF%99%E7%AF%87%E6%96%87%E7%AB%A0%E4%B8%8D%E7%BB%99%E7%8E%B0%E6%88%90%E7%AD%94%E6%A1%88%EF%BC%8C%E5%8F%AA%E4%B8%BB%E5%BC%A0%E4%B8%80%E7%82%B9%EF%BC%9A%E7%9B%B8%E5%AF%B9%E6%80%A7%E6%98%AF%E7%AB%99%E5%9C%A8%E7%94%9F%E5%91%BD%E5%A4%96%E9%9D%A2%E7%9C%8B%E7%9A%84%E6%80%A7%E8%B4%A8%EF%BC%8C%E4%B8%8D%E6%98%AF%E8%B5%B0%E5%9C%A8%E8%B7%AF%E4%B8%8A%E7%9A%84%E6%80%A7%E8%B4%A8%E3%80%82%E6%8B%86%E5%88%B0%E6%9C%80%E5%90%8E%EF%BC%8C%E9%82%A3%E4%B8%AA%E4%BD%A0%E6%80%8E%E4%B9%88%E7%94%A8%26%2334%3B%E2%80%A6&source=https%3a%2f%2fcubxxw.com%2fzh%2fgrowth%2fposts%2f2026-07-14-what-remains-when-taken-apart%2f
            - button "更多" [ref=e252] [cursor=pointer]
        - dialog [aria-hidden] [ref=e257]:
          - generic [ref=e259]: 分享到
      - region "读者回响" [ref=e260]:
        - generic [ref=e261]:
          - heading "读者回响" [level=3] [ref=e262]
          - generic [ref=e263]:
            - generic [ref=e264]: —
            - generic [ref=e265]: 加入讨论
    - button "目录" [expanded]
    - dialog "目录" [ref=e268]:
      - tablist [ref=e270]:
        - tab "目录" [ref=e271] [cursor=pointer]
        - tab "AI" [selected] [ref=e274] [cursor=pointer]
        - tab "分享" [ref=e280] [cursor=pointer]
      - tabpanel "AI" [ref=e289]:
        - generic [ref=e290]:
          - generic "文章解读" [ref=e291]:
            - generic [ref=e292]:
              - text: 关于这段文字
              - blockquote [ref=e293]: 先从一个意象讲起，它是这场讨论里最美的一块。
              - paragraph [ref=e294]: 结合这篇文章，帮我理解这段话。
            - generic [ref=e295]:
              - generic [ref=e296]:
                - generic [ref=e297]: AI
                - generic [ref=e298]: 一起读懂
              - paragraph [ref=e300]: 暂时没有得到回复，请再试一次。
              - button "重试" [ref=e301] [cursor=pointer]
          - generic [ref=e302]:
            - generic [ref=e303]:
              - generic [ref=e304]: 关于这段文字
              - paragraph [ref=e305]: 先从一个意象讲起，它是这场讨论里最美的一块。
              - button "结束这段解读" [ref=e306] [cursor=pointer]: ×
            - textbox "AI" [active] [ref=e307]:
              - /placeholder: 继续追问这篇文章…
            - button "发送" [ref=e308]
    - generic [ref=e312]:
      - generic [ref=e313]:
        - generic [ref=e314]: 继续阅读
        - heading "相关文章 / Related Posts" [level=3] [ref=e315]
      - generic [ref=e316]:
        - link "Philosophy Buddhism 你以为你是玩家，可「玩家」也是一个角色：重读游戏三昧 2026-07-20 20 min" [ref=e317] [cursor=pointer]:
          - /url: /zh/growth/posts/2026-07-20-the-player-is-also-a-role/
          - generic [ref=e319]:
            - generic [ref=e320]:
              - generic [ref=e321]: Philosophy
              - generic [ref=e322]: Buddhism
            - paragraph [ref=e323]: 你以为你是玩家，可「玩家」也是一个角色：重读游戏三昧
            - generic [ref=e324]:
              - generic [ref=e325]: 2026-07-20
              - generic [aria-hidden] [ref=e326]: ·
              - generic [ref=e327]: 20 min
          - generic [aria-hidden] [ref=e328]: →
        - link "Philosophy Psychology 历史不能只活在一个尺度里：与 Archer 的一场夜谈 2026-08-06 5 min" [ref=e329] [cursor=pointer]:
          - /url: /zh/growth/posts/history-needs-more-than-one-scale/
          - generic [ref=e331]:
            - generic [ref=e332]:
              - generic [ref=e333]: Philosophy
              - generic [ref=e334]: Psychology
            - paragraph [ref=e335]: 历史不能只活在一个尺度里：与 Archer 的一场夜谈
            - generic [ref=e336]:
              - generic [ref=e337]: 2026-08-06
              - generic [aria-hidden] [ref=e338]: ·
              - generic [ref=e339]: 5 min
          - generic [aria-hidden] [ref=e340]: →
        - link "Personal Growth Self-Discovery 在泉州读弘一：看破之后，继续把人生当真 2026-08-03 7 min" [ref=e341] [cursor=pointer]:
          - /url: /zh/growth/posts/2026-08-03-hongyi-quanzhou-game-of-life/
          - generic [ref=e343]:
            - generic [ref=e344]:
              - generic [ref=e345]: Personal Growth
              - generic [ref=e346]: Self-Discovery
            - paragraph [ref=e347]: 在泉州读弘一：看破之后，继续把人生当真
            - generic [ref=e348]:
              - generic [ref=e349]: 2026-08-03
              - generic [aria-hidden] [ref=e350]: ·
              - generic [ref=e351]: 7 min
          - generic [aria-hidden] [ref=e352]: →
  - region "邮件订阅" [ref=e353]:
    - generic [ref=e356]:
      - generic [ref=e357]:
        - heading "新文章写好，先寄给你" [level=2] [ref=e358]
        - paragraph [ref=e359]: 每有新文章，寄一封信到你的邮箱。双重确认，随时退订。
      - generic [ref=e360]:
        - generic [ref=e361]:
          - generic [ref=e362]: 邮箱地址
          - textbox "邮箱地址" [ref=e363]:
            - /placeholder: you@example.com
        - button "订阅" [ref=e364] [cursor=pointer]
        - textbox [aria-hidden] [ref=e367]
      - paragraph [ref=e368]
      - generic [ref=e369]:
        - generic [ref=e370]: 更喜欢 RSS？
        - link "全部 · RSS" [ref=e371] [cursor=pointer]:
          - /url: /zh/index.xml
        - link "JSON" [ref=e372] [cursor=pointer]:
          - /url: /zh/feed.json
        - link "OPML" [ref=e373] [cursor=pointer]:
          - /url: /zh/subscriptions.opml
        - link "Growth & Life" [ref=e375] [cursor=pointer]:
          - /url: /zh/growth/index.xml
        - link "AI Agent" [ref=e376] [cursor=pointer]:
          - /url: /zh/ai-agent/index.xml
        - link "Engineering" [ref=e377] [cursor=pointer]:
          - /url: /zh/engineering/index.xml
        - link "空间 · CUBXXW OS" [ref=e378] [cursor=pointer]:
          - /url: /zh/projects/index.xml
        - link "所有文章" [ref=e379] [cursor=pointer]:
          - /url: /zh/articles/index.xml
  - contentinfo "站点导航" [ref=e380]:
    - generic [ref=e381]:
      - generic [ref=e382]:
        - paragraph [ref=e383]: 继续读
        - list [ref=e384]:
          - listitem [ref=e385]:
            - link "专栏" [ref=e386] [cursor=pointer]:
              - /url: /zh/columns/
          - listitem [ref=e387]:
            - link "AI Agent" [ref=e388] [cursor=pointer]:
              - /url: /zh/ai-agent/
          - listitem [ref=e389]:
            - link "工程" [ref=e390] [cursor=pointer]:
              - /url: /zh/engineering/
          - listitem [ref=e391]:
            - link "成长" [ref=e392] [cursor=pointer]:
              - /url: /zh/growth/
          - listitem [ref=e393]:
            - link "全部文章" [ref=e394] [cursor=pointer]:
              - /url: /zh/articles/
          - listitem [ref=e395]:
            - link "归档" [ref=e396] [cursor=pointer]:
              - /url: /zh/archives/
          - listitem [ref=e397]:
            - link "旅行" [ref=e398] [cursor=pointer]:
              - /url: /zh/travel/
      - generic [ref=e399]:
        - paragraph [ref=e400]: 产品
        - list [ref=e401]:
          - listitem [ref=e402]:
            - link "Talent Signal" [ref=e403] [cursor=pointer]:
              - /url: /zh/projects/#talent-signal
          - listitem [ref=e404]:
            - link "Leafhour" [ref=e405] [cursor=pointer]:
              - /url: /zh/projects/#leafhour
          - listitem [ref=e406]:
            - link "IMStage" [ref=e407] [cursor=pointer]:
              - /url: /zh/projects/#imstage
          - listitem [ref=e408]:
            - link "Solo Compass" [ref=e409] [cursor=pointer]:
              - /url: /zh/projects/#solo-compass
          - listitem [ref=e410]:
            - link "DayPage" [ref=e411] [cursor=pointer]:
              - /url: /zh/projects/#daypage
          - listitem [ref=e412]:
            - link "Telepace" [ref=e413] [cursor=pointer]:
              - /url: /zh/projects/#telepace
          - listitem [ref=e414]:
            - link "Apply Agent" [ref=e415] [cursor=pointer]:
              - /url: /zh/projects/#apply-agent
          - listitem [ref=e416]:
            - link "Agent Diff Guard" [ref=e417] [cursor=pointer]:
              - /url: /zh/projects/#agent-diff-guard
          - listitem [ref=e418]:
            - link "全部产品 →" [ref=e419] [cursor=pointer]:
              - /url: /zh/projects/#studio-products
      - generic [ref=e420]:
        - paragraph [ref=e421]: 订阅与联系
        - list [ref=e422]:
          - listitem [ref=e423]:
            - link "关于 · 阅读地图" [ref=e424] [cursor=pointer]:
              - /url: /zh/about/
          - listitem [ref=e425]:
            - link "RSS" [ref=e426] [cursor=pointer]:
              - /url: /zh/index.xml
          - listitem [ref=e427]:
            - link "JSON Feed" [ref=e428] [cursor=pointer]:
              - /url: /zh/feed.json
          - listitem [ref=e429]:
            - link "GitHub" [ref=e430] [cursor=pointer]:
              - /url: https://github.com/cubxxw
          - listitem [ref=e431]:
            - link "邮件" [ref=e432] [cursor=pointer]:
              - /url: mailto:3293172751nss@gmail.com
  - contentinfo [ref=e433]:
    - generic [ref=e434]:
      - text: © 2026
      - link "熊鑫伟（cubxxw）· 公开的实践与思想档案" [ref=e435] [cursor=pointer]:
        - /url: https://cubxxw.com/zh/
  - progressbar "Reading progress" [ref=e436]
  - status
  - status
```

# Test source

```ts
  106 |     (window as any).ShareConversation.showExcerpt('下一段原文。', { lang: 'zh', title: '测试', url: 'https://cubxxw.com/zh/growth/posts/test/' });
  107 |   });
  108 |   dialog = page.locator('#conv-share-modal [role="dialog"]');
  109 |   await expect(page.locator('#conv-share-modal')).toHaveCount(1);
  110 |   await dialog.locator('#csb-copy-text').click(); await expect(dialog.locator('#csp-manual textarea')).toHaveValue(/下一段原文/);
  111 |   await expect(dialog.locator('#csb-save-img')).toBeEnabled();
  112 | });
  113 | test('font preparation keeps focus inside share editor', async ({ page }) => {
  114 |   await page.goto(article); await select(page);
  115 |   await page.evaluate(() => {
  116 |     const load = document.fonts.load.bind(document.fonts);
  117 |     document.fonts.load = async (...args) => { await new Promise(r => setTimeout(r, 250)); return load(...args); };
  118 |   });
  119 |   await page.getByRole('toolbar').getByRole('button', { name: '分享', exact: true }).click();
  120 |   await expect(page.locator('.conv-share-close')).toBeFocused(); await expect(page.locator('#csb-save-img')).toBeEnabled();
  121 | });
  122 | test('over-limit excerpt has no canvas and retains full copy', async ({ page }) => {
  123 |   await page.goto(article); await select(page); await share(page);
  124 |   await page.evaluate(() => (window as any).ShareConversation.showExcerpt('长'.repeat(2401), { lang: 'zh', title: '长引用' }));
  125 |   const dialog = page.locator('#conv-share-modal [role="dialog"]');
  126 |   await expect(dialog.locator('#csp-limit')).toBeVisible(); await expect(dialog.locator('canvas')).toHaveCount(0);
  127 |   await expect(dialog.locator('#csb-save-img')).toBeDisabled(); await expect(dialog.locator('#csb-copy-text')).toBeEnabled();
  128 | });
  129 | test('comments preserve reading position, refresh failed copy and respect topmost share', async ({ page }) => {
  130 |   await page.addInitScript(() => Object.defineProperty(navigator, 'clipboard', { value: { writeText: () => Promise.reject(new Error('refused')) } }));
  131 |   await page.goto(article); await select(page); const y = await page.evaluate(() => scrollY);
  132 |   await page.getByRole('toolbar').getByRole('button', { name: '评论', exact: true }).click();
  133 |   const drawer = page.locator('.asel-comments'); await expect(drawer).toBeVisible();
  134 |   expect(await page.evaluate(() => scrollY)).toBe(y);
  135 |   await drawer.getByRole('button', { name: '复制引用', exact: true }).click();
  136 |   await expect(drawer.locator('.asel-comments-manual')).toHaveValue(new RegExp(passage));
  137 |   await drawer.getByRole('button', { name: '继续阅读', exact: true }).click(); expect(await page.evaluate(() => scrollY)).toBe(y);
  138 |   await select(page, page.locator('.post-content p').filter({ hasText: '这篇文章的种子' }));
  139 |   await page.getByRole('toolbar').getByRole('button', { name: '评论', exact: true }).click();
  140 |   await expect(drawer.locator('.asel-comments-manual')).toHaveCount(0);
  141 |   await expect(drawer.locator('blockquote')).toContainText('这篇文章的种子');
  142 |   await page.evaluate(() => (window as any).loadShareScripts(() => (window as any).ShareConversation.showExcerpt('当前分享。', { lang: 'zh' })));
  143 |   await expect(page.locator('#conv-share-modal')).toBeVisible(); await page.keyboard.press('Escape');
  144 |   await expect(page.locator('#conv-share-modal')).not.toBeVisible(); await expect(drawer).toBeVisible();
  145 |   if (process.env.SELECTION_EVIDENCE) await page.screenshot({ path: join(process.env.SELECTION_EVIDENCE, 'comments-desktop.png') });
  146 | });
  147 | test('drag uses actual range and Escape preserves native text', async ({ page }) => {
  148 |   await page.goto(article); await select(page);
  149 |   await page.locator('.post-content p').filter({ hasText: passage }).evaluate(el => {
  150 |     const r = document.createRange(); r.setStart(el.firstChild!, 4); r.setEnd(el.firstChild!, 12);
  151 |     getSelection()!.removeAllRanges(); getSelection()!.addRange(r);
  152 |   });
  153 |   const selected = await page.evaluate(() => ({ text: getSelection()!.toString(), rect: getSelection()!.getRangeAt(0).getBoundingClientRect().toJSON() }));
  154 |   const touch = await page.evaluate(() => matchMedia('(hover: none)').matches);
  155 |   if (touch) {
  156 |     await expect.poll(async () => (await page.getByRole('toolbar').boundingBox())!.y - selected.rect.bottom).toBeGreaterThanOrEqual(55);
  157 |   } else {
  158 |     await expect.poll(async () => { const r = (await page.getByRole('toolbar').boundingBox())!; return Math.abs(r.y + r.height + 10 - selected.rect.top); }).toBeLessThan(2);
  159 |   }
  160 |   await page.keyboard.press('Escape'); await expect(page.getByRole('toolbar')).not.toBeVisible();
  161 |   expect(await page.evaluate(() => getSelection()!.toString())).toBe(passage.slice(4, 12));
  162 | });
  163 | test('dark share matches article surface', async ({ page }) => {
  164 |   await page.addInitScript(() => localStorage.setItem('pref-theme', 'dark'));
  165 |   await page.goto(article); await select(page); const dialog = await share(page);
  166 |   expect(await dialog.evaluate(el => getComputedStyle(el).backgroundColor)).not.toBe('rgb(255, 255, 255)');
  167 |   expect(await page.locator('body').evaluate(el => el.classList.contains('dark'))).toBe(true);
  168 |   if (process.env.SELECTION_EVIDENCE) await page.screenshot({ path: join(process.env.SELECTION_EVIDENCE, 'share-dark.png') });
  169 | });
  170 | test('footer card uses same local editor and Escape closes cleanly', async ({ page }) => {
  171 |   await page.goto(article); await page.getByRole('button', { name: '生成文章分享卡', exact: true }).click();
  172 |   const dialog = page.locator('#conv-share-modal [role="dialog"]');
  173 |   await expect(dialog).toBeVisible(); await expect(dialog.locator('#csb-save-img')).toBeEnabled();
  174 |   await expect(dialog.locator('#conv-share-heading')).toHaveText('分享这篇文章');
  175 |   await page.keyboard.press('Escape'); await expect(dialog).not.toBeVisible();
  176 | });
  177 | test.describe('native touch selection', () => {
  178 |   test.use({ hasTouch: true, isMobile: true, viewport: { width: 390, height: 844 } });
  179 |   test('toolbar clears system menu zone and compact comments fit', async ({ page }) => {
  180 |     await page.goto(article); await select(page);
  181 |     const r = await page.evaluate(() => getSelection()!.getRangeAt(0).getBoundingClientRect().toJSON());
  182 |     expect((await page.getByRole('toolbar').boundingBox())!.y).toBeGreaterThanOrEqual(r.bottom + 55);
  183 |     await page.getByRole('toolbar').getByRole('button', { name: '评论', exact: true }).click();
  184 |     const drawer = page.locator('.asel-comments'); await expect(drawer).toHaveAttribute('aria-modal', 'true');
  185 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  186 |     await drawer.getByRole('button', { name: '继续阅读', exact: true }).click(); await expect(drawer).not.toBeVisible();
  187 |   });
  188 | });
  189 | test('unsupported selection is rejected and English controls are localized', async ({ page }) => {
  190 |   await page.goto(article); await select(page);
  191 |   await page.locator('.post-title').evaluate(el => { const r = document.createRange(); r.selectNodeContents(el); getSelection()!.removeAllRanges(); getSelection()!.addRange(r); });
  192 |   await expect(page.getByRole('toolbar')).not.toBeVisible();
  193 |   await page.goto('/growth/posts/2026-07-14-what-remains-when-taken-apart/');
  194 |   await select(page, page.locator('.post-content p').filter({ hasText: 'Start with an image — the most beautiful thing' }));
  195 |   for (const name of ['Share', 'AI analysis', 'Comment', 'More']) await expect(page.getByRole('toolbar').getByRole('button', { name, exact: true })).toBeVisible();
  196 | });
  197 | test('failed AI retry avoids duplicate question and poisoned history', async ({ page }) => {
  198 |   const requests: any[] = [];
  199 |   await page.route('**/.netlify/functions/article-ai', async route => {
  200 |     requests.push(route.request().postDataJSON());
  201 |     await route.fulfill(requests.length === 1 ? { status: 503, body: '{}' } : { contentType: 'text/event-stream', body: 'data: {"delta":"回复完整。"}\r\n\r\ndata: [DONE]\r\n\r\n' });
  202 |   });
  203 |   await page.goto(article); await select(page);
  204 |   await page.getByRole('toolbar').getByRole('button', { name: 'AI 分析', exact: true }).click();
  205 |   const prefix = await page.evaluate(() => innerWidth < 1200 ? 'abs' : 'rc');
> 206 |   const panel = page.locator('.' + prefix + '-ai-panel'); await panel.getByRole('button', { name: '重试', exact: true }).click();
      |                                                                                                                        ^ Error: locator.click: Test timeout of 30000ms exceeded.
  207 |   await expect(panel.locator('.' + prefix + '-ai-answer-body')).toHaveText('回复完整。'); await expect(panel.locator('.' + prefix + '-ai-msg--user')).toHaveCount(1);
  208 |   expect(requests[1].context).toEqual([]);
  209 | });
  210 | 
  211 | test('a brief curve connects the passage to desktop chat and then clears', async ({ page }) => {
  212 |   await page.setViewportSize({ width: 1280, height: 800 });
  213 |   await page.emulateMedia({ reducedMotion: 'no-preference' });
  214 |   await page.route('**/.netlify/functions/article-ai', async route => {
  215 |     await route.fulfill({ contentType: 'application/json', body: JSON.stringify({ answer: '这段解释进入右侧聊天。' }) });
  216 |   });
  217 |   await page.goto(article); await select(page);
  218 |   await page.getByRole('toolbar').getByRole('button', { name: 'AI 分析', exact: true }).click();
  219 |   await expect(page.locator('.article-selection-guide path')).toBeAttached();
  220 |   await expect(page.locator('#rc-tab-ai')).toHaveAttribute('aria-selected', 'true');
  221 |   if (process.env.SELECTION_EVIDENCE) await page.screenshot({ path: join(process.env.SELECTION_EVIDENCE, 'ai-curve.png') });
  222 |   await expect(page.locator('.article-selection-guide')).toHaveCount(0);
  223 | });
  224 | test('a late clipboard rejection cannot restore an old comment quote', async ({ page }) => {
  225 |   await page.addInitScript(() => Object.defineProperty(navigator, 'clipboard', { value: {
  226 |     writeText: () => new Promise((_, reject) => { (window as any).rejectOldQuote = reject; }),
  227 |   } }));
  228 |   await page.goto(article); await select(page);
  229 |   await page.getByRole('toolbar').getByRole('button', { name: '评论', exact: true }).click();
  230 |   const drawer = page.locator('.asel-comments');
  231 |   await drawer.getByRole('button', { name: '复制引用', exact: true }).click();
  232 |   await drawer.getByRole('button', { name: '继续阅读', exact: true }).click();
  233 |   await select(page, page.locator('.post-content p').filter({ hasText: '这篇文章的种子' }));
  234 |   await page.getByRole('toolbar').getByRole('button', { name: '评论', exact: true }).click();
  235 |   await page.evaluate(() => (window as any).rejectOldQuote(new Error('delayed refusal')));
  236 |   await expect(drawer.locator('.asel-comments-manual')).toHaveCount(0);
  237 |   await expect(drawer.locator('blockquote')).toContainText('这篇文章的种子');
  238 | });
  239 | test('compact share tray has a local article-card entry and retains its open state', async ({ page }) => {
  240 |   await page.setViewportSize({ width: 390, height: 844 });
  241 |   await page.goto(article); await select(page); await page.keyboard.press('Escape');
  242 |   await page.locator('#article-fab').click();
  243 |   await page.locator('.abs-tab[data-tab="share"]').click();
  244 |   await page.locator('.abs-share-card').click();
  245 |   const dialog = page.locator('#conv-share-modal [role="dialog"]');
  246 |   await expect(dialog).toBeVisible(); await expect(dialog.locator('#csb-save-img')).toBeEnabled();
  247 |   await page.keyboard.press('Escape'); await expect(dialog).not.toBeVisible();
  248 |   await expect(page.locator('#article-bottom-sheet')).toHaveClass(/abs--open/);
  249 |   expect(await page.evaluate(() => document.body.style.overflow)).toBe('hidden');
  250 | });
  251 | 
```