# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 00-space-onboarding.spec.ts >> the resident wanders but pauses in quiet mode, dialogs, reduced motion and the workspace
- Location: tests/e2e/00-space-onboarding.spec.ts:100:5

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "{\"x\":1.25,\"z\":1.5,\"yaw\":0}"

Call Log:
- Timeout 12000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - link "Skip to main content":
    - /url: "#main-content"
  - text: /
  - main [ref=e2]:
    - generic [ref=e3]:
      - heading "空间 · CUBXXW OS" [level=1] [ref=e4]
      - paragraph [ref=e5]: CUBXXW OS 工作区
      - region "CUBXXW OS 个人工作区" [ref=e6]:
        - generic "三维咖啡馆。WASD 或方向键行走，拖动看四周。" [ref=e8]
        - generic:
          - generic:
            - link "返回博客" [ref=e9] [cursor=pointer]:
              - /url: /zh/
              - text: SPACE
              - generic [ref=e10]: CAFÉ
            - generic:
              - button "切换到英文" [ref=e11] [cursor=pointer]: EN
              - button "安静模式" [ref=e12] [cursor=pointer]
              - button "换个地方" [ref=e13] [cursor=pointer]
          - generic:
            - generic:
              - paragraph: A PLACE TO STAY A LITTLE
              - button "禅庭" [ref=e20] [cursor=pointer]:
                - generic [aria-hidden] [ref=e22]: ⌄
              - paragraph: 雨后枫树，苔石与一池静水。
            - paragraph: 不赶时间。坐一会儿。
        - navigation "咖啡馆导览":
          - generic:
            - button "看看咖啡" [ref=e23] [cursor=pointer]
            - button "逛逛书架" [ref=e24] [cursor=pointer]
            - button "看看小猫" [ref=e25] [cursor=pointer]
          - generic:
            - paragraph: 拖动看看四周，或用方向键散步。
            - button "坐下，读一篇" [ref=e26] [cursor=pointer]:
              - text: 坐下，读一篇
              - generic [aria-hidden] [ref=e27]: ↗
            - button "打开工作区" [ref=e28] [cursor=pointer]:
              - text: 打开工作区
              - generic [aria-hidden] [ref=e29]: ↗
```

# Test source

```ts
  4   | test.use({channel:'chromium',launchOptions:{args:process.platform==='darwin'?['--enable-gpu','--use-angle=metal']:['--enable-unsafe-swiftshader']}});
  5   | test.beforeEach(({page})=>reserveWorldJourney(page));
  6   | const root='[data-bear-workspace]';
  7   | const room=async(page:import('@playwright/test').Page)=>{
  8   |   await expect(page.locator(root)).toHaveAttribute('data-boot-state','complete',{timeout:30000});
  9   |   await expect(page.locator(root)).toHaveAttribute('data-world-rendered-mode','roam');
  10  | };
  11  | const clickWithClockPaused=async(control:import('@playwright/test').Locator)=>{
  12  |   await expect(control).toBeVisible();await expect(control).toBeEnabled();
  13  |   const point=await control.evaluate(el=>{const r=el.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;return {x,y,width:r.width,height:r.height,inside:x>=0&&y>=0&&x<innerWidth&&y<innerHeight,hit:el.contains(document.elementFromPoint(x,y))};});
  14  |   expect(point.width).toBeGreaterThanOrEqual(44);expect(point.height).toBeGreaterThanOrEqual(44);expect(point.inside).toBe(true);expect(point.hit).toBe(true);
  15  |   await control.page().mouse.click(point.x,point.y);
  16  | };
  17  | 
  18  | test('the terminal stays visible until a real scene frame, with a direct writing escape',async({page})=>{
  19  |   let release!:()=>void;const gate=new Promise<void>(resolve=>release=resolve);
  20  |   await page.route('**/world-cafe.*.js',async route=>{await gate;await route.continue();});
  21  |   await page.goto('/zh/projects/');
  22  |   try {
  23  |     await expect(page.locator('[data-space-boot]')).toBeVisible();
  24  |     await expect(page.locator('[data-boot-skip]')).toBeDisabled();
  25  |     await expect(page.locator('[data-space-boot] a').last()).toHaveAttribute('href','/zh/articles/');
  26  |     await expect(page.locator(root)).not.toHaveAttribute('data-world-ready','true');
  27  |     expect(await page.locator('[data-space-boot]').evaluate(el=>el.scrollWidth<=el.clientWidth)).toBe(true);
  28  |   }finally{release();}
  29  |   await room(page);await expect(page.locator(root)).toHaveAttribute('data-world-ready','true');
  30  |   await expect(page.locator('[data-space-boot]')).toBeHidden();
  31  |   await expect(page.locator('[data-cafe-read]')).toBeVisible();
  32  | });
  33  | 
  34  | test('opening a seat or terrace from the workspace preserves notes and allows returning',async({page})=>{
  35  |   await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/zh/projects/');await enterWorkspace(page);
  36  |   await page.evaluate(()=>(window as unknown as {BearSpace:{execute:(n:string,a:object)=>void}}).BearSpace.execute('open',{app:'notes'}));
  37  |   await page.locator('[data-note-editor]').fill('The same private draft.');
  38  |   await page.locator('[data-note-editor]').evaluate(el=>(el as HTMLElement).dataset.instance='resident');
  39  |   for(const place of ['outside','start']){
  40  |     await page.locator('.space-world-hud__workspace [data-cafe-picker]').click();
  41  |     await page.locator(`[data-cafe-${place}]`).click();await room(page);
  42  |     await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','cafe');
  43  |     await page.locator('[data-cafe-enter]').click();
  44  |     await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  45  |     await expect(page.locator(root)).toHaveAttribute('data-world-mode','workspace');
  46  |     await expect(page.locator('[data-note-editor]')).toHaveAttribute('data-instance','resident');
  47  |     await expect(page.locator('[data-note-editor]')).toHaveValue('The same private draft.');
  48  |   }
  49  | });
  50  | 
  51  | test('a cancelled read transition cannot steal a replayed café visit',async({page})=>{
  52  |   await page.clock.install({time:new Date('2026-10-17T00:00:00Z')});
  53  |   try{
  54  |     await page.goto('/zh/projects/');await room(page);
  55  |     await page.clock.pauseAt(new Date('2026-10-17T01:00:00Z'));
  56  |     await clickWithClockPaused(page.locator('[data-cafe-read]'));
  57  |     await expect(page.locator(root)).toHaveAttribute('data-world-travel','true');
  58  |     await clickWithClockPaused(page.locator('.space-cafe__utilities [data-cafe-picker]'));
  59  |     await clickWithClockPaused(page.locator('[data-cafe-replay]'));
  60  |     // Complete the real replacement seat travel, then its original boot/reveal
  61  |     // timers. Paused time keeps CDP latency from consuming those short states.
  62  |     await page.clock.fastForward(1200);await expect(page.locator(root)).toHaveAttribute('data-boot-state','loading');
  63  |     await page.clock.fastForward(1500);await expect(page.locator(root)).toHaveAttribute('data-boot-state','revealing');
  64  |     await page.clock.runFor(550);await room(page);
  65  |     await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','cafe');
  66  |     const snapshot=await page.evaluate(()=>(window as unknown as {BearSpace:{snapshot:()=>{active:string;windows:{id:string}[]}}}).BearSpace.snapshot());
  67  |     expect(snapshot.active).not.toBe('reader');
  68  |     await expect(page.locator('[data-space-window="reader"]')).toHaveCount(0);
  69  |     await clickWithClockPaused(page.locator('[data-cafe-enter]'));await page.clock.fastForward(2000);await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  70  |   }finally{await page.clock.resume();}
  71  | });
  72  | 
  73  | test('a completed onboarding recovers immediately after graphics context loss',async({page})=>{
  74  |   await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/zh/projects/');await room(page);
  75  |   await page.locator('.space-world__canvas').evaluate(canvas=>(canvas as HTMLCanvasElement).getContext('webgl2')!.getExtension('WEBGL_lose_context')!.loseContext());
  76  |   await expect(page.locator(root)).toHaveAttribute('data-world-failed','true');
  77  |   await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  78  |   await expect(page.locator('.space-world')).toHaveCount(0);
  79  |   await expect(page.locator('[data-space-toast]')).toBeVisible();
  80  |   await page.evaluate(()=>(window as unknown as {BearSpace:{execute:(n:string,a:object)=>void}}).BearSpace.execute('open',{app:'notes'}));
  81  |   await page.locator('[data-note-editor]').fill('Still usable after losing the GPU.');
  82  | });
  83  | 
  84  | test('module failure offers an ordinary workspace and reading link',async({page})=>{
  85  |   await page.route('**/world-cafe.*.js',route=>route.abort());
  86  |   await page.goto('/zh/projects/');await expect(page.locator(root)).toHaveAttribute('data-world-failed','true');
  87  |   await expect(page.locator('[data-boot-status]')).toContainText('仍可阅读');
  88  |   await page.locator('[data-boot-skip]').click();await expect(page.locator('[data-space-boot]')).toBeHidden();
  89  |   await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  90  |   await expect(page.locator('[data-space-menu-trigger]')).toBeVisible();
  91  | });
  92  | 
  93  | test('the optional resident can fail without blocking the room or workspace',async({page})=>{
  94  |   await page.emulateMedia({reducedMotion:'reduce'});await page.route('**/models/space/cat.glb',route=>route.abort());
  95  |   await page.goto('/zh/projects/');await room(page);await expect(page.locator(root)).toHaveAttribute('data-cat-loaded','false');
  96  |   await page.locator('[data-cafe-read]').click();await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  97  |   await expect(page.locator('[data-space-window="reader"]')).toBeVisible();
  98  | });
  99  | 
  100 | test('the resident wanders but pauses in quiet mode, dialogs, reduced motion and the workspace',async({page})=>{
  101 |   reserveWorldJourney(page);await page.goto('/zh/projects/');await room(page);
  102 |   await expect(page.locator(root)).toHaveAttribute('data-cat-loaded','true',{timeout:30000});
  103 |   const pose=()=>page.locator(root).getAttribute('data-cat-pose');const initial=await pose();
> 104 |   await expect.poll(pose,{timeout:12000}).not.toBe(initial);
      |                                               ^ Error: expect(received).not.toBe(expected) // Object.is equality
  105 |   await page.locator('[data-cafe-quiet]').click();await expect(page.locator(root)).toHaveAttribute('data-cat-active','false');
  106 |   const quiet=await pose();await page.waitForTimeout(400);expect(await pose()).toBe(quiet);
  107 |   const frames=await page.locator(root).getAttribute('data-world-frames');await page.waitForTimeout(200);expect(await page.locator(root).getAttribute('data-world-frames')).toBe(frames);
  108 |   await page.locator('[data-cafe-quiet]').click();
  109 |   await page.locator('.space-cafe__utilities [data-cafe-picker]').click();
  110 |   await expect(page.locator(root)).toHaveAttribute('data-cat-active','false');const modal=await pose();await page.waitForTimeout(400);expect(await pose()).toBe(modal);
  111 |   await page.locator('[data-cafe-picker-close]').click();
  112 |   await page.emulateMedia({reducedMotion:'reduce'});await expect(page.locator(root)).toHaveAttribute('data-cat-active','false');
  113 |   const reduced=await pose();await page.waitForTimeout(400);expect(await pose()).toBe(reduced);
  114 |   await page.locator('[data-cafe-enter]').click();await expect(page.locator(root)).toHaveAttribute('data-cafe-mode','desktop');
  115 |   const desk=await pose();await page.waitForTimeout(400);expect(await pose()).toBe(desk);
  116 | });
  117 | 
  118 | test('a graphics failure during the reveal cannot leave an invisible modal behind',async({page})=>{
  119 |   await page.clock.install({time:new Date('2026-10-17T00:00:00Z')});
  120 |   await page.clock.pauseAt(new Date('2026-10-17T01:00:00Z'));
  121 |   try{
  122 |     await page.goto('/zh/projects/');
  123 |     await expect(page.locator(root)).toHaveAttribute('data-boot-stage','2',{timeout:30000});
  124 |     await page.clock.runFor(16);await expect(page.locator(root)).toHaveAttribute('data-boot-stage','3');
  125 |     // The first actual frame is ready; preserve the original 1400ms minimum
  126 |     // before holding the real 550ms reveal window for context-loss injection.
  127 |     await page.clock.fastForward(1405);
  128 |     await expect(page.locator(root)).toHaveAttribute('data-boot-state','revealing');
  129 |     await page.locator('.space-world__canvas').evaluate(canvas=>(canvas as HTMLCanvasElement).getContext('webgl2')!.getExtension('WEBGL_lose_context')!.loseContext());
  130 |     await expect(page.locator(root)).toHaveAttribute('data-world-failed','true');
  131 |     await expect(page.locator('[data-space-boot]')).toBeHidden();
  132 |     await page.keyboard.press('Control+k');await expect(page.locator('[data-space-search]')).toBeVisible();
  133 |   }finally{await page.clock.resume();}
  134 | });
  135 | 
  136 | test('graphics recovery preserves the original editor, focus and selection',async({page})=>{
  137 |   await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/zh/projects/');await enterWorkspace(page);
  138 |   await page.evaluate(()=>(window as unknown as {BearSpace:{execute:(n:string,a:object)=>void}}).BearSpace.execute('open',{app:'notes'}));
  139 |   const editor=page.locator('[data-note-editor]');await editor.click();await page.keyboard.type('A quiet draft.');
  140 |   await expect(editor).toBeFocused();
  141 |   await editor.evaluate(el=>{(el as HTMLTextAreaElement).setSelectionRange(2,7);(el as HTMLElement).dataset.instance='same';});
  142 |   await page.locator('.space-world__canvas').evaluate(canvas=>(canvas as HTMLCanvasElement).getContext('webgl2')!.getExtension('WEBGL_lose_context')!.loseContext());
  143 |   await expect(page.locator(root)).toHaveAttribute('data-world-failed','true');
  144 |   await expect(editor).toBeFocused();await expect(editor).toHaveAttribute('data-instance','same');
  145 |   expect(await editor.evaluate(el=>[(el as HTMLTextAreaElement).selectionStart,(el as HTMLTextAreaElement).selectionEnd])).toEqual([2,7]);
  146 |   await page.keyboard.type('calm');await expect(editor).toHaveValue('A calm draft.');
  147 | });
  148 | 
  149 | test('returning from a hidden Product Lab waits for readiness and restores keyboard entry',async({page})=>{
  150 |   await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/zh/projects/#product-lab');
  151 |   await expect(page.locator(root)).toHaveAttribute('data-ready','true');
  152 |   await expect(page.locator(root)).toBeHidden();
  153 |   await page.setViewportSize({width:568,height:320});
  154 |   await page.locator('.product-view-switch [data-product-view-button="bear"]').click();
  155 |   await expect(page.locator(root)).toHaveAttribute('data-world-rendered-mode','workspace');
  156 |   await expect(page.locator('[data-space-menu-trigger]')).toBeFocused();
  157 |   await page.keyboard.press('Enter');await expect(page.locator('.space-menu')).toBeVisible();
  158 | });
  159 | 
```