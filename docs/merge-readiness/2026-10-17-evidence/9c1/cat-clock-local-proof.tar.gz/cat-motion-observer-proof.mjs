import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {resolve} from 'node:path';
import vm from 'node:vm';
import test from 'node:test';
const wt=resolve(process.argv[2]),require=createRequire(resolve(wt,'package.json'));
const {transformSync}=require('esbuild');
const source=readFileSync(resolve(wt,'tests/e2e/00-space-onboarding.spec.ts'),'utf8');
const marker='await page.addInitScript(',start=source.indexOf(marker)+marker.length,end=source.indexOf('\n  });\n  await page.goto',start);
assert.ok(start>=marker.length&&end>start,'Extract the actual current addInitScript callback');
const callback=source.slice(start,end+'\n  }'.length);
const code=transformSync(`var install=${callback};`,{loader:'ts',target:'es2020'}).code;
function fixture({present=true}={}){
  let now=0,id=0,disconnects=0;const timers=new Map(),listeners=new Map(),attrs=new Map(),observations=[];
  const target={getAttribute(name){assert.ok(['data-cat-loaded','data-cat-active','data-cat-pose'].includes(name));return attrs.get(name)??null;}};
  let observer;
  const sandbox={window:{},performance:{now:()=>now},document:{querySelector(selector){assert.equal(selector,'[data-bear-workspace]');return present?target:null;}},
    MutationObserver:class {constructor(fn){observer=this;this.callback=fn;}observe(node,options){observations.push({node,options});}disconnect(){disconnects++;}},
    setTimeout(fn,ms){timers.set(++id,{fn,at:now+ms});return id;},clearTimeout(key){timers.delete(key);},
    addEventListener(name,fn){listeners.set(name,fn);},removeEventListener(name,fn){if(listeners.get(name)===fn)listeners.delete(name);}};
  vm.createContext(sandbox);vm.runInContext(code+'\ninstall();',sandbox);
  const sample=()=>observer.callback([]),set=(values,at=now)=>{now=at;for(const [k,v]of Object.entries(values))attrs.set('data-cat-'+k,v);sample();};
  function advance(at){while(true){const next=[...timers].filter(([,t])=>t.at<=at).sort((a,b)=>a[1].at-b[1].at)[0];if(!next)break;now=next[1].at;timers.delete(next[0]);next[1].fn();}now=at;}
  return {set,advance,sample,jump:at=>now=at,hide:()=>listeners.get('pagehide')?.(),read:()=>JSON.parse(JSON.stringify(sandbox.window.__catMotionObservation)),clean:()=>{assert.equal(timers.size,0);assert.equal(listeners.size,0);assert.ok(disconnects>0);},observations};
}
const ready={loaded:'true',active:'true',pose:'{"x":1.25,"z":1.5,"yaw":0}'};
test('first actual loaded+active locks once; same pose and pause never restart time; first changed pose finishes',()=>{
  const f=fixture();f.set({...ready,active:'false'},500);assert.equal(f.read().status,'startup');
  f.set({active:'true'},1000);assert.equal(f.read().initialTime,1000);
  f.set({pose:ready.pose},2000);assert.equal(f.read().status,'watching');
  f.set({active:'false'},2500);f.set({active:'true'},3000);assert.equal(f.read().initialTime,1000);
  f.set({pose:'{"x":1.25,"z":1.51,"yaw":0}'},3100);const done=f.read();assert.equal(done.status,'changed');assert.equal(done.changedTime-done.initialTime,2100);assert.notEqual(done.changedPose,done.initialPose);f.clean();
  f.set({pose:'late'},99999);assert.deepEqual(f.read(),done);
});
test('fixed 12s motion deadline does not accept same pose or a late queued mutation',()=>{
  const f=fixture();f.set(ready,10);f.advance(12010);assert.equal(f.read().status,'motion-timeout');f.clean();const done=f.read();f.set({pose:'late'},12011);assert.deepEqual(f.read(),done);
});
test('startup has a 60s bound; delayed callback cannot lock after that deadline',()=>{
  const f=fixture({present:false});f.advance(60000);assert.equal(f.read().status,'startup-timeout');f.clean();
  const delayed=fixture();delayed.set(ready,60001);assert.equal(delayed.read().status,'startup-timeout');assert.equal(delayed.read().initialTime,null);delayed.clean();
});
test('pagehide disconnects and clears timers both before and after locking; queued callback is inert',()=>{
  for(const locked of [false,true]){const f=fixture();if(locked)f.set(ready,100);f.hide();const done=f.read();assert.equal(done.status,'pagehide');f.clean();f.set({...ready,pose:'late'},200);f.advance(70000);assert.deepEqual(f.read(),done);}
});
test('actual movement delta must stay inside 12s even if deadline timer has not run yet',()=>{
  const inside=fixture();inside.set(ready,100);inside.set({pose:'changed'},12099);assert.equal(inside.read().status,'changed');assert.equal(inside.read().changedTime-inside.read().initialTime,11999);inside.clean();
  const late=fixture();late.set(ready,100);late.set({pose:'changed'},12101);assert.equal(late.read().status,'motion-timeout');assert.equal(late.read().changedPose,null);late.clean();
});
test('observer reads only the three attributes; no frame/layout/product writes; exact source bound is tested',()=>{
  assert.doesNotMatch(callback,/requestAnimationFrame|getBoundingClientRect|scrollTop|dataset\s*[.[]|setAttribute|\.style\b/);
  const f=fixture();f.set(ready,1);assert.deepEqual(JSON.parse(JSON.stringify(f.observations.at(-1).options)),{attributes:true,attributeFilter:['data-cat-loaded','data-cat-active','data-cat-pose']});f.hide();f.clean();
});
