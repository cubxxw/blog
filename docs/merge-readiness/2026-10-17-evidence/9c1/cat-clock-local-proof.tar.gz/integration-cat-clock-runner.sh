#!/bin/sh
set -eu
cd "${1:?Pass the blog worktree path}"
node --test scripts/space-cat.test.mjs scripts/space-cat-interaction.test.mjs scripts/space-world.test.mjs
