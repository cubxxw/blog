import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const {createCatState,stepCat}=await import(pathToFileURL(resolve(process.argv[2],'assets/js/space/cat-state.mjs')));
let cat=createCatState(79),elapsed=0;
for(let steps=0;steps<6000&&cat.phase!=='rest';steps++){cat=stepCat(cat,.02);elapsed+=.02;}
assert.equal(cat.phase,'rest');
assert.ok(cat.remaining>22.65&&cat.remaining<22.67);
const pose=state=>JSON.stringify({x:state.x,z:state.z,yaw:state.yaw});
const initial=pose(cat),remaining=cat.remaining;
for(let steps=0;steps<600;steps++)cat=stepCat(cat,.02);
console.log(JSON.stringify({scope:'deterministic natural seed79; not a browser result',sampledAtSeconds:elapsed,restAtSampleSeconds:remaining,observedSeconds:12,remainingAfterSeconds:cat.remaining,initial,final:pose(cat)},null,2));
// Deliberately run the original arbitrary-phase predicate: this must fail.
assert.notEqual(pose(cat),initial,'Old arbitrary-phase 12s movement predicate is invalid during a legal natural rest');
